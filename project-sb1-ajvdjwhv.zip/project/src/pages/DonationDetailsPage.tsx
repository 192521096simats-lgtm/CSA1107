import { useState, useMemo } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  ArrowLeft, Clock, MapPin, Package, Store, Thermometer, AlertTriangle,
  Calendar, Truck, CheckCircle, XCircle, User,
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useData } from '@/context/DataContext';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, Button, DonationStatusBadge, UrgencyBadge, Badge, PageHeader, Modal, Input, Textarea } from '@/components/ui';
import { formatDateTime, countdownToExpiry, hoursUntilExpiry } from '@/services/formatters';
import { isExpired } from '@/services/matching';
import { validateRequestQuantity } from '@/services/validation';

export function DonationDetailsPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user, getAllUsers } = useAuth();
  const { getDonation, addRequest, requests, deliveries, assignDelivery, providers } = useData();

  const [showRequestModal, setShowRequestModal] = useState(false);
  const [requestForm, setRequestForm] = useState({
    requestedQuantity: 0,
    reason: '',
    preferredPickupTime: '',
    notes: '',
  });
  const [requestError, setRequestError] = useState('');
  const [assignPartnerId, setAssignPartnerId] = useState('');
  const [showAssignModal, setShowAssignModal] = useState(false);

  if (!user || !id) return null;
  const donation = getDonation(id);

  if (!donation) {
    return (
      <DashboardLayout>
        <Card className="p-8 text-center">
          <p className="text-gray-500">Donation not found.</p>
          <Button className="mt-4" variant="outline" onClick={() => navigate(-1)}>Go Back</Button>
        </Card>
      </DashboardLayout>
    );
  }

  const isProvider = user.role === 'provider' && donation.providerId === user.organizationId;
  const isRecipient = user.role === 'recipient';
  const isAdmin = user.role === 'admin';
  const expired = isExpired(donation.expiryTime);
  const hoursLeft = hoursUntilExpiry(donation.expiryTime);
  const isUrgent = hoursLeft > 0 && hoursLeft <= 6;

  const relatedRequests = requests.filter((r) => r.donationId === donation.donationId);
  const relatedDeliveries = deliveries.filter((d) => d.donationId === donation.donationId);
  const provider = providers.find((p) => p.providerId === donation.providerId);

  const handleRequestSubmit = () => {
    const qtyErr = validateRequestQuantity(requestForm.requestedQuantity, donation.quantity);
    if (qtyErr) {
      setRequestError(qtyErr);
      return;
    }
    addRequest({
      donationId: donation.donationId,
      organizationId: user.organizationId,
      organizationName: user.organizationName,
      providerId: donation.providerId,
      requestedQuantity: requestForm.requestedQuantity,
      priority: donation.urgency,
      notes: requestForm.notes,
      preferredPickupTime: requestForm.preferredPickupTime ? new Date(requestForm.preferredPickupTime).toISOString() : '',
      reason: requestForm.reason,
    });
    setShowRequestModal(false);
    setRequestForm({ requestedQuantity: 0, reason: '', preferredPickupTime: '', notes: '' });
  };

  const handleAssignDelivery = () => {
    if (assignPartnerId) {
      assignDelivery(donation.donationId, assignPartnerId);
      setShowAssignModal(false);
      setAssignPartnerId('');
    }
  };

  return (
    <DashboardLayout>
      <PageHeader
        title={donation.foodName}
        subtitle={`${donation.donationId} · ${donation.providerName}`}
        action={<Button variant="outline" onClick={() => navigate(-1)}><ArrowLeft size={16} /> Back</Button>}
      />

      {/* Expiry banner */}
      {expired ? (
        <Card className="p-4 mb-6 bg-red-50 border-red-200">
          <div className="flex items-center gap-2 text-red-700">
            <AlertTriangle size={20} />
            <span className="font-semibold">This donation has expired and can no longer be requested.</span>
          </div>
        </Card>
      ) : isUrgent ? (
        <Card className="p-4 mb-6 bg-red-50 border-red-200">
          <div className="flex items-center gap-2 text-red-700">
            <AlertTriangle size={20} className="animate-pulse" />
            <span className="font-semibold">URGENT – EXPIRING SOON</span>
            <span className="text-sm">Expires in: {countdownToExpiry(donation.expiryTime)}</span>
          </div>
        </Card>
      ) : (
        <Card className="p-4 mb-6 bg-blue-50 border-blue-200">
          <div className="flex items-center gap-2 text-blue-700">
            <Clock size={20} />
            <span className="font-medium">Expires in: {countdownToExpiry(donation.expiryTime)}</span>
          </div>
        </Card>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main details */}
        <div className="lg:col-span-2 space-y-6">
          <Card className="p-6">
            <h3 className="font-semibold text-gray-900 mb-4">Donation Information</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <DetailItem icon={Package} label="Food Type" value={donation.foodType} />
              <DetailItem icon={Package} label="Quantity" value={`${donation.quantity} ${donation.unit}`} />
              <DetailItem icon={Calendar} label="Preparation Time" value={formatDateTime(donation.preparationTime)} />
              <DetailItem icon={Clock} label="Expiry Time" value={formatDateTime(donation.expiryTime)} />
              <DetailItem icon={Thermometer} label="Storage Requirement" value={donation.storageRequirement} />
              <DetailItem icon={MapPin} label="Pickup Location" value={donation.pickupLocation} />
              <DetailItem icon={Store} label="Provider" value={donation.providerName} />
              <div>
                <p className="text-xs text-gray-500 mb-1">Status</p>
                <DonationStatusBadge status={donation.status} />
              </div>
              <div>
                <p className="text-xs text-gray-500 mb-1">Urgency</p>
                <UrgencyBadge urgency={donation.urgency} />
              </div>
            </div>
            {donation.description && (
              <div className="mt-4 pt-4 border-t border-gray-100">
                <p className="text-xs text-gray-500 mb-1">Description</p>
                <p className="text-sm text-gray-700">{donation.description}</p>
              </div>
            )}
          </Card>

          {/* Related requests */}
          {relatedRequests.length > 0 && (
            <Card className="p-6">
              <h3 className="font-semibold text-gray-900 mb-4">Requests for This Donation</h3>
              <div className="space-y-3">
                {relatedRequests.map((req) => (
                  <div key={req.requestId} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                    <div>
                      <p className="text-sm font-medium text-gray-900">{req.organizationName}</p>
                      <p className="text-xs text-gray-500">{req.requestedQuantity} {donation.unit} · {formatDateTime(req.requestDate)}</p>
                    </div>
                    <RequestStatusPill status={req.status} />
                  </div>
                ))}
              </div>
            </Card>
          )}

          {/* Related deliveries */}
          {relatedDeliveries.length > 0 && (
            <Card className="p-6">
              <h3 className="font-semibold text-gray-900 mb-4">Delivery Information</h3>
              {relatedDeliveries.map((del) => (
                <div key={del.deliveryId} className="p-3 bg-gray-50 rounded-lg space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-gray-900">{del.deliveryId}</span>
                    <Badge color="blue">{del.status}</Badge>
                  </div>
                  <div className="text-xs text-gray-500">
                    <p>From: {del.pickupLocation}</p>
                    <p>To: {del.destination}</p>
                    <p>Partner: {del.partnerName}</p>
                  </div>
                </div>
              ))}
            </Card>
          )}
        </div>

        {/* Sidebar actions */}
        <div className="space-y-4">
          <Card className="p-5">
            <h3 className="font-semibold text-gray-900 mb-4">Actions</h3>
            {isRecipient && !expired && donation.status === 'Available' && (
              <Button className="w-full" onClick={() => setShowRequestModal(true)}>
                <CheckCircle size={16} /> Request Donation
              </Button>
            )}
            {isRecipient && expired && (
              <p className="text-sm text-red-600 text-center py-2">This donation has expired.</p>
            )}
            {isRecipient && donation.status !== 'Available' && !expired && (
              <p className="text-sm text-gray-500 text-center py-2">This donation is no longer available for requests.</p>
            )}
            {isProvider && donation.status === 'Approved' && (
              <Button className="w-full" onClick={() => setShowAssignModal(true)}>
                <Truck size={16} /> Assign Delivery Partner
              </Button>
            )}
            {isAdmin && donation.status === 'Approved' && (
              <Button className="w-full" onClick={() => setShowAssignModal(true)}>
                <Truck size={16} /> Assign Delivery Partner
              </Button>
            )}
            {(isProvider || isAdmin) && (
              <Button variant="outline" className="w-full mt-2" onClick={() => navigate(`/provider/matching`)}>
                View Matches
              </Button>
            )}
          </Card>

          {provider && (
            <Card className="p-5">
              <h3 className="font-semibold text-gray-900 mb-3">Provider Info</h3>
              <div className="space-y-2 text-sm">
                <div className="flex items-center gap-2 text-gray-600"><Store size={14} /> {provider.organizationName}</div>
                <div className="flex items-center gap-2 text-gray-600"><MapPin size={14} /> {provider.address}</div>
                <div className="flex items-center gap-2 text-gray-600"><User size={14} /> {provider.contactName}</div>
                <div className="flex items-center gap-2 text-gray-600"><Package size={14} /> {provider.totalDonations} total donations</div>
                {provider.rating > 0 && (
                  <div className="flex items-center gap-2"><Badge color="green">Rating: {provider.rating}/5</Badge></div>
                )}
              </div>
            </Card>
          )}
        </div>
      </div>

      {/* Request modal */}
      <Modal open={showRequestModal} onClose={() => setShowRequestModal(false)} title="Request Donation">
        <p className="text-sm text-gray-600 mb-4">Are you sure you want to request this donation?</p>
        <div className="space-y-4">
          <Input
            label={`Requested Quantity (max: ${donation.quantity} ${donation.unit})`}
            type="number"
            value={requestForm.requestedQuantity || ''}
            onChange={(e) => { setRequestForm({ ...requestForm, requestedQuantity: parseFloat(e.target.value) || 0 }); setRequestError(''); }}
            error={requestError}
            placeholder={`Max ${donation.quantity}`}
          />
          <Input
            label="Reason / Requirement"
            value={requestForm.reason}
            onChange={(e) => setRequestForm({ ...requestForm, reason: e.target.value })}
            placeholder="Why do you need this food?"
          />
          <Input
            label="Preferred Pickup Time"
            type="datetime-local"
            value={requestForm.preferredPickupTime}
            onChange={(e) => setRequestForm({ ...requestForm, preferredPickupTime: e.target.value })}
          />
          <Textarea
            label="Additional Notes"
            value={requestForm.notes}
            onChange={(e) => setRequestForm({ ...requestForm, notes: e.target.value })}
            placeholder="Any special instructions..."
            rows={3}
          />
        </div>
        <div className="flex gap-3 mt-6 justify-end">
          <Button variant="outline" onClick={() => setShowRequestModal(false)}>Cancel</Button>
          <Button onClick={handleRequestSubmit}>Submit Request</Button>
        </div>
      </Modal>

      {/* Assign delivery modal */}
      <Modal open={showAssignModal} onClose={() => setShowAssignModal(false)} title="Assign Delivery Partner" size="sm">
        <p className="text-sm text-gray-600 mb-4">Select a delivery partner to assign for this donation.</p>
        <div className="space-y-2">
          {getAllUsers().filter((u) => u.role === 'delivery').map((u) => (
            <button
              key={u.userId}
              onClick={() => setAssignPartnerId(u.userId)}
              className={`w-full text-left p-3 rounded-lg border transition-colors ${
                assignPartnerId === u.userId ? 'border-brand-500 bg-brand-50' : 'border-gray-200 hover:bg-gray-50'
              }`}
            >
              <p className="text-sm font-medium text-gray-900">{u.name}</p>
              <p className="text-xs text-gray-500">{u.organizationName}</p>
            </button>
          ))}
          {getAllUsers().filter((u) => u.role === 'delivery').length === 0 && <p className="text-sm text-gray-500">No delivery partners available.</p>}
        </div>
        <div className="flex gap-3 mt-6 justify-end">
          <Button variant="outline" onClick={() => setShowAssignModal(false)}>Cancel</Button>
          <Button onClick={handleAssignDelivery} disabled={!assignPartnerId}>Assign</Button>
        </div>
      </Modal>
    </DashboardLayout>
  );
}

function DetailItem({ icon: Icon, label, value }: { icon: typeof Clock; label: string; value: string }) {
  return (
    <div>
      <p className="text-xs text-gray-500 mb-1 flex items-center gap-1"><Icon size={12} /> {label}</p>
      <p className="text-sm text-gray-700">{value}</p>
    </div>
  );
}

function RequestStatusPill({ status }: { status: string }) {
  const colors: Record<string, string> = {
    Pending: 'amber', Approved: 'green', Rejected: 'red', Fulfilled: 'green', Cancelled: 'gray',
  };
  return <Badge color={colors[status] as 'amber' | 'green' | 'red' | 'gray'}>{status}</Badge>;
}
