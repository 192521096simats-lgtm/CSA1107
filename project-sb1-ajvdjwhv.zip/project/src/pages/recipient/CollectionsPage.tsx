import { useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { PackageCheck, Truck, MapPin, Clock, Eye, Inbox } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useData } from '@/context/DataContext';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, Button, DeliveryStatusBadge, PageHeader, EmptyState, Badge } from '@/components/ui';
import { formatDateTime } from '@/services/formatters';

export function CollectionsPage() {
  const { user } = useAuth();
  const { deliveries, donations } = useData();
  const navigate = useNavigate();

  if (!user) return null;

  const myDeliveries = useMemo(() => {
    return deliveries
      .filter((d) => d.recipientId === user.organizationId)
      .sort((a, b) => new Date(b.assignedTime).getTime() - new Date(a.assignedTime).getTime());
  }, [deliveries, user.organizationId]);

  const handleConfirmCollection = (deliveryId: string) => {
    // Navigate to delivery tracking page
    navigate(`/recipient/collections/${deliveryId}`);
  };

  return (
    <DashboardLayout>
      <PageHeader title="Collections" subtitle="Track incoming food deliveries to your organization" />

      {myDeliveries.length === 0 ? (
        <Card className="p-6">
          <EmptyState icon={Inbox} title="No deliveries yet" message="When providers assign deliveries to your organization, they will appear here." />
        </Card>
      ) : (
        <div className="space-y-4">
          {myDeliveries.map((del) => {
            const donation = donations.find((d) => d.donationId === del.donationId);
            return (
              <Card key={del.deliveryId} className="p-5">
                <div className="flex flex-col lg:flex-row gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-3">
                      <h3 className="font-semibold text-gray-900">{del.deliveryId}</h3>
                      <DeliveryStatusBadge status={del.status} />
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-sm">
                      <div>
                        <p className="text-xs text-gray-500">Food</p>
                        <p className="font-medium text-gray-700">{del.foodName}</p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-500">Quantity</p>
                        <p className="font-medium text-gray-700">{del.quantity} {del.unit}</p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-500">Provider</p>
                        <p className="font-medium text-gray-700">{del.providerName}</p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-500">Delivery Partner</p>
                        <p className="font-medium text-gray-700">{del.partnerName}</p>
                      </div>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm mt-3">
                      <div className="flex items-start gap-2">
                        <MapPin size={14} className="text-gray-400 mt-0.5" />
                        <div>
                          <p className="text-xs text-gray-500">Pickup</p>
                          <p className="text-gray-700 text-xs">{del.pickupLocation}</p>
                        </div>
                      </div>
                      <div className="flex items-start gap-2">
                        <MapPin size={14} className="text-gray-400 mt-0.5" />
                        <div>
                          <p className="text-xs text-gray-500">Destination</p>
                          <p className="text-gray-700 text-xs">{del.destination}</p>
                        </div>
                      </div>
                    </div>
                    {del.deliveryTime && (
                      <div className="mt-2 flex items-center gap-2">
                        <Badge color="green"><Clock size={12} className="inline mr-1" /> Delivered: {formatDateTime(del.deliveryTime)}</Badge>
                      </div>
                    )}
                  </div>
                  <div className="flex flex-row lg:flex-col gap-2 lg:w-40">
                    <Button size="sm" variant="outline" onClick={() => navigate(`/recipient/collections/${del.deliveryId}`)}>
                      <Eye size={14} /> Track Delivery
                    </Button>
                    {del.status === 'Delivered' && (
                      <Button size="sm" onClick={() => navigate(`/recipient/distribution?deliveryId=${del.deliveryId}`)}>
                        <PackageCheck size={14} /> Confirm Collection
                      </Button>
                    )}
                  </div>
                </div>
              </Card>
            );
          })}
        </div>
      )}
    </DashboardLayout>
  );
}
