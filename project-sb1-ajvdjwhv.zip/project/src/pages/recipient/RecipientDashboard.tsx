import { Link } from 'react-router-dom';
import {
  Package, Clock, CheckCircle, Utensils, Search, Heart, MapPin, AlertTriangle,
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useData } from '@/context/DataContext';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, StatCard, Button, Badge, UrgencyBadge, PageHeader, EmptyState } from '@/components/ui';
import { DonutChart, BarChartViz } from '@/components/charts/Charts';
import { donationsByFoodType, weeklyRedistribution } from '@/services/analytics';
import { countdownToExpiry } from '@/services/formatters';
import { isExpired } from '@/services/matching';
import { calculateDistance } from '@/services/matching';

export function RecipientDashboard() {
  const { user } = useAuth();
  const { donations, requests, distributions, recipients } = useData();

  if (!user) return null;
  const recipient = recipients.find((r) => r.organizationId === user.organizationId);

  const availableDonations = donations.filter((d) => d.status === 'Available' && !isExpired(d.expiryTime));
  const myRequests = requests.filter((r) => r.organizationId === user.organizationId);
  const pendingRequests = myRequests.filter((r) => r.status === 'Pending').length;
  const approvedRequests = myRequests.filter((r) => r.status === 'Approved').length;
  const foodReceived = distributions.filter((d) => d.organizationId === user.organizationId).reduce((sum, d) => sum + d.totalReceived, 0);
  const mealsDistributed = distributions.filter((d) => d.organizationId === user.organizationId).reduce((sum, d) => sum + d.distributedQuantity, 0);

  const sortedAvailable = [...availableDonations]
    .map((d) => {
      const dist = recipient ? calculateDistance(d.pickupLatitude, d.pickupLongitude, recipient.latitude, recipient.longitude) : 0;
      return { ...d, distance: dist };
    })
    .sort((a, b) => {
      const urgencyOrder = { Critical: 0, High: 1, Medium: 2, Low: 3 };
      return urgencyOrder[a.urgency] - urgencyOrder[b.urgency] || a.distance - b.distance;
    })
    .slice(0, 6);

  return (
    <DashboardLayout>
      <PageHeader
        title="Dashboard"
        subtitle={`Welcome back, ${user.name}`}
        action={<Link to="/recipient/browse"><Button><Search size={18} /> Browse Donations</Button></Link>}
      />

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4 mb-6">
        <StatCard label="Available Donations" value={availableDonations.length} icon={Package} color="brand" />
        <StatCard label="Pending Requests" value={pendingRequests} icon={Clock} color="amber" />
        <StatCard label="Approved Requests" value={approvedRequests} icon={CheckCircle} color="teal" />
        <StatCard label="Food Received" value={`${foodReceived}`} icon={Utensils} color="blue" />
        <StatCard label="Meals Distributed" value={mealsDistributed} icon={Heart} color="brand" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        <Card className="p-5">
          <h3 className="font-semibold text-gray-900 mb-4">Donations by Food Type</h3>
          <DonutChart data={donationsByFoodType(donations)} />
        </Card>
        <Card className="p-5 lg:col-span-2">
          <h3 className="font-semibold text-gray-900 mb-4">Weekly Redistribution Trend</h3>
          <BarChartViz data={weeklyRedistribution(donations)} />
        </Card>
      </div>

      <Card className="overflow-hidden">
        <div className="px-5 py-4 border-b border-gray-200 flex items-center justify-between">
          <h3 className="font-semibold text-gray-900">Available Donations Near You</h3>
          <Link to="/recipient/browse" className="text-sm text-brand-600 hover:text-brand-700 font-medium">View All</Link>
        </div>
        {sortedAvailable.length === 0 ? (
          <EmptyState icon={Package} title="No available donations" message="Check back later for new surplus food donations from providers." />
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 p-5">
            {sortedAvailable.map((d) => (
              <Card key={d.donationId} className="p-4 hover:shadow-md transition-shadow">
                <div className="flex items-start justify-between mb-2">
                  <div className="flex-1 min-w-0">
                    <h4 className="font-semibold text-gray-900 text-sm truncate">{d.foodName}</h4>
                    <p className="text-xs text-gray-500">{d.providerName}</p>
                  </div>
                  <UrgencyBadge urgency={d.urgency} />
                </div>
                <div className="grid grid-cols-2 gap-2 text-xs text-gray-600 mt-3">
                  <div><span className="text-gray-400">Qty:</span> {d.quantity} {d.unit}</div>
                  <div className="flex items-center gap-1"><MapPin size={10} /> {d.distance.toFixed(1)} km</div>
                  <div className="flex items-center gap-1"><Clock size={10} /> {countdownToExpiry(d.expiryTime)}</div>
                  <div><span className="text-gray-400">Storage:</span> {d.storageRequirement}</div>
                </div>
                <div className="mt-3">
                  <Link to={`/recipient/browse/${d.donationId}`}>
                    <Button size="sm" variant="outline" className="w-full">View Details</Button>
                  </Link>
                </div>
              </Card>
            ))}
          </div>
        )}
      </Card>
    </DashboardLayout>
  );
}
