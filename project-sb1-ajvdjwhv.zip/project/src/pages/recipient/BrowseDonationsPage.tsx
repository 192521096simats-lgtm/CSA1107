import { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, MapPin, Clock, Package, Filter, Inbox } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useData } from '@/context/DataContext';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, Button, Select, Badge, UrgencyBadge, PageHeader, EmptyState } from '@/components/ui';
import { countdownToExpiry } from '@/services/formatters';
import { isExpired, calculateDistance } from '@/services/matching';
import { foodTypeList } from '@/services/analytics';
import type { FoodType, UrgencyLevel } from '@/types';

export function BrowseDonationsPage() {
  const { user } = useAuth();
  const { donations, recipients } = useData();
  const navigate = useNavigate();

  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState('');
  const [urgencyFilter, setUrgencyFilter] = useState('');
  const [distanceFilter, setDistanceFilter] = useState('');
  const [sortBy, setSortBy] = useState('urgency');

  if (!user) return null;
  const recipient = recipients.find((r) => r.organizationId === user.organizationId);

  const availableDonations = useMemo(() => {
    let list = donations
      .filter((d) => d.status === 'Available')
      .filter((d) => !isExpired(d.expiryTime))
      .filter((d) => !search || d.foodName.toLowerCase().includes(search.toLowerCase()) || d.providerName.toLowerCase().includes(search.toLowerCase()))
      .filter((d) => !typeFilter || d.foodType === typeFilter)
      .filter((d) => !urgencyFilter || d.urgency === urgencyFilter)
      .map((d) => {
        const dist = recipient ? calculateDistance(d.pickupLatitude, d.pickupLongitude, recipient.latitude, recipient.longitude) : 0;
        return { ...d, distance: dist };
      });

    if (distanceFilter) {
      const maxDist = parseFloat(distanceFilter);
      list = list.filter((d) => d.distance <= maxDist);
    }

    const urgencyOrder: Record<UrgencyLevel, number> = { Critical: 0, High: 1, Medium: 2, Low: 3 };
    if (sortBy === 'urgency') {
      list.sort((a, b) => urgencyOrder[a.urgency] - urgencyOrder[b.urgency] || a.distance - b.distance);
    } else if (sortBy === 'distance') {
      list.sort((a, b) => a.distance - b.distance);
    } else if (sortBy === 'expiry') {
      list.sort((a, b) => new Date(a.expiryTime).getTime() - new Date(b.expiryTime).getTime());
    } else if (sortBy === 'quantity') {
      list.sort((a, b) => b.quantity - a.quantity);
    }

    return list;
  }, [donations, recipient, search, typeFilter, urgencyFilter, distanceFilter, sortBy]);

  const typeOptions = foodTypeList.map((f) => ({ value: f, label: f }));
  const urgencyOptions = [
    { value: 'Critical', label: 'Critical' },
    { value: 'High', label: 'High' },
    { value: 'Medium', label: 'Medium' },
    { value: 'Low', label: 'Low' },
  ];
  const distanceOptions = [
    { value: '5', label: 'Within 5 km' },
    { value: '10', label: 'Within 10 km' },
    { value: '20', label: 'Within 20 km' },
    { value: '50', label: 'Within 50 km' },
  ];
  const sortOptions = [
    { value: 'urgency', label: 'Sort: Urgency' },
    { value: 'distance', label: 'Sort: Distance' },
    { value: 'expiry', label: 'Sort: Expiry Time' },
    { value: 'quantity', label: 'Sort: Quantity' },
  ];

  return (
    <DashboardLayout>
      <PageHeader title="Browse Donations" subtitle="Find available surplus food donations near you" />

      <Card className="p-4 mb-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-3">
          <div className="relative">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Search food or provider..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-9 pr-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-brand-500"
            />
          </div>
          <Select value={typeFilter} onChange={(e) => setTypeFilter(e.target.value)} options={typeOptions} placeholder="All Food Types" />
          <Select value={urgencyFilter} onChange={(e) => setUrgencyFilter(e.target.value)} options={urgencyOptions} placeholder="All Urgency" />
          <Select value={distanceFilter} onChange={(e) => setDistanceFilter(e.target.value)} options={distanceOptions} placeholder="Any Distance" />
          <Select value={sortBy} onChange={(e) => setSortBy(e.target.value)} options={sortOptions} />
        </div>
      </Card>

      {availableDonations.length === 0 ? (
        <Card className="p-6">
          <EmptyState icon={Inbox} title="No donations found" message="Try adjusting your filters or check back later for new donations." />
        </Card>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {availableDonations.map((d) => (
            <Card key={d.donationId} className="p-4 hover:shadow-md transition-shadow flex flex-col">
              <div className="flex items-start justify-between mb-2">
                <div className="flex-1 min-w-0">
                  <h4 className="font-semibold text-gray-900 text-sm truncate">{d.foodName}</h4>
                  <p className="text-xs text-gray-500 mt-0.5">{d.providerName}</p>
                </div>
                <UrgencyBadge urgency={d.urgency} />
              </div>

              <div className="space-y-1.5 text-xs text-gray-600 mt-3 flex-1">
                <div className="flex items-center gap-1.5"><Package size={12} className="text-gray-400" /> {d.quantity} {d.unit} · {d.foodType}</div>
                <div className="flex items-center gap-1.5"><MapPin size={12} className="text-gray-400" /> {d.distance.toFixed(1)} km away</div>
                <div className="flex items-center gap-1.5"><Clock size={12} className="text-gray-400" /> Expires in {countdownToExpiry(d.expiryTime)}</div>
                <div className="flex items-center gap-1.5"><span className="text-gray-400">Storage:</span> {d.storageRequirement}</div>
              </div>

              <div className="mt-4 flex gap-2">
                <Button size="sm" variant="outline" className="flex-1" onClick={() => navigate(`/recipient/browse/${d.donationId}`)}>
                  View Details
                </Button>
              </div>
            </Card>
          ))}
        </div>
      )}
    </DashboardLayout>
  );
}
