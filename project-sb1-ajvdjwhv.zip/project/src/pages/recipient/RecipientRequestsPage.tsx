import { useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { ClipboardList, Eye, Inbox, Clock, CheckCircle } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useData } from '@/context/DataContext';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, Button, RequestStatusBadge, PageHeader, EmptyState, Badge } from '@/components/ui';
import { formatDateTime } from '@/services/formatters';

export function RecipientRequestsPage() {
  const { user } = useAuth();
  const { requests, donations } = useData();
  const navigate = useNavigate();

  if (!user) return null;

  const myRequests = useMemo(() => {
    return requests
      .filter((r) => r.organizationId === user.organizationId)
      .sort((a, b) => new Date(b.requestDate).getTime() - new Date(a.requestDate).getTime());
  }, [requests, user.organizationId]);

  return (
    <DashboardLayout>
      <PageHeader title="My Requests" subtitle="Track all your food donation requests" />

      {myRequests.length === 0 ? (
        <Card className="p-6">
          <EmptyState icon={Inbox} title="No requests yet" message="Browse available donations and submit a request to get started." />
        </Card>
      ) : (
        <div className="space-y-4">
          {myRequests.map((req) => {
            const donation = donations.find((d) => d.donationId === req.donationId);
            return (
              <Card key={req.requestId} className="p-5">
                <div className="flex flex-col lg:flex-row gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-3">
                      <h3 className="font-semibold text-gray-900">{req.requestId}</h3>
                      <RequestStatusBadge status={req.status} />
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-sm">
                      <div>
                        <p className="text-xs text-gray-500">Food Item</p>
                        <p className="font-medium text-gray-700">{donation?.foodName ?? 'N/A'}</p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-500">Provider</p>
                        <p className="font-medium text-gray-700">{donation?.providerName ?? 'N/A'}</p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-500">Requested Qty</p>
                        <p className="font-medium text-gray-700">{req.requestedQuantity} {donation?.unit ?? ''}</p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-500">Request Date</p>
                        <p className="font-medium text-gray-700 text-xs">{formatDateTime(req.requestDate)}</p>
                      </div>
                    </div>
                    {req.reason && (
                      <div className="mt-3 p-3 bg-gray-50 rounded-lg">
                        <p className="text-xs text-gray-500 mb-1">Reason</p>
                        <p className="text-sm text-gray-700">{req.reason}</p>
                      </div>
                    )}
                    {req.status === 'Approved' && (
                      <div className="mt-2 flex items-center gap-2">
                        <Badge color="green"><CheckCircle size={12} className="inline mr-1" /> Approved - Awaiting Delivery Assignment</Badge>
                      </div>
                    )}
                  </div>
                  <div className="flex flex-row lg:flex-col gap-2 lg:w-40">
                    {donation && (
                      <Button size="sm" variant="outline" onClick={() => navigate(`/recipient/browse/${req.donationId}`)}>
                        <Eye size={14} /> View Donation
                      </Button>
                    )}
                  </div>
                </div>
              </Card>
            );
          })}
        </div>
      )}
    </DashboardLayout>
  );
}
