import { useState, useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Utensils, Package, TrendingUp, ClipboardList, Plus, Edit, Inbox } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useData } from '@/context/DataContext';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, Button, Input, Select, Textarea, PageHeader, EmptyState, Badge, Modal, StatCard } from '@/components/ui';
import { formatDateTime } from '@/services/formatters';
import type { DistributionStatus } from '@/types';

export function DistributionPage() {
  const { user } = useAuth();
  const { distributions, deliveries, addDistribution, updateDistribution } = useData();
  const [searchParams] = useSearchParams();
  const preselectDeliveryId = searchParams.get('deliveryId');

  const [showModal, setShowModal] = useState(!!preselectDeliveryId);
  const [editTarget, setEditTarget] = useState<string | null>(null);
  const [form, setForm] = useState({
    deliveryId: preselectDeliveryId ?? '',
    distributedQuantity: 0,
    status: 'Received' as DistributionStatus,
    notes: '',
  });

  if (!user) return null;

  const myDistributions = useMemo(() => {
    return distributions
      .filter((d) => d.organizationId === user.organizationId)
      .sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime());
  }, [distributions, user.organizationId]);

  const completedDeliveries = deliveries.filter(
    (d) => d.recipientId === user.organizationId && (d.status === 'Delivered' || d.status === 'Confirmed'),
  );

  const totalReceived = myDistributions.reduce((sum, d) => sum + d.totalReceived, 0);
  const totalDistributed = myDistributions.reduce((sum, d) => sum + d.distributedQuantity, 0);
  const totalRemaining = myDistributions.reduce((sum, d) => sum + d.remainingQuantity, 0);

  const statusOptions: { value: DistributionStatus; label: DistributionStatus }[] = [
    { value: 'Received', label: 'Received' },
    { value: 'Being Prepared', label: 'Being Prepared' },
    { value: 'Distributed', label: 'Distributed' },
    { value: 'Partially Distributed', label: 'Partially Distributed' },
    { value: 'Unable to Distribute', label: 'Unable to Distribute' },
  ];

  const handleCreateOrUpdate = () => {
    const delivery = deliveries.find((d) => d.deliveryId === form.deliveryId);
    if (!delivery) return;

    if (editTarget) {
      const existing = myDistributions.find((d) => d.distributionId === editTarget);
      if (existing) {
        const remaining = existing.totalReceived - form.distributedQuantity;
        updateDistribution(editTarget, {
          distributedQuantity: form.distributedQuantity,
          remainingQuantity: remaining,
          status: form.status,
          notes: form.notes,
        });
      }
    } else {
      addDistribution({
        deliveryId: form.deliveryId,
        donationId: delivery.donationId,
        organizationId: user.organizationId,
        organizationName: user.organizationName,
        foodName: delivery.foodName,
        totalReceived: delivery.quantity,
        distributedQuantity: form.distributedQuantity,
        remainingQuantity: delivery.quantity - form.distributedQuantity,
        unit: delivery.unit,
        status: form.status,
        notes: form.notes,
      });
    }

    setShowModal(false);
    setEditTarget(null);
    setForm({ deliveryId: '', distributedQuantity: 0, status: 'Received', notes: '' });
  };

  const openEdit = (distId: string) => {
    const dist = myDistributions.find((d) => d.distributionId === distId);
    if (dist) {
      setForm({
        deliveryId: dist.deliveryId,
        distributedQuantity: dist.distributedQuantity,
        status: dist.status,
        notes: dist.notes,
      });
      setEditTarget(distId);
      setShowModal(true);
    }
  };

  const statusColors: Record<DistributionStatus, 'green' | 'blue' | 'amber' | 'red' | 'gray'> = {
    Received: 'blue',
    'Being Prepared': 'amber',
    Distributed: 'green',
    'Partially Distributed': 'amber',
    'Unable to Distribute': 'red',
  };

  return (
    <DashboardLayout>
      <PageHeader
        title="Distribution"
        subtitle="Track food distribution to people in need"
        action={
          <Button onClick={() => { setForm({ deliveryId: '', distributedQuantity: 0, status: 'Received', notes: '' }); setEditTarget(null); setShowModal(true); }}>
            <Plus size={18} /> Record Distribution
          </Button>
        }
      />

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
        <StatCard label="Total Received" value={totalReceived} icon={Package} color="blue" />
        <StatCard label="Total Distributed" value={totalDistributed} icon={TrendingUp} color="brand" />
        <StatCard label="Remaining" value={totalRemaining} icon={Utensils} color="amber" />
      </div>

      {myDistributions.length === 0 ? (
        <Card className="p-6">
          <EmptyState icon={Inbox} title="No distributions recorded" message="Once you receive food deliveries, record how you distribute it to people in need." />
        </Card>
      ) : (
        <Card className="overflow-hidden">
          <div className="overflow-x-auto table-scroll">
            <table className="w-full text-sm">
              <thead className="bg-gray-50 text-gray-600">
                <tr>
                  <th className="px-4 py-3 text-left font-medium">Distribution ID</th>
                  <th className="px-4 py-3 text-left font-medium">Food</th>
                  <th className="px-4 py-3 text-left font-medium">Received</th>
                  <th className="px-4 py-3 text-left font-medium">Distributed</th>
                  <th className="px-4 py-3 text-left font-medium">Remaining</th>
                  <th className="px-4 py-3 text-left font-medium">Status</th>
                  <th className="px-4 py-3 text-left font-medium">Updated</th>
                  <th className="px-4 py-3 text-left font-medium">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {myDistributions.map((d) => (
                  <tr key={d.distributionId} className="hover:bg-gray-50">
                    <td className="px-4 py-3 font-medium text-gray-900 text-xs">{d.distributionId}</td>
                    <td className="px-4 py-3 text-gray-700">{d.foodName}</td>
                    <td className="px-4 py-3 text-gray-600">{d.totalReceived} {d.unit}</td>
                    <td className="px-4 py-3 text-gray-600">{d.distributedQuantity} {d.unit}</td>
                    <td className="px-4 py-3 text-gray-600">{d.remainingQuantity} {d.unit}</td>
                    <td className="px-4 py-3"><Badge color={statusColors[d.status]}>{d.status}</Badge></td>
                    <td className="px-4 py-3 text-gray-500 text-xs">{formatDateTime(d.updatedAt)}</td>
                    <td className="px-4 py-3">
                      <Button size="sm" variant="ghost" onClick={() => openEdit(d.distributionId)}>
                        <Edit size={14} />
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      )}

      <Modal open={showModal} onClose={() => { setShowModal(false); setEditTarget(null); }} title={editTarget ? 'Update Distribution' : 'Record Distribution'}>
        <div className="space-y-4">
          {!editTarget && (
            <Select
              label="Select Delivery"
              value={form.deliveryId}
              onChange={(e) => setForm({ ...form, deliveryId: e.target.value })}
              options={completedDeliveries.map((d) => ({ value: d.deliveryId, label: `${d.deliveryId} - ${d.foodName} (${d.quantity} ${d.unit})` }))}
              placeholder="Choose a delivered item"
            />
          )}
          <Input
            label="Distributed Quantity"
            type="number"
            value={form.distributedQuantity || ''}
            onChange={(e) => setForm({ ...form, distributedQuantity: parseFloat(e.target.value) || 0 })}
            placeholder="0"
          />
          <Select
            label="Distribution Status"
            value={form.status}
            onChange={(e) => setForm({ ...form, status: e.target.value as DistributionStatus })}
            options={statusOptions}
          />
          <Textarea
            label="Notes"
            value={form.notes}
            onChange={(e) => setForm({ ...form, notes: e.target.value })}
            placeholder="Distribution details, who received the food, etc."
            rows={3}
          />
        </div>
        <div className="flex gap-3 mt-6 justify-end">
          <Button variant="outline" onClick={() => { setShowModal(false); setEditTarget(null); }}>Cancel</Button>
          <Button onClick={handleCreateOrUpdate}>{editTarget ? 'Update' : 'Record'}</Button>
        </div>
      </Modal>
    </DashboardLayout>
  );
}
