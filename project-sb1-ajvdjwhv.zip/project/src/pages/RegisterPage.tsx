import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Leaf, ArrowRight, AlertCircle, ArrowLeft } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { Button, Input, Select } from '@/components/ui';
import { validateEmail, validatePhone, validateRequired, validatePassword } from '@/services/validation';
import type { UserRole, OrganizationType } from '@/types';

export function RegisterPage() {
  const { register } = useAuth();
  const navigate = useNavigate();

  const [form, setForm] = useState({
    name: '',
    organizationName: '',
    email: '',
    phone: '',
    password: '',
    confirmPassword: '',
    role: 'provider' as UserRole,
    address: '',
    city: '',
    organizationType: 'Restaurant' as OrganizationType,
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [serverError, setServerError] = useState('');
  const [loading, setLoading] = useState(false);

  const roleOptions = [
    { value: 'provider', label: 'Food Provider' },
    { value: 'recipient', label: 'Recipient Organization' },
    { value: 'delivery', label: 'Delivery Partner' },
  ];

  const orgTypeOptions = [
    { value: 'Restaurant', label: 'Restaurant' },
    { value: 'Hotel', label: 'Hotel' },
    { value: 'Supermarket', label: 'Supermarket' },
    { value: 'Food Supplier', label: 'Food Supplier' },
    { value: 'Charity', label: 'Charity' },
    { value: 'NGO', label: 'NGO' },
  ];

  const handleChange = (field: string, value: string) => {
    setForm({ ...form, [field]: value });
    if (errors[field]) setErrors({ ...errors, [field]: '' });
  };

  const validate = (): boolean => {
    const newErrors: Record<string, string> = {};
    const nameErr = validateRequired(form.name, 'Full Name');
    if (nameErr) newErrors.name = nameErr;
    const orgErr = validateRequired(form.organizationName, 'Organization Name');
    if (orgErr) newErrors.organizationName = orgErr;
    const emailErr = validateEmail(form.email);
    if (emailErr) newErrors.email = emailErr;
    const phoneErr = validatePhone(form.phone);
    if (phoneErr) newErrors.phone = phoneErr;
    const passwordErr = validatePassword(form.password);
    if (passwordErr) newErrors.password = passwordErr;
    if (form.password !== form.confirmPassword) newErrors.confirmPassword = 'Passwords do not match';
    const addressErr = validateRequired(form.address, 'Address');
    if (addressErr) newErrors.address = addressErr;
    const cityErr = validateRequired(form.city, 'City');
    if (cityErr) newErrors.city = cityErr;

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setServerError('');
    if (!validate()) return;
    setLoading(true);

    const result = register({
      name: form.name,
      organizationName: form.organizationName,
      email: form.email,
      phone: form.phone,
      password: form.password,
      role: form.role,
      address: form.address,
      city: form.city,
      organizationType: form.organizationType,
    });

    if (result.success) {
      const rolePaths: Record<UserRole, string> = {
        provider: '/provider',
        recipient: '/recipient',
        delivery: '/delivery',
        admin: '/admin',
      };
      navigate(rolePaths[form.role]);
    } else {
      setServerError(result.message);
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Header */}
      <header className="bg-white border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <Link to="/" className="flex items-center gap-2">
            <div className="w-10 h-10 bg-brand-600 rounded-lg flex items-center justify-center">
              <Leaf size={22} className="text-white" />
            </div>
            <h1 className="text-xl font-bold text-gray-900">IFWRRS</h1>
          </Link>
          <Link to="/" className="flex items-center gap-1 text-sm text-gray-600 hover:text-gray-900">
            <ArrowLeft size={16} /> Back to home
          </Link>
        </div>
      </header>

      <div className="flex-1 flex items-center justify-center py-12 px-4">
        <div className="w-full max-w-2xl">
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-gray-900">Create Your Account</h2>
            <p className="mt-2 text-gray-600">Join IFWRRS and start making a difference today</p>
          </div>

          {serverError && (
            <div className="mb-6 p-3 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2 text-sm text-red-700">
              <AlertCircle size={16} />
              <span>{serverError}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 lg:p-8 space-y-5">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Input
                label="Full Name"
                value={form.name}
                onChange={(e) => handleChange('name', e.target.value)}
                error={errors.name}
                placeholder="John Doe"
              />
              <Input
                label="Organization Name"
                value={form.organizationName}
                onChange={(e) => handleChange('organizationName', e.target.value)}
                error={errors.organizationName}
                placeholder="Green Leaf Restaurant"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Input
                label="Email"
                type="email"
                value={form.email}
                onChange={(e) => handleChange('email', e.target.value)}
                error={errors.email}
                placeholder="you@example.com"
              />
              <Input
                label="Phone"
                value={form.phone}
                onChange={(e) => handleChange('phone', e.target.value)}
                error={errors.phone}
                placeholder="+1-555-0100"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Input
                label="Password"
                type="password"
                value={form.password}
                onChange={(e) => handleChange('password', e.target.value)}
                error={errors.password}
                placeholder="Min 6 characters"
              />
              <Input
                label="Confirm Password"
                type="password"
                value={form.confirmPassword}
                onChange={(e) => handleChange('confirmPassword', e.target.value)}
                error={errors.confirmPassword}
                placeholder="Re-enter password"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Select
                label="User Role"
                value={form.role}
                onChange={(e) => handleChange('role', e.target.value)}
                options={roleOptions}
              />
              <Select
                label="Organization Type"
                value={form.organizationType}
                onChange={(e) => handleChange('organizationType', e.target.value)}
                options={orgTypeOptions}
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Input
                label="Address"
                value={form.address}
                onChange={(e) => handleChange('address', e.target.value)}
                error={errors.address}
                placeholder="123 Main Street"
              />
              <Input
                label="City"
                value={form.city}
                onChange={(e) => handleChange('city', e.target.value)}
                error={errors.city}
                placeholder="Metro City"
              />
            </div>

            <div className="pt-2">
              <Button type="submit" size="lg" className="w-full" disabled={loading}>
                {loading ? 'Creating account...' : 'Create Account'} <ArrowRight size={18} />
              </Button>
            </div>

            <p className="text-center text-sm text-gray-600">
              Already have an account?{' '}
              <Link to="/login" className="font-medium text-brand-600 hover:text-brand-700">
                Sign in
              </Link>
            </p>
          </form>
        </div>
      </div>
    </div>
  );
}
