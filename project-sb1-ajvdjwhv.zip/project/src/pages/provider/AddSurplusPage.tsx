import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { PlusCircle, AlertCircle, CheckCircle, MapPin } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useData } from '@/context/DataContext';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, Button, Input, Select, Textarea, PageHeader, Badge, ProgressBar } from '@/components/ui';
import { validateRequired, validatePositiveNumber, validateExpiryAfterPreparation } from '@/services/validation';
import { foodTypeList } from '@/services/analytics';
import { findBestMatches } from '@/services/matching';
import { calculateDistance } from '@/services/matching';
import type { FoodType, StorageRequirement, MatchResult } from '@/types';

export function AddSurplusPage() {
  const { user } = useAuth();
  const { addDonation, recipients, settings } = useData();
  const navigate = useNavigate();

  const [form, setForm] = useState({
    foodName: '',
    foodType: '' as FoodType | '',
    quantity: 0,
    unit: 'kg',
    preparationTime: '',
    expiryTime: '',
    storageRequirement: '' as StorageRequirement | '',
    pickupLocation: '',
    description: '',
    availabilityTime: '',
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [success, setSuccess] = useState(false);
  const [matches, setMatches] = useState<MatchResult[]>([]);

  if (!user) return null;

  const foodTypeOptions = foodTypeList.map((f) => ({ value: f, label: f }));
  const unitOptions = ['kg', 'meals', 'liters', 'pieces', 'loaves', 'cans', 'bottles', 'boxes'].map((u) => ({ value: u, label: u }));
  const storageOptions = [
    { value: 'Room Temperature', label: 'Room Temperature' },
    { value: 'Refrigerated', label: 'Refrigerated' },
    { value: 'Frozen', label: 'Frozen' },
    { value: 'Dry Storage', label: 'Dry Storage' },
  ];

  const handleChange = (field: string, value: string | number) => {
    setForm({ ...form, [field]: value });
    if (errors[field]) setErrors({ ...errors, [field]: '' });
  };

  const validate = (): boolean => {
    const newErrors: Record<string, string> = {};
    const nameErr = validateRequired(form.foodName, 'Food Name');
    if (nameErr) newErrors.foodName = nameErr;
    if (!form.foodType) newErrors.foodType = 'Food type is required';
    const qtyErr = validatePositiveNumber(form.quantity, 'Quantity');
    if (qtyErr) newErrors.quantity = qtyErr;
    if (!form.storageRequirement) newErrors.storageRequirement = 'Storage requirement is required';
    const locErr = validateRequired(form.pickupLocation, 'Pickup Location');
    if (locErr) newErrors.pickupLocation = locErr;
    const prepErr = validateRequired(form.preparationTime, 'Preparation Time');
    if (prepErr) newErrors.preparationTime = prepErr;
    const expiryErr = validateExpiryAfterPreparation(form.preparationTime, form.expiryTime);
    if (expiryErr) newErrors.expiryTime = expiryErr;
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    const donation = addDonation({
      providerId: user.organizationId,
      providerName: user.organizationName,
      foodName: form.foodName,
      foodType: form.foodType as FoodType,
      quantity: form.quantity,
      unit: form.unit,
      preparationTime: new Date(form.preparationTime).toISOString(),
      expiryTime: new Date(form.expiryTime).toISOString(),
      storageRequirement: form.storageRequirement as StorageRequirement,
      pickupLocation: form.pickupLocation,
      pickupLatitude: 40.7589 + (Math.random() - 0.5) * 0.05,
      pickupLongitude: -73.9851 + (Math.random() - 0.5) * 0.05,
      description: form.description,
      imageUrl: '',
      availabilityTime: new Date(form.availabilityTime || Date.now()).toISOString(),
    });

    // Calculate matches
    const tempDonation = {
      ...donation,
      urgency: 'Medium' as const,
    };
    const matchResults = findBestMatches(tempDonation, recipients, settings.matchWeights);
    setMatches(matchResults.slice(0, 5));
    setSuccess(true);
  };

  return (
    <DashboardLayout>
      <PageHeader title="Add Surplus Food" subtitle="Record surplus food for donation and find matched organizations" />

      {success && (
        <Card className="p-4 mb-6 bg-brand-50 border-brand-200">
          <div className="flex items-start gap-3">
            <CheckCircle size={20} className="text-brand-600 flex-shrink-0 mt-0.5" />
            <div className="flex-1">
              <p className="font-medium text-brand-900">Donation created successfully!</p>
              <p className="text-sm text-brand-700 mt-1">
                Recommended organizations have been found below. You can also view them in Smart Matching.
              </p>
              <div className="mt-3 flex gap-2">
                <Button size="sm" variant="primary" onClick={() => navigate('/provider/donations')}>View My Donations</Button>
                <Button size="sm" variant="outline" onClick={() => { setSuccess(false); setForm({ foodName: '', foodType: '', quantity: 0, unit: 'kg', preparationTime: '', expiryTime: '', storageRequirement: '', pickupLocation: '', description: '', availabilityTime: '' }); setMatches([]); }}>
                  Add Another
                </Button>
              </div>
            </div>
          </div>
        </Card>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Form */}
        <div className="lg:col-span-2">
          <Card className="p-6">
            <form onSubmit={handleSubmit} className="space-y-5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Input
                  label="Food Name"
                  value={form.foodName}
                  onChange={(e) => handleChange('foodName', e.target.value)}
                  error={errors.foodName}
                  placeholder="e.g., Vegetable Pasta"
                />
                <Select
                  label="Food Type"
                  value={form.foodType}
                  onChange={(e) => handleChange('foodType', e.target.value)}
                  options={foodTypeOptions}
                  placeholder="Select food type"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Input
                  label="Quantity"
                  type="number"
                  value={form.quantity || ''}
                  onChange={(e) => handleChange('quantity', parseFloat(e.target.value) || 0)}
                  error={errors.quantity}
                  placeholder="e.g., 50"
                />
                <Select
                  label="Unit"
                  value={form.unit}
                  onChange={(e) => handleChange('unit', e.target.value)}
                  options={unitOptions}
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Input
                  label="Preparation Date & Time"
                  type="datetime-local"
                  value={form.preparationTime}
                  onChange={(e) => handleChange('preparationTime', e.target.value)}
                  error={errors.preparationTime}
                />
                <Input
                  label="Expiry Date & Time"
                  type="datetime-local"
                  value={form.expiryTime}
                  onChange={(e) => handleChange('expiryTime', e.target.value)}
                  error={errors.expiryTime}
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Select
                  label="Storage Requirement"
                  value={form.storageRequirement}
                  onChange={(e) => handleChange('storageRequirement', e.target.value)}
                  options={storageOptions}
                  placeholder="Select storage type"
                />
                <Input
                  label="Availability Time"
                  type="datetime-local"
                  value={form.availabilityTime}
                  onChange={(e) => handleChange('availabilityTime', e.target.value)}
                  hint="When the food becomes available for pickup"
                />
              </div>

              <Input
                label="Pickup Location"
                value={form.pickupLocation}
                onChange={(e) => handleChange('pickupLocation', e.target.value)}
                error={errors.pickupLocation}
                placeholder="Full address for pickup"
              />

              <Textarea
                label="Description"
                value={form.description}
                onChange={(e) => handleChange('description', e.target.value)}
                placeholder="Additional details about the food..."
                rows={3}
              />

              <div className="flex gap-3 pt-2">
                <Button type="submit" size="lg"><PlusCircle size={18} /> Create Donation</Button>
                <Button type="button" variant="outline" size="lg" onClick={() => navigate('/provider')}>Cancel</Button>
              </div>
            </form>
          </Card>
        </div>

        {/* Matching sidebar */}
        <div className="space-y-4">
          <Card className="p-5">
            <h3 className="font-semibold text-gray-900 mb-2">Intelligent Matching</h3>
            <p className="text-sm text-gray-500 mb-4">
              When you submit a donation, the system automatically finds the best-matched organizations based on:
            </p>
            <div className="space-y-2 text-sm">
              {[
                { label: 'Location', weight: `${settings.matchWeights.location}%` },
                { label: 'Quantity', weight: `${settings.matchWeights.quantity}%` },
                { label: 'Urgency', weight: `${settings.matchWeights.urgency}%` },
                { label: 'Food Requirement', weight: `${settings.matchWeights.foodRequirement}%` },
                { label: 'Availability', weight: `${settings.matchWeights.availability}%` },
              ].map((c) => (
                <div key={c.label} className="flex items-center justify-between py-1.5 px-3 bg-gray-50 rounded-lg">
                  <span className="text-gray-600">{c.label}</span>
                  <Badge color="brand">{c.weight}</Badge>
                </div>
              ))}
            </div>
          </Card>

          {matches.length > 0 && (
            <Card className="p-5">
              <h3 className="font-semibold text-gray-900 mb-4">Recommended Organizations</h3>
              <div className="space-y-3">
                {matches.map((match, i) => (
                  <div key={match.organization.organizationId} className="p-3 border border-gray-200 rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-medium text-sm text-gray-900">{match.organization.organizationName}</span>
                      <Badge color={match.score >= 80 ? 'green' : match.score >= 60 ? 'amber' : 'red'}>{match.score}% Match</Badge>
                    </div>
                    <ProgressBar value={match.score} color={match.score >= 80 ? 'brand' : match.score >= 60 ? 'amber' : 'red'} />
                    <div className="flex items-center gap-1 mt-2 text-xs text-gray-500">
                      <MapPin size={12} /> {match.distance} km away
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          )}
        </div>
      </div>
    </DashboardLayout>
  );
}
