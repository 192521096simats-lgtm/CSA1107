import { useState, useMemo } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Package, Search, Trash2, Eye, PlusCircle, Inbox } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useData } from '@/context/DataContext';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, Button, Input, Select, DonationStatusBadge, UrgencyBadge, PageHeader, EmptyState, Modal, Badge } from '@/components/ui';
import { formatDateTime, countdownToExpiry } from '@/services/formatters';
import { foodTypeList } from '@/services/analytics';
import type { FoodDonation, DonationStatus } from '@/types';

export function MyDonationsPage() {
  const { user } = useAuth();
  const { donations, deleteDonation } = useData();
  const navigate = useNavigate();

  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [typeFilter, setTypeFilter] = useState('');
  const [urgencyFilter, setUrgencyFilter] = useState('');
  const [deleteTarget, setDeleteTarget] = useState<FoodDonation | null>(null);

  if (!user) return null;

  const myDonations = useMemo(() => {
    return donations
      .filter((d) => d.providerId === user.organizationId)
      .filter((d) => !search || d.foodName.toLowerCase().includes(search.toLowerCase()) || d.donationId.toLowerCase().includes(search.toLowerCase()))
      .filter((d) => !statusFilter || d.status === statusFilter)
      .filter((d) => !typeFilter || d.foodType === typeFilter)
      .filter((d) => !urgencyFilter || d.urgency === urgencyFilter)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }, [donations, user.organizationId, search, statusFilter, typeFilter, urgencyFilter]);

  const statusOptions = ['Available', 'Matched', 'Requested', 'Approved', 'Assigned', 'Picked Up', 'In Transit', 'Delivered', 'Distributed', 'Expired', 'Cancelled']
    .map((s) => ({ value: s, label: s }));
  const typeOptions = foodTypeList.map((f) => ({ value: f, label: f }));
  const urgencyOptions = ['Low', 'Medium', 'High', 'Critical'].map((u) => ({ value: u, label: u }));

  const canDelete = (status: DonationStatus) => status === 'Available' || status === 'Created' || status === 'Matched';

  const handleDelete = () => {
    if (deleteTarget) {
      deleteDonation(deleteTarget.donationId);
      setDeleteTarget(null);
    }
  };

  return (
    <DashboardLayout>
      <PageHeader
        title="My Donations"
        subtitle="Manage all your surplus food donations"
        action={
          <Link to="/provider/add-surplus">
            <Button><PlusCircle size={18} /> Add Surplus Food</Button>
          </Link>
        }
      />

      {/* Filters */}
      <Card className="p-4 mb-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          <div className="relative">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Search by name or ID..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-9 pr-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-brand-500"
            />
          </div>
          <Select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} options={statusOptions} placeholder="All Statuses" />
          <Select value={typeFilter} onChange={(e) => setTypeFilter(e.target.value)} options={typeOptions} placeholder="All Food Types" />
          <Select value={urgencyFilter} onChange={(e) => setUrgencyFilter(e.target.value)} options={urgencyOptions} placeholder="All Urgency Levels" />
        </div>
      </Card>

      {/* Table */}
      <Card className="overflow-hidden">
        {myDonations.length === 0 ? (
          <EmptyState icon={Inbox} title="No donations found" message="Try adjusting your filters or create a new surplus food donation." />
        ) : (
          <div className="overflow-x-auto table-scroll">
            <table className="w-full text-sm">
              <thead className="bg-gray-50 text-gray-600">
                <tr>
                  <th className="px-4 py-3 text-left font-medium">Donation ID</th>
                  <th className="px-4 py-3 text-left font-medium">Food Name</th>
                  <th className="px-4 py-3 text-left font-medium">Type</th>
                  <th className="px-4 py-3 text-left font-medium">Quantity</th>
                  <th className="px-4 py-3 text-left font-medium">Prepared</th>
                  <th className="px-4 py-3 text-left font-medium">Expires In</th>
                  <th className="px-4 py-3 text-left font-medium">Status</th>
                  <th className="px-4 py-3 text-left font-medium">Urgency</th>
                  <th className="px-4 py-3 text-left font-medium">Matched Org</th>
                  <th className="px-4 py-3 text-left font-medium">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {myDonations.map((d) => (
                  <tr key={d.donationId} className="hover:bg-gray-50">
                    <td className="px-4 py-3 font-medium text-gray-900">{d.donationId}</td>
                    <td className="px-4 py-3 text-gray-700">{d.foodName}</td>
                    <td className="px-4 py-3 text-gray-600">{d.foodType}</td>
                    <td className="px-4 py-3 text-gray-600">{d.quantity} {d.unit}</td>
                    <td className="px-4 py-3 text-gray-500 text-xs">{formatDateTime(d.preparationTime)}</td>
                    <td className="px-4 py-3 text-xs">
                      {d.status === 'Expired' ? <Badge color="red">Expired</Badge> : <span className="text-gray-600">{countdownToExpiry(d.expiryTime)}</span>}
                    </td>
                    <td className="px-4 py-3"><DonationStatusBadge status={d.status} /></td>
                    <td className="px-4 py-3"><UrgencyBadge urgency={d.urgency} /></td>
                    <td className="px-4 py-3 text-gray-600 text-xs">{d.matchedOrganizationName ?? '—'}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => navigate(`/provider/donations/${d.donationId}`)}
                          className="p-1.5 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                          title="View Details"
                        >
                          <Eye size={16} />
                        </button>
                        {canDelete(d.status) && (
                          <button
                            onClick={() => setDeleteTarget(d)}
                            className="p-1.5 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                            title="Cancel/Delete"
                          >
                            <Trash2 size={16} />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      {/* Delete confirmation */}
      <Modal open={!!deleteTarget} onClose={() => setDeleteTarget(null)} title="Cancel Donation" size="sm">
        <p className="text-sm text-gray-600">
          Are you sure you want to cancel and remove donation <strong>{deleteTarget?.donationId}</strong> ({deleteTarget?.foodName})?
          This action cannot be undone.
        </p>
        <div className="flex gap-3 mt-6 justify-end">
          <Button variant="outline" onClick={() => setDeleteTarget(null)}>Cancel</Button>
          <Button variant="danger" onClick={handleDelete}>Yes, Cancel Donation</Button>
        </div>
      </Modal>
    </DashboardLayout>
  );
}
