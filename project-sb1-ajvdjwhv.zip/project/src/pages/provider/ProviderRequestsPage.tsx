import { useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { ClipboardList, CheckCircle, XCircle, Eye, Inbox } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useData } from '@/context/DataContext';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, Button, RequestStatusBadge, UrgencyBadge, PageHeader, EmptyState } from '@/components/ui';
import { formatDateTime } from '@/services/formatters';

export function ProviderRequestsPage() {
  const { user } = useAuth();
  const { requests, donations, updateRequestStatus } = useData();
  const navigate = useNavigate();

  if (!user) return null;

  const myRequests = useMemo(() => {
    return requests
      .filter((r) => r.providerId === user.organizationId)
      .sort((a, b) => new Date(b.requestDate).getTime() - new Date(a.requestDate).getTime());
  }, [requests, user.organizationId]);

  const handleApprove = (requestId: string) => {
    updateRequestStatus(requestId, 'Approved');
  };

  const handleReject = (requestId: string) => {
    updateRequestStatus(requestId, 'Rejected');
  };

  return (
    <DashboardLayout>
      <PageHeader title="Requests" subtitle="Review and manage food requests from recipient organizations" />

      {myRequests.length === 0 ? (
        <Card className="p-6">
          <EmptyState icon={Inbox} title="No requests yet" message="When recipient organizations request your donations, they will appear here." />
        </Card>
      ) : (
        <div className="space-y-4">
          {myRequests.map((req) => {
            const donation = donations.find((d) => d.donationId === req.donationId);
            return (
              <Card key={req.requestId} className="p-5">
                <div className="flex flex-col lg:flex-row gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-3">
                      <h3 className="font-semibold text-gray-900">{req.requestId}</h3>
                      <RequestStatusBadge status={req.status} />
                      <UrgencyBadge urgency={req.priority} />
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-sm">
                      <div>
                        <p className="text-xs text-gray-500">Organization</p>
                        <p className="font-medium text-gray-700">{req.organizationName}</p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-500">Food Item</p>
                        <p className="font-medium text-gray-700">{donation?.foodName ?? 'N/A'}</p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-500">Requested Qty</p>
                        <p className="font-medium text-gray-700">{req.requestedQuantity} {donation?.unit ?? ''}</p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-500">Preferred Pickup</p>
                        <p className="font-medium text-gray-700 text-xs">{req.preferredPickupTime ? formatDateTime(req.preferredPickupTime) : 'Anytime'}</p>
                      </div>
                    </div>
                    {req.reason && (
                      <div className="mt-3 p-3 bg-gray-50 rounded-lg">
                        <p className="text-xs text-gray-500 mb-1">Reason</p>
                        <p className="text-sm text-gray-700">{req.reason}</p>
                      </div>
                    )}
                    {req.notes && (
                      <div className="mt-2 p-3 bg-blue-50 rounded-lg">
                        <p className="text-xs text-blue-500 mb-1">Notes</p>
                        <p className="text-sm text-blue-700">{req.notes}</p>
                      </div>
                    )}
                  </div>

                  <div className="flex flex-row lg:flex-col gap-2 lg:w-40">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => navigate(`/provider/donations/${req.donationId}`)}
                    >
                      <Eye size={14} /> View Donation
                    </Button>
                    {req.status === 'Pending' && (
                      <>
                        <Button size="sm" variant="primary" onClick={() => handleApprove(req.requestId)}>
                          <CheckCircle size={14} /> Approve
                        </Button>
                        <Button size="sm" variant="danger" onClick={() => handleReject(req.requestId)}>
                          <XCircle size={14} /> Reject
                        </Button>
                      </>
                    )}
                  </div>
                </div>
              </Card>
            );
          })}
        </div>
      )}
    </DashboardLayout>
  );
}
