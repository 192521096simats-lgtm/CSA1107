import { useState, useMemo } from 'react';
import { Target, MapPin, Send, Eye, Search, Inbox } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useData } from '@/context/DataContext';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, Button, Select, Badge, PageHeader, EmptyState, ProgressBar, Modal } from '@/components/ui';
import { MatchScoreGauge } from '@/components/charts/Charts';
import { calculateDistance } from '@/services/matching';
import { formatDateTime, countdownToExpiry } from '@/services/formatters';
import type { FoodDonation, MatchResult } from '@/types';

export function SmartMatchingPage() {
  const { user } = useAuth();
  const { donations, recipients, settings, addNotification } = useData();
  const [selectedDonationId, setSelectedDonationId] = useState<string>('');
  const [orgModal, setOrgModal] = useState<MatchResult | null>(null);

  if (!user) return null;

  const myDonations = useMemo(
    () => donations.filter((d) => d.providerId === user.organizationId && (d.status === 'Available' || d.status === 'Matched')),
    [donations, user.organizationId],
  );

  const selectedDonation = myDonations.find((d) => d.donationId === selectedDonationId) ?? myDonations[0];

  const matches = useMemo(() => {
    if (!selectedDonation) return [];
    return recipients
      .filter((r) => r.availability)
      .map((org) => {
        const distance = calculateDistance(
          selectedDonation.pickupLatitude,
          selectedDonation.pickupLongitude,
          org.latitude,
          org.longitude,
        );
        const locationScore = Math.max(0, Math.min(100, 100 - (distance / 50) * 100));
        const quantityRatio = selectedDonation.quantity / org.capacity;
        const quantityScore = Math.min(100, quantityRatio * 100 * 2);
        const urgencyMap = { Critical: 100, High: 80, Medium: 60, Low: 40 } as const;
        const urgencyScore = urgencyMap[selectedDonation.urgency] ?? 50;
        const foodScore = org.foodRequirements.includes(selectedDonation.foodType) ? 100 : 30;
        const availabilityScore = org.availability ? 100 : 0;
        const score = Math.round(
          (locationScore * settings.matchWeights.location +
            quantityScore * settings.matchWeights.quantity +
            urgencyScore * settings.matchWeights.urgency +
            foodScore * settings.matchWeights.foodRequirement +
            availabilityScore * settings.matchWeights.availability) / 100,
        );
        return { organization: org, score, distance, details: { locationScore: Math.round(locationScore), quantityScore: Math.round(quantityScore), urgencyScore, foodScore, availabilityScore } };
      })
      .sort((a, b) => b.score - a.score);
  }, [selectedDonation, recipients, settings.matchWeights]);

  const handleSendOffer = (match: MatchResult) => {
    addNotification({
      userId: match.organization.userId,
      type: 'info',
      title: 'Donation Offer Received',
      message: `${user.organizationName} has sent you a donation offer for ${selectedDonation?.foodName} (${selectedDonation?.quantity} ${selectedDonation?.unit}). Check available donations to request.`,
      relatedId: selectedDonation?.donationId ?? null,
    });
    setOrgModal(null);
  };

  return (
    <DashboardLayout>
      <PageHeader title="Smart Food Matching" subtitle="AI-powered matching of your donations with recipient organizations" />

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Donation selector */}
        <div className="lg:col-span-1">
          <Card className="p-4">
            <h3 className="font-semibold text-gray-900 mb-3 text-sm">Select a Donation</h3>
            {myDonations.length === 0 ? (
              <p className="text-sm text-gray-500">No available donations to match.</p>
            ) : (
              <div className="space-y-2 max-h-[500px] overflow-y-auto scrollbar-thin">
                {myDonations.map((d) => (
                  <button
                    key={d.donationId}
                    onClick={() => setSelectedDonationId(d.donationId)}
                    className={`w-full text-left p-3 rounded-lg border transition-colors ${
                      selectedDonation?.donationId === d.donationId
                        ? 'border-brand-500 bg-brand-50'
                        : 'border-gray-200 hover:bg-gray-50'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs font-medium text-gray-500">{d.donationId}</span>
                      <Badge color={d.urgency === 'Critical' ? 'red' : d.urgency === 'High' ? 'amber' : 'gray'}>{d.urgency}</Badge>
                    </div>
                    <p className="text-sm font-medium text-gray-900 truncate">{d.foodName}</p>
                    <p className="text-xs text-gray-500 mt-1">{d.quantity} {d.unit} · {countdownToExpiry(d.expiryTime)}</p>
                  </button>
                ))}
              </div>
            )}
          </Card>
        </div>

        {/* Match results */}
        <div className="lg:col-span-3">
          {!selectedDonation ? (
            <Card className="p-6">
              <EmptyState icon={Inbox} title="No donations to match" message="Create a surplus food donation first, then come back here to find matched organizations." />
            </Card>
          ) : (
            <>
              <Card className="p-5 mb-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <h3 className="font-semibold text-gray-900">{selectedDonation.foodName}</h3>
                    <p className="text-sm text-gray-500 mt-1">
                      {selectedDonation.donationId} · {selectedDonation.quantity} {selectedDonation.unit} · {selectedDonation.foodType}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-xs text-gray-500">Expires In</p>
                    <p className={`font-semibold ${selectedDonation.urgency === 'Critical' ? 'text-red-600' : 'text-gray-900'}`}>
                      {countdownToExpiry(selectedDonation.expiryTime)}
                    </p>
                  </div>
                </div>
              </Card>

              <div className="space-y-3">
                {matches.map((match, i) => (
                  <Card key={match.organization.organizationId} className="p-5">
                    <div className="flex flex-col sm:flex-row gap-4">
                      {/* Score gauge */}
                      <div className="flex-shrink-0 flex items-center justify-center">
                        <MatchScoreGauge score={match.score} />
                      </div>

                      {/* Details */}
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between mb-3">
                          <div>
                            <h4 className="font-semibold text-gray-900">{match.organization.organizationName}</h4>
                            <p className="text-sm text-gray-500">{match.organization.organizationType} · {match.organization.peopleServed} people served</p>
                          </div>
                          <Badge color={match.score >= 80 ? 'green' : match.score >= 60 ? 'amber' : 'red'}>
                            {match.score}% Match
                          </Badge>
                        </div>

                        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mb-4">
                          <div className="flex items-center gap-2 text-sm">
                            <MapPin size={14} className="text-gray-400" />
                            <div>
                              <p className="text-xs text-gray-500">Distance</p>
                              <p className="font-medium text-gray-700">{match.distance} km</p>
                            </div>
                          </div>
                          <div className="text-sm">
                            <p className="text-xs text-gray-500">Required Qty</p>
                            <p className="font-medium text-gray-700">Up to {match.organization.capacity} {selectedDonation.unit}</p>
                          </div>
                          <div className="text-sm">
                            <p className="text-xs text-gray-500">Food Type</p>
                            <p className="font-medium text-gray-700">{selectedDonation.foodType}</p>
                          </div>
                          <div className="text-sm">
                            <p className="text-xs text-gray-500">Storage</p>
                            <p className="font-medium text-gray-700">{selectedDonation.storageRequirement}</p>
                          </div>
                          <div className="text-sm">
                            <p className="text-xs text-gray-500">Urgency</p>
                            <p className="font-medium text-gray-700">{selectedDonation.urgency}</p>
                          </div>
                          <div className="text-sm">
                            <p className="text-xs text-gray-500">Availability</p>
                            <p className="font-medium text-brand-600">{match.organization.availability ? 'Available' : 'Unavailable'}</p>
                          </div>
                        </div>

                        {/* Score breakdown */}
                        <div className="grid grid-cols-5 gap-2 mb-4">
                          {[
                            { label: 'Location', val: match.details.locationScore },
                            { label: 'Quantity', val: match.details.quantityScore },
                            { label: 'Urgency', val: match.details.urgencyScore },
                            { label: 'Food', val: match.details.foodScore },
                            { label: 'Avail.', val: match.details.availabilityScore },
                          ].map((s) => (
                            <div key={s.label}>
                              <div className="flex justify-between text-[10px] text-gray-500 mb-1">
                                <span>{s.label}</span>
                                <span>{s.val}</span>
                              </div>
                              <ProgressBar value={s.val} className="h-1" />
                            </div>
                          ))}
                        </div>

                        <div className="flex gap-2">
                          <Button size="sm" variant="outline" onClick={() => setOrgModal(match)}>
                            <Eye size={14} /> View Organization
                          </Button>
                          <Button size="sm" onClick={() => handleSendOffer(match)}>
                            <Send size={14} /> Send Donation Offer
                          </Button>
                        </div>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            </>
          )}
        </div>
      </div>

      {/* Organization detail modal */}
      <Modal open={!!orgModal} onClose={() => setOrgModal(null)} title="Organization Details" size="md">
        {orgModal && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-semibold text-gray-900 text-lg">{orgModal.organization.organizationName}</h3>
                <p className="text-sm text-gray-500">{orgModal.organization.organizationType}</p>
              </div>
              <MatchScoreGauge score={orgModal.score} size={80} />
            </div>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div><p className="text-xs text-gray-500">Address</p><p className="text-gray-700">{orgModal.organization.address}</p></div>
              <div><p className="text-xs text-gray-500">Operating Hours</p><p className="text-gray-700">{orgModal.organization.operatingHours}</p></div>
              <div><p className="text-xs text-gray-500">Capacity</p><p className="text-gray-700">{orgModal.organization.capacity} units</p></div>
              <div><p className="text-xs text-gray-500">People Served</p><p className="text-gray-700">{orgModal.organization.peopleServed}</p></div>
              <div><p className="text-xs text-gray-500">Contact</p><p className="text-gray-700">{orgModal.organization.contactName}</p></div>
              <div><p className="text-xs text-gray-500">Phone</p><p className="text-gray-700">{orgModal.organization.contactPhone}</p></div>
            </div>
            <div>
              <p className="text-xs text-gray-500 mb-2">Food Requirements</p>
              <div className="flex flex-wrap gap-2">
                {orgModal.organization.foodRequirements.map((f) => (
                  <Badge key={f} color="teal">{f}</Badge>
                ))}
              </div>
            </div>
            <div className="flex gap-3 pt-2">
              <Button onClick={() => handleSendOffer(orgModal)}><Send size={16} /> Send Donation Offer</Button>
              <Button variant="outline" onClick={() => setOrgModal(null)}>Close</Button>
            </div>
          </div>
        )}
      </Modal>
    </DashboardLayout>
  );
}
