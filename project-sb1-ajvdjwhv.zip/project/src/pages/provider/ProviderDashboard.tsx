import { Link } from 'react-router-dom';
import {
  Package, CheckCircle2, Clock, TrendingUp, PlusCircle, Utensils, Truck,
} from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useData } from '@/context/DataContext';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, StatCard, Button, DonationStatusBadge, UrgencyBadge, PageHeader } from '@/components/ui';
import { DonutChart, BarChartViz, LineChartViz } from '@/components/charts/Charts';
import { donationsByFoodType, donationsByStatus, weeklyRedistribution } from '@/services/analytics';
import { formatDateTime, countdownToExpiry } from '@/services/formatters';

export function ProviderDashboard() {
  const { user } = useAuth();
  const { donations } = useData();

  if (!user) return null;
  const myDonations = donations.filter((d) => d.providerId === user.organizationId);

  const total = myDonations.length;
  const available = myDonations.filter((d) => d.status === 'Available').length;
  const matched = myDonations.filter((d) => d.status === 'Matched' || d.status === 'Requested' || d.status === 'Approved').length;
  const redistributed = myDonations.filter((d) => d.status === 'Distributed' || d.status === 'Delivered').length;
  const expiringSoon = myDonations.filter((d) => {
    if (d.status === 'Expired' || d.status === 'Distributed' || d.status === 'Cancelled') return false;
    const hours = (new Date(d.expiryTime).getTime() - Date.now()) / (1000 * 60 * 60);
    return hours > 0 && hours <= 24;
  }).length;

  const recentDonations = [...myDonations].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt()).getTime()).slice(0, 5);

  return (
    <DashboardLayout>
      <PageHeader
        title="Dashboard"
        subtitle={`Welcome back, ${user.name}`}
        action={
          <Link to="/provider/add-surplus">
            <Button><PlusCircle size={18} /> Add Surplus Food</Button>
          </Link>
        }
      />

      {/* Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-5 gap-4 mb-6">
        <StatCard label="Total Donations" value={total} icon={Package} color="brand" />
        <StatCard label="Available Food" value={available} icon={Utensils} color="blue" />
        <StatCard label="Matched Donations" value={matched} icon={CheckCircle2} color="teal" />
        <StatCard label="Food Redistributed" value={redistributed} icon={TrendingUp} color="brand" />
        <StatCard label="Expiring Soon" value={expiringSoon} icon={Clock} color="red" />
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        <Card className="p-5">
          <h3 className="font-semibold text-gray-900 mb-4">Donations by Food Type</h3>
          <DonutChart data={donationsByFoodType(myDonations)} />
        </Card>
        <Card className="p-5">
          <h3 className="font-semibold text-gray-900 mb-4">Weekly Food Redistribution</h3>
          <BarChartViz data={weeklyRedistribution(myDonations)} />
        </Card>
        <Card className="p-5">
          <h3 className="font-semibold text-gray-900 mb-4">Donation Status Distribution</h3>
          <DonutChart data={donationsByStatus(myDonations)} />
        </Card>
      </div>

      {/* Recent Donations Table */}
      <Card className="overflow-hidden">
        <div className="px-5 py-4 border-b border-gray-200 flex items-center justify-between">
          <h3 className="font-semibold text-gray-900">Recent Donations</h3>
          <Link to="/provider/donations" className="text-sm text-brand-600 hover:text-brand-700 font-medium">
            View All
          </Link>
        </div>
        <div className="overflow-x-auto table-scroll">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 text-gray-600">
              <tr>
                <th className="px-4 py-3 text-left font-medium">Donation ID</th>
                <th className="px-4 py-3 text-left font-medium">Food Type</th>
                <th className="px-4 py-3 text-left font-medium">Quantity</th>
                <th className="px-4 py-3 text-left font-medium">Prepared</th>
                <th className="px-4 py-3 text-left font-medium">Expires In</th>
                <th className="px-4 py-3 text-left font-medium">Status</th>
                <th className="px-4 py-3 text-left font-medium">Matched Org</th>
                <th className="px-4 py-3 text-left font-medium">Urgency</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {recentDonations.map((d) => (
                <tr key={d.donationId} className="hover:bg-gray-50">
                  <td className="px-4 py-3 font-medium text-gray-900">{d.donationId}</td>
                  <td className="px-4 py-3 text-gray-600">{d.foodType}</td>
                  <td className="px-4 py-3 text-gray-600">{d.quantity} {d.unit}</td>
                  <td className="px-4 py-3 text-gray-600 text-xs">{formatDateTime(d.preparationTime)}</td>
                  <td className="px-4 py-3 text-gray-600 text-xs">
                    {d.status === 'Expired' ? <span className="text-red-600 font-medium">Expired</span> : countdownToExpiry(d.expiryTime)}
                  </td>
                  <td className="px-4 py-3"><DonationStatusBadge status={d.status} /></td>
                  <td className="px-4 py-3 text-gray-600 text-xs">{d.matchedOrganizationName ?? '—'}</td>
                  <td className="px-4 py-3"><UrgencyBadge urgency={d.urgency} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </DashboardLayout>
  );
}
