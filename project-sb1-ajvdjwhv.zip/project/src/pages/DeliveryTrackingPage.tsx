import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, MapPin, Truck, Package, User, Clock, CheckCircle, Circle, Navigation } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useData } from '@/context/DataContext';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, Button, DeliveryStatusBadge, PageHeader, Badge } from '@/components/ui';
import { formatDateTime } from '@/services/formatters';
import type { DeliveryStatus } from '@/types';

const TIMELINE: DeliveryStatus[] = [
  'Assigned',
  'Accepted',
  'Pickup Started',
  'Picked Up',
  'In Transit',
  'Delivered',
  'Confirmed',
];

export function DeliveryTrackingPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { getDelivery, updateDeliveryStatus } = useData();

  if (!user || !id) return null;
  const delivery = getDelivery(id);

  if (!delivery) {
    return (
      <DashboardLayout>
        <Card className="p-8 text-center">
          <p className="text-gray-500">Delivery not found.</p>
          <Button className="mt-4" variant="outline" onClick={() => navigate(-1)}>Go Back</Button>
        </Card>
      </DashboardLayout>
    );
  }

  const currentIdx = TIMELINE.indexOf(delivery.status);
  const isDeliveryPartner = user.role === 'delivery' && delivery.partnerId === user.userId;
  const isRecipient = user.role === 'recipient' && delivery.recipientId === user.organizationId;

  const nextStatusMap: Record<DeliveryStatus, DeliveryStatus | null> = {
    Assigned: 'Accepted',
    Accepted: 'Pickup Started',
    Rejected: null,
    'Pickup Started': 'Picked Up',
    'Picked Up': 'In Transit',
    'In Transit': 'Delivered',
    Delivered: 'Confirmed',
    Confirmed: null,
    Cancelled: null,
  };

  const nextStatus = nextStatusMap[delivery.status];
  const canAct = (isDeliveryPartner || isRecipient) && nextStatus !== null && delivery.status !== 'Rejected' && delivery.status !== 'Cancelled';

  const actionLabels: Record<DeliveryStatus, string> = {
    Assigned: 'Accept Assignment',
    Accepted: 'Start Pickup',
    'Pickup Started': 'Mark Picked Up',
    'Picked Up': 'Start Delivery',
    'In Transit': 'Mark Delivered',
    Delivered: 'Confirm Collection',
    Confirmed: '',
    Rejected: '',
    Cancelled: '',
  };

  return (
    <DashboardLayout>
      <PageHeader
        title={`Delivery ${delivery.deliveryId}`}
        subtitle={`${delivery.foodName} · ${delivery.quantity} ${delivery.unit}`}
        action={<Button variant="outline" onClick={() => navigate(-1)}><ArrowLeft size={16} /> Back</Button>}
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Timeline */}
        <div className="lg:col-span-2">
          <Card className="p-6">
            <h3 className="font-semibold text-gray-900 mb-6">Delivery Timeline</h3>
            <div className="space-y-0">
              {TIMELINE.map((status, i) => {
                const isCompleted = i < currentIdx || delivery.status === 'Confirmed';
                const isCurrent = i === currentIdx;
                const isPending = i > currentIdx;
                return (
                  <div key={status} className="flex items-start gap-4 relative">
                    {/* Line */}
                    {i < TIMELINE.length - 1 && (
                      <div className={`absolute left-4 top-8 w-0.5 h-12 ${isCompleted ? 'bg-brand-500' : 'bg-gray-200'}`} />
                    )}
                    {/* Icon */}
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 z-10 ${
                      isCompleted ? 'bg-brand-500 text-white' :
                      isCurrent ? 'bg-brand-100 text-brand-600 ring-2 ring-brand-500' :
                      'bg-gray-100 text-gray-400'
                    }`}>
                      {isCompleted ? <CheckCircle size={16} /> : <Circle size={16} />}
                    </div>
                    {/* Content */}
                    <div className={`pb-6 ${isPending ? 'opacity-50' : ''}`}>
                      <p className={`text-sm font-medium ${isCurrent ? 'text-brand-700' : isCompleted ? 'text-gray-900' : 'text-gray-500'}`}>
                        {status}
                      </p>
                      {isCurrent && (
                        <p className="text-xs text-brand-600 mt-0.5">Current status</p>
                      )}
                      {status === 'Assigned' && delivery.assignedTime && (
                        <p className="text-xs text-gray-400 mt-0.5">{formatDateTime(delivery.assignedTime)}</p>
                      )}
                      {status === 'Picked Up' && delivery.pickupTime && (
                        <p className="text-xs text-gray-400 mt-0.5">{formatDateTime(delivery.pickupTime)}</p>
                      )}
                      {status === 'Delivered' && delivery.deliveryTime && (
                        <p className="text-xs text-gray-400 mt-0.5">{formatDateTime(delivery.deliveryTime)}</p>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>

            {canAct && (
              <div className="mt-6 pt-6 border-t border-gray-100">
                <Button onClick={() => updateDeliveryStatus(delivery.deliveryId, nextStatus!)}>
                  <CheckCircle size={16} /> {actionLabels[delivery.status]}
                </Button>
              </div>
            )}

            {delivery.status === 'Delivered' && isRecipient && (
              <div className="mt-6 pt-6 border-t border-gray-100">
                <Badge color="green"><CheckCircle size={12} className="inline mr-1" /> Awaiting your confirmation</Badge>
              </div>
            )}
          </Card>
        </div>

        {/* Delivery details */}
        <div className="space-y-4">
          <Card className="p-5">
            <h3 className="font-semibold text-gray-900 mb-4">Delivery Details</h3>
            <div className="space-y-3 text-sm">
              <div className="flex items-center gap-2">
                <span className="text-gray-500">Status:</span>
                <DeliveryStatusBadge status={delivery.status} />
              </div>
              <div className="flex items-start gap-2">
                <User size={14} className="text-gray-400 mt-0.5" />
                <div>
                  <p className="text-xs text-gray-500">Delivery Partner</p>
                  <p className="text-gray-700">{delivery.partnerName}</p>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <Package size={14} className="text-gray-400 mt-0.5" />
                <div>
                  <p className="text-xs text-gray-500">Food</p>
                  <p className="text-gray-700">{delivery.foodName} ({delivery.foodType})</p>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <Navigation size={14} className="text-gray-400 mt-0.5" />
                <div>
                  <p className="text-xs text-gray-500">Distance</p>
                  <p className="text-gray-700">{delivery.distance} km</p>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <Clock size={14} className="text-gray-400 mt-0.5" />
                <div>
                  <p className="text-xs text-gray-500">Estimated Delivery</p>
                  <p className="text-gray-700 text-xs">{formatDateTime(delivery.estimatedDeliveryTime)}</p>
                </div>
              </div>
            </div>
          </Card>

          <Card className="p-5">
            <h3 className="font-semibold text-gray-900 mb-4">Locations</h3>
            <div className="space-y-4">
              <div className="flex items-start gap-2">
                <div className="w-8 h-8 bg-blue-50 rounded-lg flex items-center justify-center flex-shrink-0">
                  <MapPin size={16} className="text-blue-600" />
                </div>
                <div>
                  <p className="text-xs text-gray-500">Pickup Location</p>
                  <p className="text-sm text-gray-700">{delivery.pickupLocation}</p>
                  <p className="text-xs text-gray-400 mt-0.5">{delivery.providerName}</p>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <div className="w-8 h-8 bg-brand-50 rounded-lg flex items-center justify-center flex-shrink-0">
                  <Truck size={16} className="text-brand-600" />
                </div>
                <div>
                  <p className="text-xs text-gray-500">Destination</p>
                  <p className="text-sm text-gray-700">{delivery.destination}</p>
                  <p className="text-xs text-gray-400 mt-0.5">{delivery.recipientName}</p>
                </div>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
}
