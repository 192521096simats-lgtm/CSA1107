import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Leaf, Mail, Lock, Users, ArrowRight, AlertCircle, Info } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { Button, Input, Select } from '@/components/ui';
import type { UserRole } from '@/types';

export function LoginPage() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState<UserRole>('provider');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const roleOptions = [
    { value: 'provider', label: 'Food Provider' },
    { value: 'recipient', label: 'Recipient Organization' },
    { value: 'delivery', label: 'Delivery Partner' },
    { value: 'admin', label: 'Administrator' },
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    const result = login(email, password, role);
    if (result.success) {
      // Navigate based on role
      const rolePaths: Record<UserRole, string> = {
        provider: '/provider',
        recipient: '/recipient',
        delivery: '/delivery',
        admin: '/admin',
      };
      navigate(rolePaths[role]);
    } else {
      setError(result.message);
    }
    setLoading(false);
  };

  const fillCredentials = (emailVal: string, roleVal: UserRole) => {
    setEmail(emailVal);
    setPassword('password123');
    setRole(roleVal);
  };

  return (
    <div className="min-h-screen flex flex-col lg:flex-row">
      {/* Left side - branding */}
      <div className="lg:w-1/2 bg-gradient-to-br from-brand-700 via-brand-800 to-brand-900 p-8 lg:p-12 flex flex-col justify-between relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-brand-600/20 rounded-full blur-3xl" />
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-brand-500/10 rounded-full blur-3xl" />

        <div className="relative">
          <Link to="/" className="flex items-center gap-3">
            <div className="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center backdrop-blur-sm">
              <Leaf size={26} className="text-white" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-white leading-none">IFWRRS</h1>
              <p className="text-xs text-brand-200 mt-1">Intelligent Food Waste Reduction & Redistribution</p>
            </div>
          </Link>
        </div>

        <div className="relative my-12 lg:my-0">
          <h2 className="text-3xl lg:text-4xl font-bold text-white leading-tight">
            Welcome back to the future of food redistribution
          </h2>
          <p className="mt-4 text-brand-200 text-lg leading-relaxed">
            Sign in to manage your donations, track deliveries, and make a real impact on reducing food waste.
          </p>
          <div className="mt-8 space-y-3">
            {['Smart matching algorithm', 'Real-time expiry tracking', 'Complete delivery lifecycle', 'Comprehensive analytics'].map((feat) => (
              <div key={feat} className="flex items-center gap-3 text-brand-100">
                <div className="w-5 h-5 bg-brand-500 rounded-full flex items-center justify-center flex-shrink-0">
                  <Leaf size={12} className="text-white" />
                </div>
                <span className="text-sm">{feat}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="relative text-brand-300 text-sm">
          <p>"Turning Surplus Food into Shared Resources"</p>
        </div>
      </div>

      {/* Right side - form */}
      <div className="lg:w-1/2 flex items-center justify-center p-8 lg:p-12 bg-gray-50">
        <div className="w-full max-w-md">
          <h2 className="text-2xl font-bold text-gray-900">Sign In</h2>
          <p className="mt-2 text-sm text-gray-600">Enter your credentials to access your dashboard</p>

          {/* Demo credentials */}
          <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
            <div className="flex items-start gap-2">
              <Info size={16} className="text-blue-600 flex-shrink-0 mt-0.5" />
              <div className="flex-1">
                <p className="text-xs font-medium text-blue-900 mb-2">Demo Credentials (password: password123)</p>
                <div className="grid grid-cols-2 gap-1.5 text-xs">
                  <button onClick={() => fillCredentials('admin@ifwrrs.com', 'admin')} className="text-left text-blue-700 hover:text-blue-900 hover:underline">
                    Admin
                  </button>
                  <button onClick={() => fillCredentials('provider@ifwrrs.com', 'provider')} className="text-left text-blue-700 hover:text-blue-900 hover:underline">
                    Provider
                  </button>
                  <button onClick={() => fillCredentials('recipient@ifwrrs.com', 'recipient')} className="text-left text-blue-700 hover:text-blue-900 hover:underline">
                    Recipient
                  </button>
                  <button onClick={() => fillCredentials('delivery@ifwrrs.com', 'delivery')} className="text-left text-blue-700 hover:text-blue-900 hover:underline">
                    Delivery
                  </button>
                </div>
              </div>
            </div>
          </div>

          {error && (
            <div className="mt-4 p-3 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2 text-sm text-red-700">
              <AlertCircle size={16} />
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="mt-6 space-y-4">
            <div className="space-y-1">
              <label className="block text-sm font-medium text-gray-700">Email</label>
              <div className="relative">
                <Mail size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@example.com"
                  required
                  className="w-full pl-10 pr-3 py-2.5 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-transparent"
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="block text-sm font-medium text-gray-700">Password</label>
              <div className="relative">
                <Lock size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter your password"
                  required
                  className="w-full pl-10 pr-3 py-2.5 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-transparent"
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="block text-sm font-medium text-gray-700">Role</label>
              <div className="relative">
                <Users size={18} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 z-10" />
                <select
                  value={role}
                  onChange={(e) => setRole(e.target.value as UserRole)}
                  className="w-full pl-10 pr-3 py-2.5 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-brand-500 focus:border-transparent bg-white appearance-none"
                >
                  {roleOptions.map((opt) => (
                    <option key={opt.value} value={opt.value}>{opt.label}</option>
                  ))}
                </select>
              </div>
            </div>

            <Button type="submit" size="lg" className="w-full" disabled={loading}>
              {loading ? 'Signing in...' : 'Login'} <ArrowRight size={18} />
            </Button>
          </form>

          <p className="mt-6 text-center text-sm text-gray-600">
            Don't have an account?{' '}
            <Link to="/register" className="font-medium text-brand-600 hover:text-brand-700">
              Create Account
            </Link>
          </p>

          <div className="mt-6 text-center">
            <Link to="/" className="text-sm text-gray-500 hover:text-gray-700">
              Back to home
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
