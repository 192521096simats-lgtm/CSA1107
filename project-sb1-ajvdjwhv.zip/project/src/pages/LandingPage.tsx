import { Link } from 'react-router-dom';
import {
  Leaf, ArrowRight, Utensils, Truck, Building2, HeartHandshake, Store, Package,
  Users, MapPin, Clock, Brain, Search, HandHeart, Sparkles, CheckCircle2,
  Recycle, Shield, TrendingUp,
} from 'lucide-react';
import { useData } from '@/context/DataContext';

export function LandingPage() {
  const { donations, recipients, providers, deliveries, distributions } = useData();

  const foodSaved = donations.reduce((sum, d) => {
    if (d.status === 'Distributed' || d.status === 'Delivered') return sum + d.quantity;
    return sum;
  }, 0);
  const mealsRedistributed = distributions.reduce((sum, d) => sum + d.distributedQuantity, 0) + foodSaved;
  const successfulDeliveries = deliveries.filter((d) => d.status === 'Delivered' || d.status === 'Confirmed').length;

  const stats = [
    { label: 'Food Saved', value: `${foodSaved}+ kg`, icon: Package, color: 'text-brand-600 bg-brand-50' },
    { label: 'Meals Redistributed', value: `${mealsRedistributed}+`, icon: Utensils, color: 'text-blue-600 bg-blue-50' },
    { label: 'Active Providers', value: providers.length, icon: Store, color: 'text-accent-600 bg-accent-50' },
    { label: 'Recipient Organizations', value: recipients.length, icon: HeartHandshake, color: 'text-purple-600 bg-purple-50' },
    { label: 'Successful Deliveries', value: successfulDeliveries, icon: Truck, color: 'text-teal-600 bg-teal-50' },
  ];

  const steps = [
    { icon: Store, title: 'Providers Record Surplus', desc: 'Restaurants, hotels, and supermarkets list surplus food with expiry details.' },
    { icon: Brain, title: 'AI-Based Matching', desc: 'Smart algorithm matches donations with nearby organizations based on compatibility.' },
    { icon: HandHeart, title: 'Organizations Request Food', desc: 'Recipients browse available donations and submit requests for needed items.' },
    { icon: Truck, title: 'Delivery Partner Collects', desc: 'Delivery partners pick up food and transport it to the recipient organization.' },
    { icon: Users, title: 'Food Gets Redistributed', desc: 'Organizations distribute food to people in need, reducing waste and hunger.' },
  ];

  const userTypes = [
    { icon: Utensils, title: 'Restaurants', desc: 'Donate surplus prepared food from daily service', color: 'bg-brand-50 text-brand-600' },
    { icon: Building2, title: 'Hotels', desc: 'Redistribute leftover food from events and buffets', color: 'bg-blue-50 text-blue-600' },
    { icon: Store, title: 'Supermarkets', desc: 'Share near-expiry products with the community', color: 'bg-accent-50 text-accent-600' },
    { icon: Package, title: 'Food Suppliers', desc: 'Donate excess inventory before it spoils', color: 'bg-purple-50 text-purple-600' },
    { icon: HeartHandshake, title: 'Charitable Organizations', desc: 'Receive and distribute food to those in need', color: 'bg-teal-50 text-teal-600' },
    { icon: Truck, title: 'Delivery Partners', desc: 'Transport food safely from providers to recipients', color: 'bg-red-50 text-red-600' },
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-white/90 backdrop-blur-sm border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-2">
              <div className="w-10 h-10 bg-brand-600 rounded-lg flex items-center justify-center">
                <Leaf size={22} className="text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900 leading-none">IFWRRS</h1>
                <p className="text-[10px] text-gray-500 mt-0.5">Food Redistribution System</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Link to="/login" className="text-sm font-medium text-gray-600 hover:text-brand-600 hidden sm:block">
                Login
              </Link>
              <Link
                to="/register"
                className="inline-flex items-center gap-1.5 px-4 py-2 bg-brand-600 text-white text-sm font-medium rounded-lg hover:bg-brand-700 transition-colors"
              >
                Get Started <ArrowRight size={16} />
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="relative overflow-hidden bg-gradient-to-br from-brand-50 via-white to-blue-50">
        <div className="absolute inset-0 opacity-20">
          <img
            src="https://images.pexels.com/photos/6591165/pexels-photo-6591165.jpeg?auto=compress&cs=tinysrgb&h=650&w=940"
            alt=""
            className="w-full h-full object-cover"
          />
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 lg:py-28">
          <div className="text-center max-w-3xl mx-auto">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-brand-100 text-brand-700 rounded-full text-sm font-medium mb-6 animate-fade-in">
              <Sparkles size={14} />
              Turning Surplus Food into Shared Resources
            </div>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-gray-900 leading-tight">
              Reduce Food Waste. <span className="text-brand-600">Redistribute Hope.</span>
            </h1>
            <p className="mt-6 text-lg text-gray-600 leading-relaxed">
              IFWRRS connects surplus food providers with organizations that need it, enabling
              intelligent matching, timely pickup, and efficient redistribution.
            </p>
            <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-3">
              <Link
                to="/register"
                className="inline-flex items-center gap-2 px-6 py-3 bg-brand-600 text-white text-base font-medium rounded-lg hover:bg-brand-700 transition-colors shadow-lg shadow-brand-600/20"
              >
                Get Started <ArrowRight size={18} />
              </Link>
              <Link
                to="/login"
                className="inline-flex items-center gap-2 px-6 py-3 bg-white text-gray-700 text-base font-medium rounded-lg hover:bg-gray-50 border border-gray-300 transition-colors"
              >
                Explore Donations
              </Link>
              <Link
                to="/login"
                className="inline-flex items-center gap-2 px-6 py-3 text-gray-600 text-base font-medium rounded-lg hover:bg-white/50 transition-colors"
              >
                Login
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-16 bg-white border-y border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-6">
            {stats.map((stat) => {
              const Icon = stat.icon;
              return (
                <div key={stat.label} className="text-center">
                  <div className={`inline-flex p-3 rounded-lg ${stat.color} mb-3`}>
                    <Icon size={24} />
                  </div>
                  <p className="text-3xl font-bold text-gray-900">{stat.value}</p>
                  <p className="text-sm text-gray-500 mt-1">{stat.label}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900">How It Works</h2>
            <p className="mt-3 text-gray-600 max-w-2xl mx-auto">
              A simple, intelligent workflow that connects surplus food with those who need it most.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
            {steps.map((step, i) => {
              const Icon = step.icon;
              return (
                <div key={step.title} className="relative">
                  <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-200 h-full hover:shadow-md transition-shadow">
                    <div className="w-12 h-12 bg-brand-50 rounded-lg flex items-center justify-center mb-4">
                      <Icon size={24} className="text-brand-600" />
                    </div>
                    <div className="text-xs font-bold text-brand-500 mb-1">STEP {i + 1}</div>
                    <h3 className="font-semibold text-gray-900 text-sm mb-2">{step.title}</h3>
                    <p className="text-xs text-gray-500 leading-relaxed">{step.desc}</p>
                  </div>
                  {i < steps.length - 1 && (
                    <div className="hidden lg:block absolute top-1/2 -right-3 text-gray-300 z-10">
                      <ArrowRight size={20} />
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Who Uses IFWRRS */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900">Who Uses IFWRRS?</h2>
            <p className="mt-3 text-gray-600 max-w-2xl mx-auto">
              Our platform serves the entire food redistribution ecosystem.
            </p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {userTypes.map((ut) => {
              const Icon = ut.icon;
              return (
                <div key={ut.title} className="bg-white rounded-xl p-6 border border-gray-200 hover:border-brand-300 hover:shadow-md transition-all">
                  <div className={`w-12 h-12 rounded-lg flex items-center justify-center mb-4 ${ut.color}`}>
                    <Icon size={24} />
                  </div>
                  <h3 className="font-semibold text-gray-900 mb-2">{ut.title}</h3>
                  <p className="text-sm text-gray-500">{ut.desc}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-20 bg-brand-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-white">Built for Impact</h2>
            <p className="mt-3 text-brand-200 max-w-2xl mx-auto">
              Powerful features that make food redistribution efficient, transparent, and scalable.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {[
              { icon: Brain, title: 'Smart Matching', desc: 'AI-powered algorithm scores compatibility based on location, quantity, urgency, and food type.' },
              { icon: Clock, title: 'Expiry Tracking', desc: 'Real-time countdown and automatic urgency alerts prevent food from expiring unused.' },
              { icon: Truck, title: 'Delivery Tracking', desc: 'Full lifecycle tracking from pickup to delivery with status updates at every step.' },
              { icon: TrendingUp, title: 'Analytics & Reports', desc: 'Comprehensive dashboards and reports for monitoring impact and performance.' },
              { icon: MapPin, title: 'Location-Based', desc: 'Distance calculations and mapping ensure efficient logistics and timely delivery.' },
              { icon: Recycle, title: 'Waste Reduction', desc: 'Systematic approach to reducing food waste through intelligent redistribution.' },
              { icon: Shield, title: 'Role-Based Access', desc: 'Secure, role-specific interfaces for providers, recipients, delivery, and admins.' },
              { icon: CheckCircle2, title: 'State Management', desc: 'Controlled donation lifecycle prevents invalid state transitions and data issues.' },
            ].map((f) => {
              const Icon = f.icon;
              return (
                <div key={f.title} className="bg-brand-800/50 rounded-xl p-6 border border-brand-700/50">
                  <Icon size={28} className="text-brand-300 mb-3" />
                  <h3 className="font-semibold text-white mb-2">{f.title}</h3>
                  <p className="text-sm text-brand-200 leading-relaxed">{f.desc}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 bg-gradient-to-br from-brand-50 to-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-gray-900">Ready to Make a Difference?</h2>
          <p className="mt-4 text-lg text-gray-600">
            Join IFWRRS today and be part of the solution to food waste and hunger.
          </p>
          <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-3">
            <Link
              to="/register"
              className="inline-flex items-center gap-2 px-8 py-3 bg-brand-600 text-white text-base font-medium rounded-lg hover:bg-brand-700 transition-colors shadow-lg shadow-brand-600/20"
            >
              Create Account <ArrowRight size={18} />
            </Link>
            <Link
              to="/login"
              className="inline-flex items-center gap-2 px-8 py-3 bg-white text-gray-700 text-base font-medium rounded-lg hover:bg-gray-50 border border-gray-300 transition-colors"
            >
              Login to Dashboard
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-gray-400 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="md:col-span-2">
              <div className="flex items-center gap-2 mb-4">
                <div className="w-10 h-10 bg-brand-600 rounded-lg flex items-center justify-center">
                  <Leaf size={22} className="text-white" />
                </div>
                <div>
                  <h1 className="text-xl font-bold text-white leading-none">IFWRRS</h1>
                  <p className="text-[10px] text-gray-500 mt-0.5">Intelligent Food Waste Reduction and Redistribution System</p>
                </div>
              </div>
              <p className="text-sm leading-relaxed max-w-md">
                Turning Surplus Food into Shared Resources. A platform connecting food providers,
                recipient organizations, and delivery partners to reduce food waste and fight hunger.
              </p>
            </div>
            <div>
              <h4 className="text-white font-semibold mb-3 text-sm">Quick Links</h4>
              <ul className="space-y-2 text-sm">
                <li><Link to="/about" className="hover:text-brand-400 transition-colors">About</Link></li>
                <li><Link to="/contact" className="hover:text-brand-400 transition-colors">Contact</Link></li>
                <li><Link to="/privacy" className="hover:text-brand-400 transition-colors">Privacy</Link></li>
                <li><Link to="/terms" className="hover:text-brand-400 transition-colors">Terms</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="text-white font-semibold mb-3 text-sm">System Information</h4>
              <ul className="space-y-2 text-sm">
                <li>Version 1.0.0</li>
                <li>OOAD Project Demo</li>
                <li>React + TypeScript + Tailwind</li>
                <li>Powered by Supabase</li>
              </ul>
            </div>
          </div>
          <div className="mt-8 pt-8 border-t border-gray-800 text-center text-sm">
            <p>&copy; 2026 IFWRRS. All rights reserved. Built for a sustainable future.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
