import { useMemo } from 'react';
import { History, CheckCircle, Navigation, MapPin, Package, Inbox } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useData } from '@/context/DataContext';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, DeliveryStatusBadge, PageHeader, EmptyState, Badge } from '@/components/ui';
import { formatDateTime } from '@/services/formatters';

export function DeliveryHistoryPage() {
  const { user } = useAuth();
  const { deliveries } = useData();

  if (!user) return null;

  const completed = useMemo(() => {
    return deliveries
      .filter((d) => d.partnerId === user.userId && (d.status === 'Delivered' || d.status === 'Confirmed' || d.status === 'Rejected' || d.status === 'Cancelled'))
      .sort((a, b) => new Date(b.assignedTime).getTime() - new Date(a.assignedTime).getTime());
  }, [deliveries, user.userId]);

  const totalCompleted = completed.filter((d) => d.status === 'Delivered' || d.status === 'Confirmed').length;
  const totalDistance = completed.filter((d) => d.status === 'Delivered' || d.status === 'Confirmed').reduce((sum, d) => sum + d.distance, 0);

  return (
    <DashboardLayout>
      <PageHeader title="Delivery History" subtitle="Your completed and past deliveries" />

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
        <Card className="p-5">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-brand-50 rounded-lg"><CheckCircle size={22} className="text-brand-600" /></div>
            <div>
              <p className="text-2xl font-bold text-gray-900">{totalCompleted}</p>
              <p className="text-sm text-gray-500">Completed</p>
            </div>
          </div>
        </Card>
        <Card className="p-5">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-blue-50 rounded-lg"><Navigation size={22} className="text-blue-600" /></div>
            <div>
              <p className="text-2xl font-bold text-gray-900">{totalDistance.toFixed(1)} km</p>
              <p className="text-sm text-gray-500">Total Distance</p>
            </div>
          </div>
        </Card>
        <Card className="p-5">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-accent-50 rounded-lg"><Package size={22} className="text-accent-600" /></div>
            <div>
              <p className="text-2xl font-bold text-gray-900">{completed.reduce((sum, d) => sum + d.quantity, 0)}</p>
              <p className="text-sm text-gray-500">Items Delivered</p>
            </div>
          </div>
        </Card>
      </div>

      {completed.length === 0 ? (
        <Card className="p-6">
          <EmptyState icon={Inbox} title="No delivery history" message="Your completed and past deliveries will appear here." />
        </Card>
      ) : (
        <Card className="overflow-hidden">
          <div className="overflow-x-auto table-scroll">
            <table className="w-full text-sm">
              <thead className="bg-gray-50 text-gray-600">
                <tr>
                  <th className="px-4 py-3 text-left font-medium">Delivery ID</th>
                  <th className="px-4 py-3 text-left font-medium">Food</th>
                  <th className="px-4 py-3 text-left font-medium">Quantity</th>
                  <th className="px-4 py-3 text-left font-medium">Provider</th>
                  <th className="px-4 py-3 text-left font-medium">Recipient</th>
                  <th className="px-4 py-3 text-left font-medium">Distance</th>
                  <th className="px-4 py-3 text-left font-medium">Assigned</th>
                  <th className="px-4 py-3 text-left font-medium">Completed</th>
                  <th className="px-4 py-3 text-left font-medium">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {completed.map((del) => (
                  <tr key={del.deliveryId} className="hover:bg-gray-50">
                    <td className="px-4 py-3 font-medium text-gray-900">{del.deliveryId}</td>
                    <td className="px-4 py-3 text-gray-700">{del.foodName}</td>
                    <td className="px-4 py-3 text-gray-600">{del.quantity} {del.unit}</td>
                    <td className="px-4 py-3 text-gray-600 text-xs">{del.providerName}</td>
                    <td className="px-4 py-3 text-gray-600 text-xs">{del.recipientName}</td>
                    <td className="px-4 py-3 text-gray-600">{del.distance} km</td>
                    <td className="px-4 py-3 text-gray-500 text-xs">{formatDateTime(del.assignedTime)}</td>
                    <td className="px-4 py-3 text-gray-500 text-xs">{del.completionTime ? formatDateTime(del.completionTime) : '—'}</td>
                    <td className="px-4 py-3"><DeliveryStatusBadge status={del.status} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      )}
    </DashboardLayout>
  );
}
