import { useMemo } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Truck, Package, CheckCircle, Navigation, Clock, MapPin, Eye } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useData } from '@/context/DataContext';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, StatCard, Button, DeliveryStatusBadge, PageHeader, EmptyState, Badge } from '@/components/ui';
import { formatDateTime } from '@/services/formatters';

export function DeliveryDashboard() {
  const { user } = useAuth();
  const { deliveries } = useData();
  const navigate = useNavigate();

  if (!user) return null;

  const myDeliveries = useMemo(() => {
    return deliveries.filter((d) => d.partnerId === user.userId);
  }, [deliveries, user.userId]);

  const active = myDeliveries.filter((d) =>
    ['Assigned', 'Accepted', 'Pickup Started', 'Picked Up', 'In Transit'].includes(d.status),
  );
  const pending = myDeliveries.filter((d) => d.status === 'Assigned').length;
  const completed = myDeliveries.filter((d) => d.status === 'Delivered' || d.status === 'Confirmed').length;
  const totalDistance = myDeliveries
    .filter((d) => d.status === 'Delivered' || d.status === 'Confirmed')
    .reduce((sum, d) => sum + d.distance, 0);

  const activeDeliveries = [...active].sort((a, b) => new Date(b.assignedTime).getTime() - new Date(a.assignedTime).getTime());

  return (
    <DashboardLayout>
      <PageHeader title="Dashboard" subtitle={`Welcome back, ${user.name}`} />

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatCard label="Active Deliveries" value={active.length} icon={Truck} color="brand" />
        <StatCard label="Pending Assignments" value={pending} icon={Clock} color="amber" />
        <StatCard label="Completed Deliveries" value={completed} icon={CheckCircle} color="brand" />
        <StatCard label="Distance Travelled" value={`${totalDistance.toFixed(1)} km`} icon={Navigation} color="blue" />
      </div>

      <Card className="overflow-hidden">
        <div className="px-5 py-4 border-b border-gray-200 flex items-center justify-between">
          <h3 className="font-semibold text-gray-900">Active Deliveries</h3>
          <Link to="/delivery/assignments" className="text-sm text-brand-600 hover:text-brand-700 font-medium">View All Assignments</Link>
        </div>
        {activeDeliveries.length === 0 ? (
          <EmptyState icon={Package} title="No active deliveries" message="You have no active deliveries right now. Check assignments for new tasks." />
        ) : (
          <div className="divide-y divide-gray-100">
            {activeDeliveries.map((del) => (
              <div key={del.deliveryId} className="p-5 hover:bg-gray-50 transition-colors">
                <div className="flex flex-col lg:flex-row gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-3">
                      <h4 className="font-semibold text-gray-900">{del.deliveryId}</h4>
                      <DeliveryStatusBadge status={del.status} />
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-sm">
                      <div>
                        <p className="text-xs text-gray-500">Food</p>
                        <p className="font-medium text-gray-700">{del.foodName}</p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-500">Quantity</p>
                        <p className="font-medium text-gray-700">{del.quantity} {del.unit}</p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-500">Distance</p>
                        <p className="font-medium text-gray-700">{del.distance} km</p>
                      </div>
                      <div>
                        <p className="text-xs text-gray-500">Assigned</p>
                        <p className="font-medium text-gray-700 text-xs">{formatDateTime(del.assignedTime)}</p>
                      </div>
                    </div>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm mt-3">
                      <div className="flex items-start gap-2">
                        <MapPin size={14} className="text-blue-500 mt-0.5" />
                        <div>
                          <p className="text-xs text-gray-500">Pickup</p>
                          <p className="text-gray-700 text-xs">{del.pickupLocation}</p>
                        </div>
                      </div>
                      <div className="flex items-start gap-2">
                        <MapPin size={14} className="text-brand-500 mt-0.5" />
                        <div>
                          <p className="text-xs text-gray-500">Destination</p>
                          <p className="text-gray-700 text-xs">{del.destination}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="flex lg:flex-col gap-2 lg:w-40">
                    <Button size="sm" variant="outline" onClick={() => navigate(`/delivery/active/${del.deliveryId}`)}>
                      <Eye size={14} /> Track
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>
    </DashboardLayout>
  );
}
