import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ClipboardList, Eye, CheckCircle, XCircle, Inbox, MapPin, Package } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useData } from '@/context/DataContext';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, Button, DeliveryStatusBadge, PageHeader, EmptyState, Select } from '@/components/ui';
import { formatDateTime } from '@/services/formatters';

export function DeliveryAssignmentsPage() {
  const { user } = useAuth();
  const { deliveries, updateDeliveryStatus } = useData();
  const navigate = useNavigate();
  const [statusFilter, setStatusFilter] = useState('');

  if (!user) return null;

  const myDeliveries = useMemo(() => {
    return deliveries
      .filter((d) => d.partnerId === user.userId)
      .filter((d) => !statusFilter || d.status === statusFilter)
      .sort((a, b) => new Date(b.assignedTime).getTime() - new Date(a.assignedTime).getTime());
  }, [deliveries, user.userId, statusFilter]);

  const statusOptions = ['Assigned', 'Accepted', 'Pickup Started', 'Picked Up', 'In Transit', 'Delivered', 'Confirmed', 'Rejected', 'Cancelled']
    .map((s) => ({ value: s, label: s }));

  return (
    <DashboardLayout>
      <PageHeader title="Assignments" subtitle="View and manage your delivery assignments" />

      <Card className="p-4 mb-6">
        <div className="flex gap-3">
          <Select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} options={statusOptions} placeholder="All Statuses" />
        </div>
      </Card>

      {myDeliveries.length === 0 ? (
        <Card className="p-6">
          <EmptyState icon={Inbox} title="No assignments" message="You have no delivery assignments. New assignments will appear here." />
        </Card>
      ) : (
        <div className="space-y-4">
          {myDeliveries.map((del) => (
            <Card key={del.deliveryId} className="p-5">
              <div className="flex flex-col lg:flex-row gap-4">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-3">
                    <h3 className="font-semibold text-gray-900">{del.deliveryId}</h3>
                    <DeliveryStatusBadge status={del.status} />
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 text-sm">
                    <div>
                      <p className="text-xs text-gray-500">Food</p>
                      <p className="font-medium text-gray-700">{del.foodName}</p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-500">Quantity</p>
                      <p className="font-medium text-gray-700">{del.quantity} {del.unit}</p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-500">Provider</p>
                      <p className="font-medium text-gray-700">{del.providerName}</p>
                    </div>
                    <div>
                      <p className="text-xs text-gray-500">Recipient</p>
                      <p className="font-medium text-gray-700">{del.recipientName}</p>
                    </div>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-sm mt-3">
                    <div className="flex items-start gap-2">
                      <MapPin size={14} className="text-blue-500 mt-0.5" />
                      <div>
                        <p className="text-xs text-gray-500">Pickup</p>
                        <p className="text-gray-700 text-xs">{del.pickupLocation}</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-2">
                      <MapPin size={14} className="text-brand-500 mt-0.5" />
                      <div>
                        <p className="text-xs text-gray-500">Destination</p>
                        <p className="text-gray-700 text-xs">{del.destination}</p>
                      </div>
                    </div>
                  </div>
                  <p className="text-xs text-gray-400 mt-2">Assigned: {formatDateTime(del.assignedTime)}</p>
                </div>
                <div className="flex flex-row lg:flex-col gap-2 lg:w-44">
                  <Button size="sm" variant="outline" onClick={() => navigate(`/delivery/active/${del.deliveryId}`)}>
                    <Eye size={14} /> Track Delivery
                  </Button>
                  {del.status === 'Assigned' && (
                    <>
                      <Button size="sm" variant="primary" onClick={() => updateDeliveryStatus(del.deliveryId, 'Accepted')}>
                        <CheckCircle size={14} /> Accept
                      </Button>
                      <Button size="sm" variant="danger" onClick={() => updateDeliveryStatus(del.deliveryId, 'Rejected')}>
                        <XCircle size={14} /> Reject
                      </Button>
                    </>
                  )}
                  {del.status === 'Accepted' && (
                    <Button size="sm" onClick={() => updateDeliveryStatus(del.deliveryId, 'Pickup Started')}>
                      <Package size={14} /> Start Pickup
                    </Button>
                  )}
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}
    </DashboardLayout>
  );
}
