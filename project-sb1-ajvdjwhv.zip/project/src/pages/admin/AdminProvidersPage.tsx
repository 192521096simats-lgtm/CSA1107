import { Store, MapPin, Phone, Mail, Star, Package, Inbox } from 'lucide-react';
import { useData } from '@/context/DataContext';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, Badge, PageHeader, EmptyState } from '@/components/ui';
import { formatDate } from '@/services/formatters';

export function AdminProvidersPage() {
  const { providers, donations } = useData();

  return (
    <DashboardLayout>
      <PageHeader title="Food Providers" subtitle="Manage all registered food providers" />

      {providers.length === 0 ? (
        <Card className="p-6"><EmptyState icon={Inbox} title="No providers" message="No food providers registered yet." /></Card>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {providers.map((p) => {
            const providerDonations = donations.filter((d) => d.providerId === p.providerId);
            const active = providerDonations.filter((d) => !['Expired', 'Distributed', 'Cancelled', 'Delivered'].includes(d.status)).length;
            return (
              <Card key={p.providerId} className="p-5">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-brand-50 rounded-lg flex items-center justify-center">
                      <Store size={24} className="text-brand-600" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-gray-900">{p.organizationName}</h3>
                      <Badge color="blue">{p.providerType}</Badge>
                    </div>
                  </div>
                  {p.rating > 0 && (
                    <div className="flex items-center gap-1 text-amber-500">
                      <Star size={14} fill="currentColor" />
                      <span className="text-sm font-medium">{p.rating}</span>
                    </div>
                  )}
                </div>
                <div className="space-y-2 text-sm text-gray-600">
                  <div className="flex items-start gap-2"><MapPin size={14} className="text-gray-400 mt-0.5" /> {p.address}, {p.city}</div>
                  <div className="flex items-center gap-2"><Phone size={14} className="text-gray-400" /> {p.contactPhone}</div>
                  <div className="flex items-center gap-2"><Mail size={14} className="text-gray-400" /> {p.email}</div>
                  <div className="flex items-center gap-2"><Package size={14} className="text-gray-400" /> {p.totalDonations} total donations</div>
                </div>
                <div className="mt-4 pt-4 border-t border-gray-100 flex items-center justify-between text-sm">
                  <div>
                    <p className="text-xs text-gray-500">Active Donations</p>
                    <p className="font-semibold text-gray-900">{active}</p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-500">Joined</p>
                    <p className="font-medium text-gray-700 text-xs">{formatDate(p.joinedDate)}</p>
                  </div>
                </div>
              </Card>
            );
          })}
        </div>
      )}
    </DashboardLayout>
  );
}
