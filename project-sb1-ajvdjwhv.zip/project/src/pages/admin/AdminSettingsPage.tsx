import { useState } from 'react';
import { Settings as SettingsIcon, Save, Brain } from 'lucide-react';
import { useData } from '@/context/DataContext';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, Button, Input, PageHeader, Badge } from '@/components/ui';

export function AdminSettingsPage() {
  const { settings, updateSettings } = useData();
  const [form, setForm] = useState({
    location: settings.matchWeights.location,
    quantity: settings.matchWeights.quantity,
    urgency: settings.matchWeights.urgency,
    foodRequirement: settings.matchWeights.foodRequirement,
    availability: settings.matchWeights.availability,
    expiryUrgentHours: settings.expiryUrgentHours,
    expiryWarningHours: settings.expiryWarningHours,
    maxDeliveryDistance: settings.maxDeliveryDistance,
    autoMatchEnabled: settings.autoMatchEnabled,
  });
  const [saved, setSaved] = useState(false);

  const totalWeight = form.location + form.quantity + form.urgency + form.foodRequirement + form.availability;

  const handleSave = () => {
    updateSettings({
      matchWeights: {
        location: form.location,
        quantity: form.quantity,
        urgency: form.urgency,
        foodRequirement: form.foodRequirement,
        availability: form.availability,
      },
      expiryUrgentHours: form.expiryUrgentHours,
      expiryWarningHours: form.expiryWarningHours,
      maxDeliveryDistance: form.maxDeliveryDistance,
      autoMatchEnabled: form.autoMatchEnabled,
    });
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  const weightFields = [
    { key: 'location', label: 'Location Weight', desc: 'Distance between provider and recipient' },
    { key: 'quantity', label: 'Quantity Weight', desc: 'Match between food quantity and org capacity' },
    { key: 'urgency', label: 'Urgency Weight', desc: 'How soon the food expires' },
    { key: 'foodRequirement', label: 'Food Requirement Weight', desc: 'Organization\'s food type needs' },
    { key: 'availability', label: 'Availability Weight', desc: 'Organization availability status' },
  ] as const;

  return (
    <DashboardLayout>
      <PageHeader title="System Settings" subtitle="Configure matching algorithm and system parameters" />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <Card className="p-6">
            <div className="flex items-center gap-2 mb-4">
              <Brain size={20} className="text-brand-600" />
              <h3 className="font-semibold text-gray-900">Matching Algorithm Weights</h3>
            </div>
            <p className="text-sm text-gray-500 mb-4">
              Configure how the smart matching algorithm scores donations against organizations. Weights should total 100%.
            </p>
            <div className="space-y-4">
              {weightFields.map((f) => (
                <div key={f.key}>
                  <div className="flex items-center justify-between mb-1">
                    <div>
                      <label className="text-sm font-medium text-gray-700">{f.label}</label>
                      <p className="text-xs text-gray-400">{f.desc}</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <input
                        type="number"
                        min={0}
                        max={100}
                        value={form[f.key]}
                        onChange={(e) => setForm({ ...form, [f.key]: parseInt(e.target.value) || 0 })}
                        className="w-20 px-2 py-1 border border-gray-300 rounded-lg text-sm text-center focus:outline-none focus:ring-2 focus:ring-brand-500"
                      />
                      <span className="text-sm text-gray-500">%</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-4 pt-4 border-t border-gray-100 flex items-center justify-between">
              <span className="text-sm text-gray-600">Total Weight:</span>
              <Badge color={totalWeight === 100 ? 'green' : 'red'}>{totalWeight}%</Badge>
            </div>
          </Card>

          <Card className="p-6">
            <h3 className="font-semibold text-gray-900 mb-4">Expiry & Delivery Settings</h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Input
                label="Urgent Expiry Threshold (hours)"
                type="number"
                value={form.expiryUrgentHours}
                onChange={(e) => setForm({ ...form, expiryUrgentHours: parseInt(e.target.value) || 0 })}
                hint="Donations expiring within this time are marked urgent"
              />
              <Input
                label="Warning Expiry Threshold (hours)"
                type="number"
                value={form.expiryWarningHours}
                onChange={(e) => setForm({ ...form, expiryWarningHours: parseInt(e.target.value) || 0 })}
                hint="Donations expiring within this time trigger warnings"
              />
              <Input
                label="Max Delivery Distance (km)"
                type="number"
                value={form.maxDeliveryDistance}
                onChange={(e) => setForm({ ...form, maxDeliveryDistance: parseInt(e.target.value) || 0 })}
              />
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Auto-Matching</label>
                <button
                  onClick={() => setForm({ ...form, autoMatchEnabled: !form.autoMatchEnabled })}
                  className={`relative w-12 h-6 rounded-full transition-colors ${form.autoMatchEnabled ? 'bg-brand-500' : 'bg-gray-300'}`}
                >
                  <span className={`absolute top-0.5 left-0.5 w-5 h-5 bg-white rounded-full transition-transform ${form.autoMatchEnabled ? 'translate-x-6' : ''}`} />
                </button>
              </div>
            </div>
          </Card>
        </div>

        <div className="space-y-4">
          <Card className="p-5">
            <h3 className="font-semibold text-gray-900 mb-3">Save Changes</h3>
            <p className="text-sm text-gray-500 mb-4">Apply your configuration changes to the system.</p>
            <Button className="w-full" onClick={handleSave}>
              <Save size={16} /> Save Settings
            </Button>
            {saved && (
              <p className="text-sm text-brand-600 mt-3 text-center animate-fade-in">Settings saved successfully!</p>
            )}
          </Card>

          <Card className="p-5">
            <h3 className="font-semibold text-gray-900 mb-3">Current Weights</h3>
            <div className="space-y-2 text-sm">
              {weightFields.map((f) => (
                <div key={f.key} className="flex items-center justify-between py-1.5 px-3 bg-gray-50 rounded-lg">
                  <span className="text-gray-600">{f.label}</span>
                  <Badge color="brand">{settings.matchWeights[f.key]}%</Badge>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
}
