import { Heart, MapPin, Phone, Mail, Users, Clock, Inbox } from 'lucide-react';
import { useData } from '@/context/DataContext';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, Badge, PageHeader, EmptyState } from '@/components/ui';
import { formatDate } from '@/services/formatters';

export function AdminOrganizationsPage() {
  const { recipients } = useData();

  return (
    <DashboardLayout>
      <PageHeader title="Recipient Organizations" subtitle="Manage all registered recipient organizations" />

      {recipients.length === 0 ? (
        <Card className="p-6"><EmptyState icon={Inbox} title="No organizations" message="No recipient organizations registered yet." /></Card>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {recipients.map((r) => (
            <Card key={r.organizationId} className="p-5">
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-teal-50 rounded-lg flex items-center justify-center">
                    <Heart size={24} className="text-teal-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900">{r.organizationName}</h3>
                    <Badge color="teal">{r.organizationType}</Badge>
                  </div>
                </div>
                <Badge color={r.availability ? 'green' : 'gray'}>{r.availability ? 'Available' : 'Unavailable'}</Badge>
              </div>
              <div className="space-y-2 text-sm text-gray-600">
                <div className="flex items-start gap-2"><MapPin size={14} className="text-gray-400 mt-0.5" /> {r.address}</div>
                <div className="flex items-center gap-2"><Phone size={14} className="text-gray-400" /> {r.contactPhone}</div>
                <div className="flex items-center gap-2"><Mail size={14} className="text-gray-400" /> {r.email}</div>
                <div className="flex items-center gap-2"><Users size={14} className="text-gray-400" /> Serves {r.peopleServed} people</div>
                <div className="flex items-center gap-2"><Clock size={14} className="text-gray-400" /> {r.operatingHours}</div>
              </div>
              <div className="mt-3 pt-3 border-t border-gray-100">
                <p className="text-xs text-gray-500 mb-2">Food Requirements</p>
                <div className="flex flex-wrap gap-1.5">
                  {r.foodRequirements.map((f) => (
                    <Badge key={f} color="brand">{f}</Badge>
                  ))}
                </div>
              </div>
              <div className="mt-3 pt-3 border-t border-gray-100 flex items-center justify-between text-sm">
                <div><p className="text-xs text-gray-500">Capacity</p><p className="font-semibold text-gray-900">{r.capacity}</p></div>
                <div><p className="text-xs text-gray-500">Joined</p><p className="font-medium text-gray-700 text-xs">{formatDate(r.joinedDate)}</p></div>
              </div>
            </Card>
          ))}
        </div>
      )}
    </DashboardLayout>
  );
}
