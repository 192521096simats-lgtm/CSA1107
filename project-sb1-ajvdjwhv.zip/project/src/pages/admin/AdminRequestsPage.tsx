import { useMemo, useState } from 'react';
import { Search, Eye, Inbox, ClipboardList } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useData } from '@/context/DataContext';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, Select, RequestStatusBadge, UrgencyBadge, PageHeader, EmptyState, Button } from '@/components/ui';
import { formatDateTime } from '@/services/formatters';


export function AdminRequestsPage() {
  const { requests, donations, updateRequestStatus } = useData();
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('');

  const statusOptions = ['Pending', 'Approved', 'Rejected', 'Fulfilled', 'Cancelled'].map((s) => ({ value: s, label: s }));

  const filtered = useMemo(() => {
    return requests
      .filter((r) => !search || r.requestId.toLowerCase().includes(search.toLowerCase()) || r.organizationName.toLowerCase().includes(search.toLowerCase()))
      .filter((r) => !statusFilter || r.status === statusFilter)
      .sort((a, b) => new Date(b.requestDate).getTime() - new Date(a.requestDate).getTime());
  }, [requests, search, statusFilter]);

  return (
    <DashboardLayout>
      <PageHeader title="Request Management" subtitle="Manage all food donation requests" />

      <Card className="p-4 mb-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div className="relative">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input type="text" placeholder="Search by ID or organization..." value={search} onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-9 pr-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-brand-500" />
          </div>
          <Select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} options={statusOptions} placeholder="All Statuses" />
        </div>
      </Card>

      <Card className="overflow-hidden">
        {filtered.length === 0 ? (
          <EmptyState icon={Inbox} title="No requests found" message="Try adjusting your filters." />
        ) : (
          <div className="overflow-x-auto table-scroll">
            <table className="w-full text-sm">
              <thead className="bg-gray-50 text-gray-600">
                <tr>
                  <th className="px-4 py-3 text-left font-medium">Request ID</th>
                  <th className="px-4 py-3 text-left font-medium">Donation</th>
                  <th className="px-4 py-3 text-left font-medium">Organization</th>
                  <th className="px-4 py-3 text-left font-medium">Provider</th>
                  <th className="px-4 py-3 text-left font-medium">Qty</th>
                  <th className="px-4 py-3 text-left font-medium">Date</th>
                  <th className="px-4 py-3 text-left font-medium">Priority</th>
                  <th className="px-4 py-3 text-left font-medium">Status</th>
                  <th className="px-4 py-3 text-left font-medium">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {filtered.map((r) => {
                  const donation = donations.find((d) => d.donationId === r.donationId);
                  return (
                    <tr key={r.requestId} className="hover:bg-gray-50">
                      <td className="px-4 py-3 font-medium text-gray-900">{r.requestId}</td>
                      <td className="px-4 py-3 text-gray-600 text-xs">{donation?.foodName ?? r.donationId}</td>
                      <td className="px-4 py-3 text-gray-600 text-xs">{r.organizationName}</td>
                      <td className="px-4 py-3 text-gray-600 text-xs">{r.providerId}</td>
                      <td className="px-4 py-3 text-gray-600">{r.requestedQuantity} {donation?.unit ?? ''}</td>
                      <td className="px-4 py-3 text-gray-500 text-xs">{formatDateTime(r.requestDate)}</td>
                      <td className="px-4 py-3"><UrgencyBadge urgency={r.priority} /></td>
                      <td className="px-4 py-3"><RequestStatusBadge status={r.status} /></td>
                      <td className="px-4 py-3">
                        <button onClick={() => navigate(`/admin/donations/${r.donationId}`)} className="p-1.5 text-blue-600 hover:bg-blue-50 rounded-lg" title="View Donation">
                          <Eye size={16} />
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </DashboardLayout>
  );
}
