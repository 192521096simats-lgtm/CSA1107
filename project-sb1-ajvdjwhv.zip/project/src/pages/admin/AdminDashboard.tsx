import { Users, Store, Heart, Package, TrendingUp, Truck, Clock, CheckCircle } from 'lucide-react';
import { useData } from '@/context/DataContext';
import { useAuth } from '@/context/AuthContext';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, StatCard, PageHeader } from '@/components/ui';
import { DonutChart, BarChartViz, LineChartViz, MultiBarChart } from '@/components/charts/Charts';
import {
  donationsByStatus, monthlyRedistribution, deliveryPerformance, providerContributions,
} from '@/services/analytics';

export function AdminDashboard() {
  const { user } = useAuth();
  const { donations, providers, recipients, deliveries, requests } = useData();

  if (!user) return null;

  const totalUsers = providers.length + recipients.length + 3; // +3 for delivery + admin
  const activeDonations = donations.filter((d) => !['Expired', 'Distributed', 'Cancelled', 'Delivered'].includes(d.status)).length;
  const foodRedistributed = donations.filter((d) => d.status === 'Distributed' || d.status === 'Delivered').reduce((sum, d) => sum + d.quantity, 0);
  const activeDeliveries = deliveries.filter((d) => !['Delivered', 'Confirmed', 'Rejected', 'Cancelled'].includes(d.status)).length;
  const expiringDonations = donations.filter((d) => {
    if (['Expired', 'Distributed', 'Cancelled', 'Delivered'].includes(d.status)) return false;
    const hours = (new Date(d.expiryTime).getTime() - Date.now()) / (1000 * 60 * 60);
    return hours > 0 && hours <= 24;
  }).length;
  const successfulDeliveries = deliveries.filter((d) => d.status === 'Delivered' || d.status === 'Confirmed').length;

  return (
    <DashboardLayout>
      <PageHeader title="Admin Dashboard" subtitle="System-wide overview and monitoring" />

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatCard label="Total Users" value={totalUsers} icon={Users} color="brand" />
        <StatCard label="Food Providers" value={providers.length} icon={Store} color="blue" />
        <StatCard label="Recipient Organizations" value={recipients.length} icon={Heart} color="teal" />
        <StatCard label="Active Donations" value={activeDonations} icon={Package} color="amber" />
        <StatCard label="Food Redistributed" value={foodRedistributed} icon={TrendingUp} color="brand" />
        <StatCard label="Active Deliveries" value={activeDeliveries} icon={Truck} color="purple" />
        <StatCard label="Expiring Donations" value={expiringDonations} icon={Clock} color="red" />
        <StatCard label="Successful Deliveries" value={successfulDeliveries} icon={CheckCircle} color="brand" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        <Card className="p-5">
          <h3 className="font-semibold text-gray-900 mb-4">Food Redistribution (Monthly)</h3>
          <LineChartViz data={monthlyRedistribution(donations)} />
        </Card>
        <Card className="p-5">
          <h3 className="font-semibold text-gray-900 mb-4">Donation Status Distribution</h3>
          <DonutChart data={donationsByStatus(donations)} />
        </Card>
        <Card className="p-5">
          <h3 className="font-semibold text-gray-900 mb-4">Provider Contributions</h3>
          <BarChartViz data={providerContributions(donations)} color="#0ea5e9" />
        </Card>
        <Card className="p-5">
          <h3 className="font-semibold text-gray-900 mb-4">Delivery Performance</h3>
          <MultiBarChart
            data={deliveryPerformance(deliveries)}
            series={[
              { key: 'value', label: 'Deliveries', color: '#059669' },
            ]}
          />
        </Card>
      </div>
    </DashboardLayout>
  );
}
