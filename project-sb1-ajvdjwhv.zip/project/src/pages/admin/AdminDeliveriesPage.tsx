import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, Eye, Inbox } from 'lucide-react';
import { useData } from '@/context/DataContext';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, Select, DeliveryStatusBadge, PageHeader, EmptyState } from '@/components/ui';
import { formatDateTime } from '@/services/formatters';


export function AdminDeliveriesPage() {
  const { deliveries } = useData();
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('');

  const statusOptions = ['Assigned', 'Accepted', 'Pickup Started', 'Picked Up', 'In Transit', 'Delivered', 'Confirmed', 'Rejected', 'Cancelled'].map((s) => ({ value: s, label: s }));

  const filtered = useMemo(() => {
    return deliveries
      .filter((d) => !search || d.deliveryId.toLowerCase().includes(search.toLowerCase()) || d.providerName.toLowerCase().includes(search.toLowerCase()) || d.recipientName.toLowerCase().includes(search.toLowerCase()))
      .filter((d) => !statusFilter || d.status === statusFilter)
      .sort((a, b) => new Date(b.assignedTime).getTime() - new Date(a.assignedTime).getTime());
  }, [deliveries, search, statusFilter]);

  return (
    <DashboardLayout>
      <PageHeader title="Delivery Management" subtitle="Manage all deliveries in the system" />

      <Card className="p-4 mb-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div className="relative">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input type="text" placeholder="Search by ID, provider, recipient..." value={search} onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-9 pr-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-brand-500" />
          </div>
          <Select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} options={statusOptions} placeholder="All Statuses" />
        </div>
      </Card>

      <Card className="overflow-hidden">
        {filtered.length === 0 ? (
          <EmptyState icon={Inbox} title="No deliveries found" message="Try adjusting your filters." />
        ) : (
          <div className="overflow-x-auto table-scroll">
            <table className="w-full text-sm">
              <thead className="bg-gray-50 text-gray-600">
                <tr>
                  <th className="px-4 py-3 text-left font-medium">Delivery ID</th>
                  <th className="px-4 py-3 text-left font-medium">Provider</th>
                  <th className="px-4 py-3 text-left font-medium">Recipient</th>
                  <th className="px-4 py-3 text-left font-medium">Partner</th>
                  <th className="px-4 py-3 text-left font-medium">Pickup</th>
                  <th className="px-4 py-3 text-left font-medium">Destination</th>
                  <th className="px-4 py-3 text-left font-medium">Status</th>
                  <th className="px-4 py-3 text-left font-medium">Assigned</th>
                  <th className="px-4 py-3 text-left font-medium">Completed</th>
                  <th className="px-4 py-3 text-left font-medium">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {filtered.map((d) => (
                  <tr key={d.deliveryId} className="hover:bg-gray-50">
                    <td className="px-4 py-3 font-medium text-gray-900">{d.deliveryId}</td>
                    <td className="px-4 py-3 text-gray-600 text-xs">{d.providerName}</td>
                    <td className="px-4 py-3 text-gray-600 text-xs">{d.recipientName}</td>
                    <td className="px-4 py-3 text-gray-600 text-xs">{d.partnerName}</td>
                    <td className="px-4 py-3 text-gray-500 text-xs max-w-[120px] truncate">{d.pickupLocation}</td>
                    <td className="px-4 py-3 text-gray-500 text-xs max-w-[120px] truncate">{d.destination}</td>
                    <td className="px-4 py-3"><DeliveryStatusBadge status={d.status} /></td>
                    <td className="px-4 py-3 text-gray-500 text-xs">{formatDateTime(d.assignedTime)}</td>
                    <td className="px-4 py-3 text-gray-500 text-xs">{d.completionTime ? formatDateTime(d.completionTime) : '—'}</td>
                    <td className="px-4 py-3">
                      <button onClick={() => navigate(`/admin/deliveries/${d.deliveryId}`)} className="p-1.5 text-blue-600 hover:bg-blue-50 rounded-lg" title="Track">
                        <Eye size={16} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </DashboardLayout>
  );
}
