import { useState, useMemo } from 'react';
import { Download, TrendingUp, Package, Truck, AlertTriangle, Users, BarChart3 } from 'lucide-react';
import { useData } from '@/context/DataContext';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, StatCard, Button, Select, PageHeader } from '@/components/ui';
import { DonutChart, BarChartViz, LineChartViz, MultiBarChart } from '@/components/charts/Charts';
import {
  totalFoodDonated, totalFoodRedistributed, totalFoodExpired, providerContributions,
  recipientDistribution, deliveryPerformance, monthlyRedistribution, donationsByStatus,
} from '@/services/analytics';

export function AdminReportsPage() {
  const { donations, deliveries, distributions, providers, recipients } = useData();
  const [dateRange, setDateRange] = useState('all');

  const rangeOptions = [
    { value: 'today', label: 'Today' },
    { value: 'week', label: 'This Week' },
    { value: 'month', label: 'This Month' },
    { value: 'year', label: 'This Year' },
    { value: 'all', label: 'All Time' },
  ];

  const filteredDonations = useMemo(() => {
    if (dateRange === 'all') return donations;
    const now = new Date();
    const cutoff = new Date();
    if (dateRange === 'today') cutoff.setHours(0, 0, 0, 0);
    else if (dateRange === 'week') cutoff.setDate(now.getDate() - 7);
    else if (dateRange === 'month') cutoff.setMonth(now.getMonth() - 1);
    else if (dateRange === 'year') cutoff.setFullYear(now.getFullYear() - 1);
    return donations.filter((d) => new Date(d.createdAt) >= cutoff);
  }, [donations, dateRange]);

  const filteredDeliveries = useMemo(() => {
    if (dateRange === 'all') return deliveries;
    const now = new Date();
    const cutoff = new Date();
    if (dateRange === 'today') cutoff.setHours(0, 0, 0, 0);
    else if (dateRange === 'week') cutoff.setDate(now.getDate() - 7);
    else if (dateRange === 'month') cutoff.setMonth(now.getMonth() - 1);
    else if (dateRange === 'year') cutoff.setFullYear(now.getFullYear() - 1);
    return deliveries.filter((d) => new Date(d.assignedTime) >= cutoff);
  }, [deliveries, dateRange]);

  const donated = totalFoodDonated(filteredDonations);
  const redistributed = totalFoodRedistributed(filteredDonations);
  const expired = totalFoodExpired(filteredDonations);
  const numDonations = filteredDonations.length;
  const successfulDeliveries = filteredDeliveries.filter((d) => d.status === 'Delivered' || d.status === 'Confirmed').length;
  const activeOrgs = providers.length + recipients.length;

  const handleExport = () => {
    const report = {
      generatedAt: new Date().toISOString(),
      dateRange,
      summary: { donated, redistributed, expired, numDonations, successfulDeliveries, activeOrgs },
      donations: filteredDonations,
      deliveries: filteredDeliveries,
    };
    const blob = new Blob([JSON.stringify(report, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ifwrrs-report-${dateRange}-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <DashboardLayout>
      <PageHeader
        title="Reports & Analytics"
        subtitle="Comprehensive reports on food redistribution performance"
        action={
          <>
            <Select value={dateRange} onChange={(e) => setDateRange(e.target.value)} options={rangeOptions} />
            <Button onClick={handleExport}><Download size={16} /> Export Report</Button>
          </>
        }
      />

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4 mb-6">
        <StatCard label="Food Donated" value={donated} icon={Package} color="blue" />
        <StatCard label="Food Redistributed" value={redistributed} icon={TrendingUp} color="brand" />
        <StatCard label="Food Expired" value={expired} icon={AlertTriangle} color="red" />
        <StatCard label="Total Donations" value={numDonations} icon={BarChart3} color="amber" />
        <StatCard label="Successful Deliveries" value={successfulDeliveries} icon={Truck} color="teal" />
        <StatCard label="Active Organizations" value={activeOrgs} icon={Users} color="purple" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        <Card className="p-5">
          <h3 className="font-semibold text-gray-900 mb-4">Food Redistribution Trend</h3>
          <LineChartViz data={monthlyRedistribution(filteredDonations)} />
        </Card>
        <Card className="p-5">
          <h3 className="font-semibold text-gray-900 mb-4">Donation Status Distribution</h3>
          <DonutChart data={donationsByStatus(filteredDonations)} />
        </Card>
        <Card className="p-5">
          <h3 className="font-semibold text-gray-900 mb-4">Provider Contributions</h3>
          <BarChartViz data={providerContributions(filteredDonations)} color="#0ea5e9" />
        </Card>
        <Card className="p-5">
          <h3 className="font-semibold text-gray-900 mb-4">Recipient Distribution</h3>
          <BarChartViz data={recipientDistribution(distributions)} color="#14b8a6" />
        </Card>
      </div>

      <Card className="p-5 mb-6">
        <h3 className="font-semibold text-gray-900 mb-4">Delivery Performance</h3>
        <MultiBarChart
          data={deliveryPerformance(filteredDeliveries)}
          series={[{ key: 'value', label: 'Deliveries', color: '#059669' }]}
        />
      </Card>
    </DashboardLayout>
  );
}
