import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Search, Eye, Inbox, Package } from 'lucide-react';
import { useData } from '@/context/DataContext';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, Select, DonationStatusBadge, UrgencyBadge, PageHeader, EmptyState } from '@/components/ui';
import { formatDateTime, countdownToExpiry } from '@/services/formatters';
import { foodTypeList } from '@/services/analytics';


export function AdminDonationsPage() {
  const { donations } = useData();
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [typeFilter, setTypeFilter] = useState('');
  const [urgencyFilter, setUrgencyFilter] = useState('');

  const statusOptions = [
    'Available', 'Matched', 'Requested', 'Approved', 'Assigned', 'Picked Up', 'In Transit', 'Delivered', 'Distributed', 'Expired', 'Cancelled',
  ].map((s) => ({ value: s, label: s }));
  const typeOptions = foodTypeList.map((f) => ({ value: f, label: f }));
  const urgencyOptions = ['Low', 'Medium', 'High', 'Critical'].map((u) => ({ value: u, label: u }));

  const filtered = useMemo(() => {
    return donations
      .filter((d) => !search || d.foodName.toLowerCase().includes(search.toLowerCase()) || d.donationId.toLowerCase().includes(search.toLowerCase()) || d.providerName.toLowerCase().includes(search.toLowerCase()))
      .filter((d) => !statusFilter || d.status === statusFilter)
      .filter((d) => !typeFilter || d.foodType === typeFilter)
      .filter((d) => !urgencyFilter || d.urgency === urgencyFilter)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }, [donations, search, statusFilter, typeFilter, urgencyFilter]);

  return (
    <DashboardLayout>
      <PageHeader title="Donation Management" subtitle="Manage all food donations in the system" />

      <Card className="p-4 mb-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          <div className="relative">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input type="text" placeholder="Search..." value={search} onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-9 pr-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-brand-500" />
          </div>
          <Select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} options={statusOptions} placeholder="All Statuses" />
          <Select value={typeFilter} onChange={(e) => setTypeFilter(e.target.value)} options={typeOptions} placeholder="All Food Types" />
          <Select value={urgencyFilter} onChange={(e) => setUrgencyFilter(e.target.value)} options={urgencyOptions} placeholder="All Urgency" />
        </div>
      </Card>

      <Card className="overflow-hidden">
        {filtered.length === 0 ? (
          <EmptyState icon={Inbox} title="No donations found" message="Try adjusting your filters." />
        ) : (
          <div className="overflow-x-auto table-scroll">
            <table className="w-full text-sm">
              <thead className="bg-gray-50 text-gray-600">
                <tr>
                  <th className="px-4 py-3 text-left font-medium">Donation ID</th>
                  <th className="px-4 py-3 text-left font-medium">Provider</th>
                  <th className="px-4 py-3 text-left font-medium">Food</th>
                  <th className="px-4 py-3 text-left font-medium">Qty</th>
                  <th className="px-4 py-3 text-left font-medium">Expiry</th>
                  <th className="px-4 py-3 text-left font-medium">Recipient</th>
                  <th className="px-4 py-3 text-left font-medium">Status</th>
                  <th className="px-4 py-3 text-left font-medium">Urgency</th>
                  <th className="px-4 py-3 text-left font-medium">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {filtered.map((d) => (
                  <tr key={d.donationId} className="hover:bg-gray-50">
                    <td className="px-4 py-3 font-medium text-gray-900">{d.donationId}</td>
                    <td className="px-4 py-3 text-gray-600 text-xs">{d.providerName}</td>
                    <td className="px-4 py-3 text-gray-700">{d.foodName}</td>
                    <td className="px-4 py-3 text-gray-600">{d.quantity} {d.unit}</td>
                    <td className="px-4 py-3 text-gray-500 text-xs">{countdownToExpiry(d.expiryTime)}</td>
                    <td className="px-4 py-3 text-gray-600 text-xs">{d.matchedOrganizationName ?? '—'}</td>
                    <td className="px-4 py-3"><DonationStatusBadge status={d.status} /></td>
                    <td className="px-4 py-3"><UrgencyBadge urgency={d.urgency} /></td>
                    <td className="px-4 py-3">
                      <button onClick={() => navigate(`/admin/donations/${d.donationId}`)} className="p-1.5 text-blue-600 hover:bg-blue-50 rounded-lg" title="View">
                        <Eye size={16} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </DashboardLayout>
  );
}
