import { useMemo, useState } from 'react';
import { Users as UsersIcon, Search, Eye, Trash2, UserCheck, UserX, Inbox } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useData } from '@/context/DataContext';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, Select, Badge, PageHeader, EmptyState, Modal, Button } from '@/components/ui';
import { formatDate } from '@/services/formatters';
import type { User, UserRole, UserStatus } from '@/types';

export function AdminUsersPage() {
  const { getAllUsers, setAllUsers, user: currentUser } = useAuth();
  const [search, setSearch] = useState('');
  const [roleFilter, setRoleFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [viewUser, setViewUser] = useState<User | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<User | null>(null);

  const roleOptions = [
    { value: 'provider', label: 'Food Provider' },
    { value: 'recipient', label: 'Recipient Organization' },
    { value: 'delivery', label: 'Delivery Partner' },
    { value: 'admin', label: 'Administrator' },
  ];
  const statusOptions = [
    { value: 'active', label: 'Active' },
    { value: 'inactive', label: 'Inactive' },
    { value: 'suspended', label: 'Suspended' },
  ];

  const users = useMemo(() => {
    return getAllUsers()
      .filter((u) => !search || u.name.toLowerCase().includes(search.toLowerCase()) || u.email.toLowerCase().includes(search.toLowerCase()) || u.organizationName.toLowerCase().includes(search.toLowerCase()))
      .filter((u) => !roleFilter || u.role === roleFilter)
      .filter((u) => !statusFilter || u.status === statusFilter)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }, [getAllUsers, search, roleFilter, statusFilter]);

  const toggleStatus = (userId: string) => {
    const updated = getAllUsers().map((u) => {
      if (u.userId === userId) {
        return { ...u, status: (u.status === 'active' ? 'inactive' : 'active') as UserStatus };
      }
      return u;
    });
    setAllUsers(updated);
  };

  const handleDelete = () => {
    if (deleteTarget && deleteTarget.userId !== currentUser?.userId) {
      setAllUsers(getAllUsers().filter((u) => u.userId !== deleteTarget.userId));
    }
    setDeleteTarget(null);
  };

  const roleLabels: Record<UserRole, string> = {
    provider: 'Food Provider',
    recipient: 'Recipient',
    delivery: 'Delivery Partner',
    admin: 'Administrator',
  };

  return (
    <DashboardLayout>
      <PageHeader title="User Management" subtitle="Manage all system users" />

      <Card className="p-4 mb-6">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="relative">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Search by name, email, org..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-9 pr-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-brand-500"
            />
          </div>
          <Select value={roleFilter} onChange={(e) => setRoleFilter(e.target.value)} options={roleOptions} placeholder="All Roles" />
          <Select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} options={statusOptions} placeholder="All Statuses" />
        </div>
      </Card>

      <Card className="overflow-hidden">
        {users.length === 0 ? (
          <EmptyState icon={Inbox} title="No users found" message="Try adjusting your filters." />
        ) : (
          <div className="overflow-x-auto table-scroll">
            <table className="w-full text-sm">
              <thead className="bg-gray-50 text-gray-600">
                <tr>
                  <th className="px-4 py-3 text-left font-medium">User ID</th>
                  <th className="px-4 py-3 text-left font-medium">Name</th>
                  <th className="px-4 py-3 text-left font-medium">Organization</th>
                  <th className="px-4 py-3 text-left font-medium">Role</th>
                  <th className="px-4 py-3 text-left font-medium">Email</th>
                  <th className="px-4 py-3 text-left font-medium">Status</th>
                  <th className="px-4 py-3 text-left font-medium">Joined</th>
                  <th className="px-4 py-3 text-left font-medium">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {users.map((u) => (
                  <tr key={u.userId} className="hover:bg-gray-50">
                    <td className="px-4 py-3 font-medium text-gray-900 text-xs">{u.userId}</td>
                    <td className="px-4 py-3 text-gray-700">{u.name}</td>
                    <td className="px-4 py-3 text-gray-600 text-xs">{u.organizationName}</td>
                    <td className="px-4 py-3"><Badge color="blue">{roleLabels[u.role]}</Badge></td>
                    <td className="px-4 py-3 text-gray-600 text-xs">{u.email}</td>
                    <td className="px-4 py-3">
                      <Badge color={u.status === 'active' ? 'green' : u.status === 'inactive' ? 'gray' : 'red'}>{u.status}</Badge>
                    </td>
                    <td className="px-4 py-3 text-gray-500 text-xs">{formatDate(u.createdAt)}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1">
                        <button onClick={() => setViewUser(u)} className="p-1.5 text-blue-600 hover:bg-blue-50 rounded-lg" title="View">
                          <Eye size={16} />
                        </button>
                        <button onClick={() => toggleStatus(u.userId)} className={`p-1.5 rounded-lg ${u.status === 'active' ? 'text-amber-600 hover:bg-amber-50' : 'text-brand-600 hover:bg-brand-50'}`} title={u.status === 'active' ? 'Deactivate' : 'Activate'}>
                          {u.status === 'active' ? <UserX size={16} /> : <UserCheck size={16} />}
                        </button>
                        {u.userId !== currentUser?.userId && (
                          <button onClick={() => setDeleteTarget(u)} className="p-1.5 text-red-600 hover:bg-red-50 rounded-lg" title="Delete">
                            <Trash2 size={16} />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      {/* View user modal */}
      <Modal open={!!viewUser} onClose={() => setViewUser(null)} title="User Details" size="md">
        {viewUser && (
          <div className="space-y-3 text-sm">
            <div className="grid grid-cols-2 gap-4">
              <div><p className="text-xs text-gray-500">Name</p><p className="text-gray-700">{viewUser.name}</p></div>
              <div><p className="text-xs text-gray-500">Email</p><p className="text-gray-700">{viewUser.email}</p></div>
              <div><p className="text-xs text-gray-500">Phone</p><p className="text-gray-700">{viewUser.phone}</p></div>
              <div><p className="text-xs text-gray-500">Role</p><p className="text-gray-700">{roleLabels[viewUser.role]}</p></div>
              <div><p className="text-xs text-gray-500">Organization</p><p className="text-gray-700">{viewUser.organizationName}</p></div>
              <div><p className="text-xs text-gray-500">Org Type</p><p className="text-gray-700">{viewUser.organizationType}</p></div>
              <div><p className="text-xs text-gray-500">Address</p><p className="text-gray-700">{viewUser.address}, {viewUser.city}</p></div>
              <div><p className="text-xs text-gray-500">Status</p><Badge color={viewUser.status === 'active' ? 'green' : 'gray'}>{viewUser.status}</Badge></div>
            </div>
          </div>
        )}
      </Modal>

      {/* Delete confirmation */}
      <Modal open={!!deleteTarget} onClose={() => setDeleteTarget(null)} title="Delete User" size="sm">
        <p className="text-sm text-gray-600">Are you sure you want to delete <strong>{deleteTarget?.name}</strong>? This action cannot be undone.</p>
        <div className="flex gap-3 mt-6 justify-end">
          <Button variant="outline" onClick={() => setDeleteTarget(null)}>Cancel</Button>
          <Button variant="danger" onClick={handleDelete}>Delete User</Button>
        </div>
      </Modal>
    </DashboardLayout>
  );
}
