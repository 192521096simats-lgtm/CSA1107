import { useState } from 'react';
import { User, Mail, Phone, Building2, MapPin, Calendar, Save, Shield } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, Button, Input, Select, PageHeader, Badge } from '@/components/ui';
import { formatDate } from '@/services/formatters';
import type { UserRole, OrganizationType } from '@/types';

export function ProfilePage() {
  const { user, updateProfile } = useAuth();
  const [editing, setEditing] = useState(false);
  const [saved, setSaved] = useState(false);
  const [form, setForm] = useState({
    name: user?.name ?? '',
    email: user?.email ?? '',
    phone: user?.phone ?? '',
    organizationName: user?.organizationName ?? '',
    address: user?.address ?? '',
    city: user?.city ?? '',
  });

  if (!user) return null;

  const roleLabels: Record<UserRole, string> = {
    provider: 'Food Provider',
    recipient: 'Recipient Organization',
    delivery: 'Delivery Partner',
    admin: 'Administrator',
  };

  const handleSave = () => {
    updateProfile({
      name: form.name,
      email: form.email,
      phone: form.phone,
      organizationName: form.organizationName,
      address: form.address,
      city: form.city,
    });
    setEditing(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  return (
    <DashboardLayout>
      <PageHeader
        title="Profile"
        subtitle="Manage your account information"
        action={!editing && <Button variant="outline" onClick={() => setEditing(true)}>Edit Profile</Button>}
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <Card className="p-6">
            <div className="flex items-center gap-4 mb-6">
              <div className="w-16 h-16 bg-brand-100 rounded-full flex items-center justify-center text-brand-700 font-bold text-2xl">
                {user.name.charAt(0).toUpperCase()}
              </div>
              <div>
                <h3 className="text-lg font-semibold text-gray-900">{user.name}</h3>
                <p className="text-sm text-gray-500">{user.organizationName}</p>
                <div className="flex items-center gap-2 mt-1">
                  <Badge color="blue">{roleLabels[user.role]}</Badge>
                  <Badge color={user.status === 'active' ? 'green' : 'gray'}>{user.status}</Badge>
                </div>
              </div>
            </div>

            {editing ? (
              <div className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <Input label="Full Name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
                  <Input label="Email" type="email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} />
                  <Input label="Phone" value={form.phone} onChange={(e) => setForm({ ...form, phone: e.target.value })} />
                  <Input label="Organization Name" value={form.organizationName} onChange={(e) => setForm({ ...form, organizationName: e.target.value })} />
                  <Input label="Address" value={form.address} onChange={(e) => setForm({ ...form, address: e.target.value })} />
                  <Input label="City" value={form.city} onChange={(e) => setForm({ ...form, city: e.target.value })} />
                </div>
                <div className="flex gap-3">
                  <Button onClick={handleSave}><Save size={16} /> Save Changes</Button>
                  <Button variant="outline" onClick={() => setEditing(false)}>Cancel</Button>
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <ProfileItem icon={User} label="Full Name" value={user.name} />
                <ProfileItem icon={Mail} label="Email" value={user.email} />
                <ProfileItem icon={Phone} label="Phone" value={user.phone} />
                <ProfileItem icon={Building2} label="Organization" value={user.organizationName} />
                <ProfileItem icon={MapPin} label="Address" value={`${user.address}, ${user.city}`} />
                <ProfileItem icon={Calendar} label="Member Since" value={formatDate(user.createdAt)} />
              </div>
            )}

            {saved && (
              <p className="text-sm text-brand-600 mt-4 animate-fade-in">Profile updated successfully!</p>
            )}
          </Card>
        </div>

        <div className="space-y-4">
          <Card className="p-5">
            <div className="flex items-center gap-2 mb-3">
              <Shield size={18} className="text-brand-600" />
              <h3 className="font-semibold text-gray-900">Account Security</h3>
            </div>
            <div className="space-y-2 text-sm">
              <div className="flex items-center justify-between py-2 border-b border-gray-100">
                <span className="text-gray-600">Role</span>
                <Badge color="blue">{roleLabels[user.role]}</Badge>
              </div>
              <div className="flex items-center justify-between py-2 border-b border-gray-100">
                <span className="text-gray-600">Status</span>
                <Badge color={user.status === 'active' ? 'green' : 'gray'}>{user.status}</Badge>
              </div>
              <div className="flex items-center justify-between py-2">
                <span className="text-gray-600">User ID</span>
                <span className="text-xs text-gray-400 font-mono">{user.userId}</span>
              </div>
            </div>
          </Card>

          <Card className="p-5">
            <h3 className="font-semibold text-gray-900 mb-3">Organization Type</h3>
            <Badge color="teal">{user.organizationType}</Badge>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
}

function ProfileItem({ icon: Icon, label, value }: { icon: typeof User; label: string; value: string }) {
  return (
    <div className="flex items-start gap-3">
      <div className="p-2 bg-gray-50 rounded-lg flex-shrink-0">
        <Icon size={16} className="text-gray-400" />
      </div>
      <div className="min-w-0">
        <p className="text-xs text-gray-500">{label}</p>
        <p className="text-sm text-gray-700 truncate">{value}</p>
      </div>
    </div>
  );
}
