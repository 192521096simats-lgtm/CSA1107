import { useMemo } from 'react';
import { Bell, CheckCheck, AlertTriangle, Info, CheckCircle, AlertCircle, Trash2 } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { useData } from '@/context/DataContext';
import { DashboardLayout } from '@/components/layout/DashboardLayout';
import { Card, Button, Badge, PageHeader, EmptyState } from '@/components/ui';
import { timeAgo } from '@/services/formatters';
import type { NotificationType } from '@/types';

export function NotificationsPage() {
  const { user } = useAuth();
  const { getNotificationsForUser, markNotificationRead, markAllNotificationsRead } = useData();

  if (!user) return null;

  const notifications = useMemo(() => getNotificationsForUser(user.userId), [getNotificationsForUser, user.userId]);
  const unreadCount = notifications.filter((n) => !n.read).length;

  const typeConfig: Record<NotificationType, { icon: typeof Bell; color: string; bg: string }> = {
    urgent: { icon: AlertTriangle, color: 'text-red-600', bg: 'bg-red-50' },
    warning: { icon: AlertCircle, color: 'text-amber-600', bg: 'bg-amber-50' },
    info: { icon: Info, color: 'text-blue-600', bg: 'bg-blue-50' },
    success: { icon: CheckCircle, color: 'text-brand-600', bg: 'bg-brand-50' },
  };

  return (
    <DashboardLayout>
      <PageHeader
        title="Notifications"
        subtitle={`${unreadCount} unread notification${unreadCount !== 1 ? 's' : ''}`}
        action={
          unreadCount > 0 && (
            <Button variant="outline" onClick={() => markAllNotificationsRead(user.userId)}>
              <CheckCheck size={16} /> Mark All Read
            </Button>
          )
        }
      />

      {notifications.length === 0 ? (
        <Card className="p-6">
          <EmptyState icon={Bell} title="No notifications" message="You're all caught up! New notifications will appear here." />
        </Card>
      ) : (
        <div className="space-y-3">
          {notifications.map((n) => {
            const config = typeConfig[n.type];
            const Icon = config.icon;
            return (
              <Card
                key={n.notificationId}
                className={`p-4 ${n.read ? 'opacity-75' : ''}`}
                onClick={() => !n.read && markNotificationRead(n.notificationId)}
              >
                <div className="flex items-start gap-3">
                  <div className={`p-2 rounded-lg flex-shrink-0 ${config.bg}`}>
                    <Icon size={18} className={config.color} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <h4 className="text-sm font-semibold text-gray-900">{n.title}</h4>
                      {!n.read && <Badge color="green">New</Badge>}
                    </div>
                    <p className="text-sm text-gray-600">{n.message}</p>
                    <p className="text-xs text-gray-400 mt-2">{timeAgo(n.createdAt)}</p>
                  </div>
                  {!n.read && (
                    <button
                      onClick={(e) => { e.stopPropagation(); markNotificationRead(n.notificationId); }}
                      className="p-1.5 text-gray-400 hover:text-brand-600 hover:bg-brand-50 rounded-lg flex-shrink-0"
                      title="Mark as read"
                    >
                      <CheckCheck size={16} />
                    </button>
                  )}
                </div>
              </Card>
            );
          })}
        </div>
      )}
    </DashboardLayout>
  );
}
