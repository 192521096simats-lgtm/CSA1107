// ============ Core Domain Types ============

export type UserRole = 'provider' | 'recipient' | 'delivery' | 'admin';

export type UserStatus = 'active' | 'inactive' | 'suspended';

export type OrganizationType =
  | 'Restaurant'
  | 'Hotel'
  | 'Supermarket'
  | 'Food Supplier'
  | 'Charity'
  | 'NGO';

export type FoodType =
  | 'Cooked Food'
  | 'Fruits'
  | 'Vegetables'
  | 'Bakery'
  | 'Dairy'
  | 'Packaged Food'
  | 'Grains'
  | 'Beverages'
  | 'Other';

export type StorageRequirement =
  | 'Room Temperature'
  | 'Refrigerated'
  | 'Frozen'
  | 'Dry Storage';

export type UrgencyLevel = 'Low' | 'Medium' | 'High' | 'Critical';

export type DonationStatus =
  | 'Created'
  | 'Available'
  | 'Matched'
  | 'Requested'
  | 'Approved'
  | 'Assigned'
  | 'Picked Up'
  | 'In Transit'
  | 'Delivered'
  | 'Distributed'
  | 'Expired'
  | 'Cancelled'
  | 'Rejected';

export type RequestStatus = 'Pending' | 'Approved' | 'Rejected' | 'Fulfilled' | 'Cancelled';

export type DeliveryStatus =
  | 'Assigned'
  | 'Accepted'
  | 'Rejected'
  | 'Pickup Started'
  | 'Picked Up'
  | 'In Transit'
  | 'Delivered'
  | 'Confirmed'
  | 'Cancelled';

export type DistributionStatus =
  | 'Received'
  | 'Being Prepared'
  | 'Distributed'
  | 'Partially Distributed'
  | 'Unable to Distribute';

export type NotificationType =
  | 'urgent'
  | 'warning'
  | 'info'
  | 'success';

export interface User {
  userId: string;
  name: string;
  email: string;
  phone: string;
  password: string;
  role: UserRole;
  status: UserStatus;
  organizationId: string;
  organizationName: string;
  organizationType: OrganizationType;
  address: string;
  city: string;
  createdAt: string;
}

export interface FoodProvider {
  providerId: string;
  userId: string;
  organizationName: string;
  providerType: OrganizationType;
  address: string;
  city: string;
  latitude: number;
  longitude: number;
  contactName: string;
  contactPhone: string;
  email: string;
  rating: number;
  totalDonations: number;
  joinedDate: string;
}

export interface FoodRequirement {
  foodType: FoodType;
  minQuantity: number;
  maxQuantity: number;
  preferredUnit: string;
}

export interface RecipientOrganization {
  organizationId: string;
  userId: string;
  organizationName: string;
  organizationType: OrganizationType;
  address: string;
  city: string;
  latitude: number;
  longitude: number;
  foodRequirements: FoodType[];
  capacity: number;
  operatingHours: string;
  availability: boolean;
  contactName: string;
  contactPhone: string;
  email: string;
  peopleServed: number;
  joinedDate: string;
}

export interface FoodDonation {
  donationId: string;
  providerId: string;
  providerName: string;
  foodName: string;
  foodType: FoodType;
  quantity: number;
  unit: string;
  preparationTime: string;
  expiryTime: string;
  storageRequirement: StorageRequirement;
  pickupLocation: string;
  pickupLatitude: number;
  pickupLongitude: number;
  description: string;
  imageUrl: string;
  availabilityTime: string;
  status: DonationStatus;
  urgency: UrgencyLevel;
  matchedOrganizationId: string | null;
  matchedOrganizationName: string | null;
  matchScore: number;
  createdAt: string;
}

export interface DonationRequest {
  requestId: string;
  donationId: string;
  organizationId: string;
  organizationName: string;
  providerId: string;
  requestedQuantity: number;
  requestDate: string;
  status: RequestStatus;
  priority: UrgencyLevel;
  notes: string;
  preferredPickupTime: string;
  reason: string;
}

export interface Delivery {
  deliveryId: string;
  requestId: string;
  donationId: string;
  partnerId: string;
  partnerName: string;
  providerId: string;
  providerName: string;
  recipientId: string;
  recipientName: string;
  pickupLocation: string;
  destination: string;
  pickupLatitude: number;
  pickupLongitude: number;
  destLatitude: number;
  destLongitude: number;
  foodName: string;
  foodType: FoodType;
  quantity: number;
  unit: string;
  distance: number;
  status: DeliveryStatus;
  assignedTime: string;
  pickupTime: string | null;
  deliveryTime: string | null;
  completionTime: string | null;
  estimatedDeliveryTime: string;
}

export interface Distribution {
  distributionId: string;
  deliveryId: string;
  donationId: string;
  organizationId: string;
  organizationName: string;
  foodName: string;
  totalReceived: number;
  distributedQuantity: number;
  remainingQuantity: number;
  unit: string;
  status: DistributionStatus;
  notes: string;
  updatedAt: string;
}

export interface Notification {
  notificationId: string;
  userId: string;
  type: NotificationType;
  title: string;
  message: string;
  createdAt: string;
  read: boolean;
  relatedId: string | null;
}

export interface MatchResult {
  organization: RecipientOrganization;
  score: number;
  distance: number;
  details: {
    locationScore: number;
    quantityScore: number;
    urgencyScore: number;
    foodScore: number;
    availabilityScore: number;
  };
}

export interface MatchWeights {
  location: number;
  quantity: number;
  urgency: number;
  foodRequirement: number;
  availability: number;
}

export interface SystemSettings {
  matchWeights: MatchWeights;
  expiryUrgentHours: number;
  expiryWarningHours: number;
  systemName: string;
  maxDeliveryDistance: number;
  autoMatchEnabled: boolean;
}
