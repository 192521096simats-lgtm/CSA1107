export function validateEmail(email: string): string | null {
  if (!email.trim()) return 'Email is required';
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) return 'Please enter a valid email address';
  return null;
}

export function validatePhone(phone: string): string | null {
  if (!phone.trim()) return 'Phone number is required';
  const phoneRegex = /^[+\d\s\-()]{10,}$/;
  if (!phoneRegex.test(phone)) return 'Please enter a valid phone number';
  return null;
}

export function validateRequired(value: string, fieldName: string): string | null {
  if (!value || !value.trim()) return `${fieldName} is required`;
  return null;
}

export function validatePositiveNumber(value: number, fieldName: string): string | null {
  if (value === undefined || value === null || isNaN(value)) return `${fieldName} is required`;
  if (value <= 0) return `${fieldName} must be greater than zero`;
  return null;
}

export function validateExpiryAfterPreparation(
  preparationTime: string,
  expiryTime: string,
): string | null {
  if (!preparationTime || !expiryTime) return 'Both preparation and expiry times are required';
  const prep = new Date(preparationTime).getTime();
  const expiry = new Date(expiryTime).getTime();
  if (expiry <= prep) return 'Expiry time must be after preparation time';
  if (expiry <= Date.now()) return 'Expiry time must be in the future';
  return null;
}

export function validateRequestQuantity(
  requestedQty: number,
  availableQty: number,
): string | null {
  if (requestedQty <= 0) return 'Requested quantity must be greater than zero';
  if (requestedQty > availableQty) return `Requested quantity cannot exceed available quantity (${availableQty})`;
  return null;
}

export function validatePassword(password: string): string | null {
  if (!password) return 'Password is required';
  if (password.length < 6) return 'Password must be at least 6 characters';
  return null;
}
