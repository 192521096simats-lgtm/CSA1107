let counter = 0;

export function generateId(prefix: string): string {
  counter += 1;
  const timestamp = Date.now().toString(36);
  const random = Math.random().toString(36).substring(2, 6);
  return `${prefix}-${timestamp}${random}${counter}`;
}

export function generateDonationId(): string {
  const num = 1013 + counter++;
  return `DON-${num}`;
}

export function generateRequestId(): string {
  const num = 2006 + counter++;
  return `REQ-${num}`;
}

export function generateDeliveryId(): string {
  const num = 1006 + counter++;
  return `DEL-${num}`;
}

export function generateNotificationId(): string {
  return generateId('N');
}

export function generateDistributionId(): string {
  return generateId('DIST');
}

export function generateUserId(): string {
  return generateId('U');
}
