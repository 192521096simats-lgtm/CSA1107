const PREFIX = 'ifwrrs_';

export function loadFromStorage<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(PREFIX + key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

export function saveToStorage<T>(key: string, value: T): void {
  try {
    localStorage.setItem(PREFIX + key, JSON.stringify(value));
  } catch {
    // ignore quota errors
  }
}

export function removeFromStorage(key: string): void {
  localStorage.removeItem(PREFIX + key);
}

export const STORAGE_KEYS = {
  users: 'users',
  providers: 'providers',
  recipients: 'recipients',
  donations: 'donations',
  requests: 'requests',
  deliveries: 'deliveries',
  distributions: 'distributions',
  notifications: 'notifications',
  settings: 'settings',
  currentUser: 'currentUser',
  initialized: 'initialized',
} as const;
