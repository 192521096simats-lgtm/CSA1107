import type { FoodDonation, Delivery, Distribution, FoodType } from '@/types';

export function donationsByFoodType(donations: FoodDonation[]): { name: string; value: number }[] {
  const map = new Map<string, number>();
  donations.forEach((d) => {
    map.set(d.foodType, (map.get(d.foodType) ?? 0) + 1);
  });
  return Array.from(map.entries()).map(([name, value]) => ({ name, value }));
}

export function donationsByStatus(donations: FoodDonation[]): { name: string; value: number }[] {
  const map = new Map<string, number>();
  donations.forEach((d) => {
    map.set(d.status, (map.get(d.status) ?? 0) + 1);
  });
  return Array.from(map.entries()).map(([name, value]) => ({ name, value }));
}

export function weeklyRedistribution(donations: FoodDonation[]): { name: string; value: number }[] {
  const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  const result = days.map((d) => ({ name: d, value: 0 }));
  const now = new Date();
  const dayOfWeek = (now.getDay() + 6) % 7; // 0 = Monday

  donations.forEach((d) => {
    const created = new Date(d.createdAt);
    const diffDays = Math.floor((now.getTime() - created.getTime()) / (1000 * 60 * 60 * 24));
    if (diffDays >= 0 && diffDays < 7) {
      const dayIdx = (dayOfWeek - diffDays + 7) % 7;
      if (d.status === 'Distributed' || d.status === 'Delivered') {
        result[dayIdx].value += d.quantity;
      }
    }
  });

  return result;
}

export function monthlyRedistribution(donations: FoodDonation[]): { name: string; value: number }[] {
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const now = new Date();
  const result: { name: string; value: number }[] = [];

  for (let i = 5; i >= 0; i--) {
    const month = new Date(now.getFullYear(), now.getMonth() - i, 1);
    const monthName = months[month.getMonth()];
    const value = donations.filter((d) => {
      const created = new Date(d.createdAt);
      return created.getMonth() === month.getMonth() &&
        created.getFullYear() === month.getFullYear() &&
        (d.status === 'Distributed' || d.status === 'Delivered');
    }).reduce((sum, d) => sum + d.quantity, 0);
    result.push({ name: monthName, value });
  }

  return result;
}

export function deliveryPerformance(deliveries: Delivery[]): { name: string; value: number }[] {
  const statuses = ['Assigned', 'In Transit', 'Delivered', 'Cancelled'] as const;
  return statuses.map((s) => ({
    name: s,
    value: deliveries.filter((d) => {
      if (s === 'In Transit') return d.status === 'In Transit' || d.status === 'Picked Up' || d.status === 'Pickup Started';
      if (s === 'Delivered') return d.status === 'Delivered' || d.status === 'Confirmed';
      return d.status === s;
    }).length,
  }));
}

export function totalFoodDonated(donations: FoodDonation[]): number {
  return donations.reduce((sum, d) => sum + d.quantity, 0);
}

export function totalFoodRedistributed(donations: FoodDonation[]): number {
  return donations.filter((d) => d.status === 'Distributed' || d.status === 'Delivered').reduce((sum, d) => sum + d.quantity, 0);
}

export function totalFoodExpired(donations: FoodDonation[]): number {
  return donations.filter((d) => d.status === 'Expired').reduce((sum, d) => sum + d.quantity, 0);
}

export function providerContributions(donations: FoodDonation[]): { name: string; value: number }[] {
  const map = new Map<string, number>();
  donations.forEach((d) => {
    map.set(d.providerName, (map.get(d.providerName) ?? 0) + d.quantity);
  });
  return Array.from(map.entries()).map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value).slice(0, 6);
}

export function recipientDistribution(distributions: Distribution[]): { name: string; value: number }[] {
  const map = new Map<string, number>();
  distributions.forEach((d) => {
    map.set(d.organizationName, (map.get(d.organizationName) ?? 0) + d.distributedQuantity);
  });
  return Array.from(map.entries()).map(([name, value]) => ({ name, value }));
}

export const foodTypeList: FoodType[] = [
  'Cooked Food', 'Fruits', 'Vegetables', 'Bakery', 'Dairy', 'Packaged Food', 'Grains', 'Beverages', 'Other',
];
