import type { DonationStatus, DeliveryStatus, RequestStatus } from '@/types';

// Donation state machine
export const donationTransitions: Record<DonationStatus, DonationStatus[]> = {
  Created: ['Available', 'Cancelled'],
  Available: ['Matched', 'Requested', 'Expired', 'Cancelled'],
  Matched: ['Requested', 'Available', 'Cancelled'],
  Requested: ['Approved', 'Rejected', 'Available', 'Cancelled'],
  Approved: ['Assigned', 'Cancelled'],
  Assigned: ['Picked Up', 'Cancelled'],
  'Picked Up': ['In Transit'],
  'In Transit': ['Delivered'],
  Delivered: ['Distributed'],
  Distributed: [],
  Expired: [],
  Cancelled: [],
  Rejected: ['Available'],
};

export function canTransition(from: DonationStatus, to: DonationStatus): boolean {
  return donationTransitions[from]?.includes(to) ?? false;
}

export function getValidNextStates(current: DonationStatus): DonationStatus[] {
  return donationTransitions[current] ?? [];
}

// Delivery state machine
export const deliveryTransitions: Record<DeliveryStatus, DeliveryStatus[]> = {
  Assigned: ['Accepted', 'Rejected', 'Cancelled'],
  Accepted: ['Pickup Started', 'Cancelled'],
  Rejected: [],
  'Pickup Started': ['Picked Up', 'Cancelled'],
  'Picked Up': ['In Transit'],
  'In Transit': ['Delivered'],
  Delivered: ['Confirmed'],
  Confirmed: [],
  Cancelled: [],
};

export function canTransitionDelivery(from: DeliveryStatus, to: DeliveryStatus): boolean {
  return deliveryTransitions[from]?.includes(to) ?? false;
}

export function getValidDeliveryNextStates(current: DeliveryStatus): DeliveryStatus[] {
  return deliveryTransitions[current] ?? [];
}

// Request state machine
export const requestTransitions: Record<RequestStatus, RequestStatus[]> = {
  Pending: ['Approved', 'Rejected', 'Cancelled'],
  Approved: ['Fulfilled', 'Cancelled'],
  Rejected: [],
  Fulfilled: [],
  Cancelled: [],
};

export function canTransitionRequest(from: RequestStatus, to: RequestStatus): boolean {
  return requestTransitions[from]?.includes(to) ?? false;
}
