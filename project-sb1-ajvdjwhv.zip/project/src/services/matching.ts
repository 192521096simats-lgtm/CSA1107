import type {
  FoodDonation,
  RecipientOrganization,
  MatchResult,
  MatchWeights,
  UrgencyLevel,
} from '@/types';

// Haversine distance in km
export function calculateDistance(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number,
): number {
  const R = 6371;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(R * c * 10) / 10;
}

export function calculateUrgency(expiryTime: string): UrgencyLevel {
  const now = Date.now();
  const expiry = new Date(expiryTime).getTime();
  const hoursLeft = (expiry - now) / (1000 * 60 * 60);

  if (hoursLeft < 0) return 'Critical';
  if (hoursLeft <= 6) return 'Critical';
  if (hoursLeft <= 24) return 'High';
  if (hoursLeft <= 48) return 'Medium';
  return 'Low';
}

export function hoursUntilExpiry(expiryTime: string): number {
  const now = Date.now();
  const expiry = new Date(expiryTime).getTime();
  return (expiry - now) / (1000 * 60 * 60);
}

export function isExpired(expiryTime: string): boolean {
  return new Date(expiryTime).getTime() < Date.now();
}

export function calculateMatchScore(
  donation: FoodDonation,
  organization: RecipientOrganization,
  weights: MatchWeights,
): MatchResult {
  const distance = calculateDistance(
    donation.pickupLatitude,
    donation.pickupLongitude,
    organization.latitude,
    organization.longitude,
  );

  // Location score: closer = higher (within 50km gets at least some score)
  const locationScore = Math.max(0, Math.min(100, 100 - (distance / 50) * 100));

  // Quantity score: org capacity vs donation quantity
  const quantityRatio = donation.quantity / organization.capacity;
  const quantityScore = Math.min(100, quantityRatio * 100 * 2); // 50% capacity = 100 score

  // Urgency score: more urgent = higher score for matching
  const urgencyMap: Record<UrgencyLevel, number> = {
    Critical: 100,
    High: 80,
    Medium: 60,
    Low: 40,
  };
  const urgencyScore = urgencyMap[donation.urgency] ?? 50;

  // Food requirement score: does org need this food type?
  const foodScore = organization.foodRequirements.includes(donation.foodType) ? 100 : 30;

  // Availability score
  const availabilityScore = organization.availability ? 100 : 0;

  const score =
    (locationScore * weights.location +
      quantityScore * weights.quantity +
      urgencyScore * weights.urgency +
      foodScore * weights.foodRequirement +
      availabilityScore * weights.availability) /
    100;

  return {
    organization,
    score: Math.round(score),
    distance,
    details: {
      locationScore: Math.round(locationScore),
      quantityScore: Math.round(quantityScore),
      urgencyScore,
      foodScore,
      availabilityScore,
    },
  };
}

export function findBestMatches(
  donation: FoodDonation,
  organizations: RecipientOrganization[],
  weights: MatchWeights,
): MatchResult[] {
  return organizations
    .filter((org) => org.availability)
    .map((org) => calculateMatchScore(donation, org, weights))
    .sort((a, b) => b.score - a.score);
}
