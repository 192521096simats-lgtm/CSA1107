import { BrowserRouter, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { type ReactNode } from 'react';
import { AuthProvider, useAuth } from '@/context/AuthContext';
import { DataProvider } from '@/context/DataContext';
import type { UserRole } from '@/types';

// Public pages
import { LandingPage } from '@/pages/LandingPage';
import { LoginPage } from '@/pages/LoginPage';
import { RegisterPage } from '@/pages/RegisterPage';

// Provider pages
import { ProviderDashboard } from '@/pages/provider/ProviderDashboard';
import { AddSurplusPage } from '@/pages/provider/AddSurplusPage';
import { MyDonationsPage } from '@/pages/provider/MyDonationsPage';
import { SmartMatchingPage } from '@/pages/provider/SmartMatchingPage';
import { ProviderRequestsPage } from '@/pages/provider/ProviderRequestsPage';

// Recipient pages
import { RecipientDashboard } from '@/pages/recipient/RecipientDashboard';
import { BrowseDonationsPage } from '@/pages/recipient/BrowseDonationsPage';
import { RecipientRequestsPage } from '@/pages/recipient/RecipientRequestsPage';
import { CollectionsPage } from '@/pages/recipient/CollectionsPage';
import { DistributionPage } from '@/pages/recipient/DistributionPage';

// Delivery pages
import { DeliveryDashboard } from '@/pages/delivery/DeliveryDashboard';
import { DeliveryAssignmentsPage } from '@/pages/delivery/DeliveryAssignmentsPage';
import { DeliveryHistoryPage } from '@/pages/delivery/DeliveryHistoryPage';

// Admin pages
import { AdminDashboard } from '@/pages/admin/AdminDashboard';
import { AdminUsersPage } from '@/pages/admin/AdminUsersPage';
import { AdminProvidersPage } from '@/pages/admin/AdminProvidersPage';
import { AdminOrganizationsPage } from '@/pages/admin/AdminOrganizationsPage';
import { AdminDonationsPage } from '@/pages/admin/AdminDonationsPage';
import { AdminRequestsPage } from '@/pages/admin/AdminRequestsPage';
import { AdminDeliveriesPage } from '@/pages/admin/AdminDeliveriesPage';
import { AdminReportsPage } from '@/pages/admin/AdminReportsPage';
import { AdminSettingsPage } from '@/pages/admin/AdminSettingsPage';

// Shared pages
import { DonationDetailsPage } from '@/pages/DonationDetailsPage';
import { DeliveryTrackingPage } from '@/pages/DeliveryTrackingPage';
import { NotificationsPage } from '@/pages/NotificationsPage';
import { ProfilePage } from '@/pages/ProfilePage';

// Role-based route guard
function RequireRole({ roles, children }: { roles: UserRole[]; children: ReactNode }) {
  const { user } = useAuth();
  const location = useLocation();

  if (!user) {
    return <Navigate to="/login" state={{ from: location }} replace />;
  }
  if (!roles.includes(user.role)) {
    const homePaths: Record<UserRole, string> = {
      provider: '/provider',
      recipient: '/recipient',
      delivery: '/delivery',
      admin: '/admin',
    };
    return <Navigate to={homePaths[user.role]} replace />;
  }
  return <>{children}</>;
}

// Redirect authenticated users away from login/register
function PublicOnly({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  if (user) {
    const homePaths: Record<UserRole, string> = {
      provider: '/provider',
      recipient: '/recipient',
      delivery: '/delivery',
      admin: '/admin',
    };
    return <Navigate to={homePaths[user.role]} replace />;
  }
  return <>{children}</>;
}

function AppRoutes() {
  return (
    <Routes>
      {/* Public routes */}
      <Route path="/" element={<LandingPage />} />
      <Route path="/login" element={<PublicOnly><LoginPage /></PublicOnly>} />
      <Route path="/register" element={<PublicOnly><RegisterPage /></PublicOnly>} />

      {/* Provider routes */}
      <Route path="/provider" element={<RequireRole roles={['provider']}><ProviderDashboard /></RequireRole>} />
      <Route path="/provider/add-surplus" element={<RequireRole roles={['provider']}><AddSurplusPage /></RequireRole>} />
      <Route path="/provider/donations" element={<RequireRole roles={['provider']}><MyDonationsPage /></RequireRole>} />
      <Route path="/provider/donations/:id" element={<RequireRole roles={['provider']}><DonationDetailsPage /></RequireRole>} />
      <Route path="/provider/matching" element={<RequireRole roles={['provider']}><SmartMatchingPage /></RequireRole>} />
      <Route path="/provider/requests" element={<RequireRole roles={['provider']}><ProviderRequestsPage /></RequireRole>} />

      {/* Recipient routes */}
      <Route path="/recipient" element={<RequireRole roles={['recipient']}><RecipientDashboard /></RequireRole>} />
      <Route path="/recipient/browse" element={<RequireRole roles={['recipient']}><BrowseDonationsPage /></RequireRole>} />
      <Route path="/recipient/browse/:id" element={<RequireRole roles={['recipient']}><DonationDetailsPage /></RequireRole>} />
      <Route path="/recipient/requests" element={<RequireRole roles={['recipient']}><RecipientRequestsPage /></RequireRole>} />
      <Route path="/recipient/collections" element={<RequireRole roles={['recipient']}><CollectionsPage /></RequireRole>} />
      <Route path="/recipient/collections/:id" element={<RequireRole roles={['recipient']}><DeliveryTrackingPage /></RequireRole>} />
      <Route path="/recipient/distribution" element={<RequireRole roles={['recipient']}><DistributionPage /></RequireRole>} />

      {/* Delivery routes */}
      <Route path="/delivery" element={<RequireRole roles={['delivery']}><DeliveryDashboard /></RequireRole>} />
      <Route path="/delivery/assignments" element={<RequireRole roles={['delivery']}><DeliveryAssignmentsPage /></RequireRole>} />
      <Route path="/delivery/active/:id" element={<RequireRole roles={['delivery']}><DeliveryTrackingPage /></RequireRole>} />
      <Route path="/delivery/history" element={<RequireRole roles={['delivery']}><DeliveryHistoryPage /></RequireRole>} />

      {/* Admin routes */}
      <Route path="/admin" element={<RequireRole roles={['admin']}><AdminDashboard /></RequireRole>} />
      <Route path="/admin/users" element={<RequireRole roles={['admin']}><AdminUsersPage /></RequireRole>} />
      <Route path="/admin/providers" element={<RequireRole roles={['admin']}><AdminProvidersPage /></RequireRole>} />
      <Route path="/admin/organizations" element={<RequireRole roles={['admin']}><AdminOrganizationsPage /></RequireRole>} />
      <Route path="/admin/donations" element={<RequireRole roles={['admin']}><AdminDonationsPage /></RequireRole>} />
      <Route path="/admin/donations/:id" element={<RequireRole roles={['admin']}><DonationDetailsPage /></RequireRole>} />
      <Route path="/admin/requests" element={<RequireRole roles={['admin']}><AdminRequestsPage /></RequireRole>} />
      <Route path="/admin/deliveries" element={<RequireRole roles={['admin']}><AdminDeliveriesPage /></RequireRole>} />
      <Route path="/admin/deliveries/:id" element={<RequireRole roles={['admin']}><DeliveryTrackingPage /></RequireRole>} />
      <Route path="/admin/reports" element={<RequireRole roles={['admin']}><AdminReportsPage /></RequireRole>} />
      <Route path="/admin/settings" element={<RequireRole roles={['admin']}><AdminSettingsPage /></RequireRole>} />

      {/* Shared routes */}
      <Route path="/notifications" element={<RequireRole roles={['provider', 'recipient', 'delivery', 'admin']}><NotificationsPage /></RequireRole>} />
      <Route path="/profile" element={<RequireRole roles={['provider', 'recipient', 'delivery', 'admin']}><ProfilePage /></RequireRole>} />

      {/* Fallback */}
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <DataProvider>
        <BrowserRouter>
          <AppRoutes />
        </BrowserRouter>
      </DataProvider>
    </AuthProvider>
  );
}
