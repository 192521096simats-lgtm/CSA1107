import { createContext, useContext, useState, useEffect, useCallback, type ReactNode } from 'react';
import type {
  FoodDonation,
  DonationRequest,
  Delivery,
  Distribution,
  Notification,
  RecipientOrganization,
  FoodProvider,
  SystemSettings,
  FoodType,
} from '@/types';
import { loadFromStorage, saveToStorage, STORAGE_KEYS } from '@/services/storage';
import {
  seedDonations,
  seedRequests,
  seedDeliveries,
  seedDistributions,
  seedNotifications,
  seedRecipients,
  seedProviders,
  seedSettings,
} from '@/data/seed';
import { calculateUrgency, isExpired, findBestMatches } from '@/services/matching';
import { generateDonationId, generateRequestId, generateDeliveryId, generateDistributionId, generateNotificationId } from '@/services/idGenerator';
import { useAuth } from '@/context/AuthContext';

interface DataContextType {
  donations: FoodDonation[];
  requests: DonationRequest[];
  deliveries: Delivery[];
  distributions: Distribution[];
  notifications: Notification[];
  recipients: RecipientOrganization[];
  providers: FoodProvider[];
  settings: SystemSettings;

  // Donation operations
  addDonation: (donation: Omit<FoodDonation, 'donationId' | 'status' | 'urgency' | 'createdAt' | 'matchScore' | 'matchedOrganizationId' | 'matchedOrganizationName'>) => FoodDonation;
  updateDonation: (id: string, updates: Partial<FoodDonation>) => void;
  deleteDonation: (id: string) => void;
  updateDonationStatus: (id: string, status: FoodDonation['status']) => void;
  getDonation: (id: string) => FoodDonation | undefined;

  // Request operations
  addRequest: (request: Omit<DonationRequest, 'requestId' | 'requestDate' | 'status'>) => DonationRequest;
  updateRequestStatus: (id: string, status: DonationRequest['status']) => void;
  getRequest: (id: string) => DonationRequest | undefined;

  // Delivery operations
  addDelivery: (delivery: Omit<Delivery, 'deliveryId' | 'status' | 'assignedTime' | 'pickupTime' | 'deliveryTime' | 'completionTime'>) => Delivery;
  updateDeliveryStatus: (id: string, status: Delivery['status']) => void;
  getDelivery: (id: string) => Delivery | undefined;
  assignDelivery: (donationId: string, partnerId: string) => void;

  // Distribution operations
  addDistribution: (dist: Omit<Distribution, 'distributionId' | 'updatedAt'>) => void;
  updateDistribution: (id: string, updates: Partial<Distribution>) => void;

  // Notification operations
  addNotification: (notif: Omit<Notification, 'notificationId' | 'createdAt' | 'read'>) => void;
  markNotificationRead: (id: string) => void;
  markAllNotificationsRead: (userId: string) => void;
  getNotificationsForUser: (userId: string) => Notification[];

  // Recipient operations
  updateRecipient: (id: string, updates: Partial<RecipientOrganization>) => void;

  // Settings
  updateSettings: (updates: Partial<SystemSettings>) => void;

  // Matching
  getMatchesForDonation: (donationId: string) => ReturnType<typeof findBestMatches>;

  // Expiry check
  checkExpiry: () => void;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export function DataProvider({ children }: { children: ReactNode }) {
  const { user, getAllUsers, setAllUsers } = useAuth();

  const [donations, setDonations] = useState<FoodDonation[]>([]);
  const [requests, setRequests] = useState<DonationRequest[]>([]);
  const [deliveries, setDeliveries] = useState<Delivery[]>([]);
  const [distributions, setDistributions] = useState<Distribution[]>([]);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [recipients, setRecipients] = useState<RecipientOrganization[]>([]);
  const [providers, setProviders] = useState<FoodProvider[]>([]);
  const [settings, setSettings] = useState<SystemSettings>(seedSettings);

  // Initialize from storage
  useEffect(() => {
    const init = <T,>(key: string, seed: T[]): T[] => {
      const stored = loadFromStorage<T[]>(key, []);
      if (stored.length === 0) {
        saveToStorage(key, seed);
        return seed;
      }
      return stored;
    };

    setDonations(init(STORAGE_KEYS.donations, seedDonations));
    setRequests(init(STORAGE_KEYS.requests, seedRequests));
    setDeliveries(init(STORAGE_KEYS.deliveries, seedDeliveries));
    setDistributions(init(STORAGE_KEYS.distributions, seedDistributions));
    setNotifications(init(STORAGE_KEYS.notifications, seedNotifications));
    setRecipients(init(STORAGE_KEYS.recipients, seedRecipients));
    setProviders(init(STORAGE_KEYS.providers, seedProviders));

    const storedSettings = loadFromStorage<SystemSettings>(STORAGE_KEYS.settings, seedSettings);
    setSettings(storedSettings);
  }, []);

  // Persist on change
  useEffect(() => { saveToStorage(STORAGE_KEYS.donations, donations); }, [donations]);
  useEffect(() => { saveToStorage(STORAGE_KEYS.requests, requests); }, [requests]);
  useEffect(() => { saveToStorage(STORAGE_KEYS.deliveries, deliveries); }, [deliveries]);
  useEffect(() => { saveToStorage(STORAGE_KEYS.distributions, distributions); }, [distributions]);
  useEffect(() => { saveToStorage(STORAGE_KEYS.notifications, notifications); }, [notifications]);
  useEffect(() => { saveToStorage(STORAGE_KEYS.recipients, recipients); }, [recipients]);
  useEffect(() => { saveToStorage(STORAGE_KEYS.providers, providers); }, [providers]);
  useEffect(() => { saveToStorage(STORAGE_KEYS.settings, settings); }, [settings]);

  // Auto-update urgency and check expiry
  useEffect(() => {
    const interval = setInterval(() => {
      setDonations((prev) =>
        prev.map((d) => {
          if (d.status === 'Expired' || d.status === 'Distributed' || d.status === 'Cancelled') return d;
          if (isExpired(d.expiryTime)) {
            return { ...d, status: 'Expired' as const, urgency: 'Critical' as const };
          }
          const newUrgency = calculateUrgency(d.expiryTime);
          return d.urgency !== newUrgency ? { ...d, urgency: newUrgency } : d;
        }),
      );
    }, 60000); // check every minute
    return () => clearInterval(interval);
  }, []);

  const notify = useCallback(
    (userId: string, type: Notification['type'], title: string, message: string, relatedId: string | null = null) => {
      const notif: Notification = {
        notificationId: generateNotificationId(),
        userId,
        type,
        title,
        message,
        createdAt: new Date().toISOString(),
        read: false,
        relatedId,
      };
      setNotifications((prev) => [notif, ...prev]);
    },
    [],
  );

  const addDonation: DataContextType['addDonation'] = useCallback((donationData) => {
    const urgency = calculateUrgency(donationData.expiryTime);
    const newDonation: FoodDonation = {
      ...donationData,
      donationId: generateDonationId(),
      status: 'Available',
      urgency,
      matchScore: 0,
      matchedOrganizationId: null,
      matchedOrganizationName: null,
      createdAt: new Date().toISOString(),
    };
    setDonations((prev) => [newDonation, ...prev]);
    notify(donationData.providerId, 'success', 'Donation Created', `Donation ${newDonation.donationId} (${donationData.foodName}) has been created and is now available.`);
    return newDonation;
  }, [notify]);

  const updateDonation: DataContextType['updateDonation'] = useCallback((id, updates) => {
    setDonations((prev) => prev.map((d) => (d.donationId === id ? { ...d, ...updates } : d)));
  }, []);

  const deleteDonation: DataContextType['deleteDonation'] = useCallback((id) => {
    setDonations((prev) => prev.filter((d) => d.donationId !== id));
    setRequests((prev) => prev.filter((r) => r.donationId !== id));
  }, []);

  const updateDonationStatus: DataContextType['updateDonationStatus'] = useCallback((id, status) => {
    setDonations((prev) => prev.map((d) => (d.donationId === id ? { ...d, status } : d)));
  }, []);

  const getDonation: DataContextType['getDonation'] = useCallback((id) => donations.find((d) => d.donationId === id), [donations]);

  const addRequest: DataContextType['addRequest'] = useCallback((requestData) => {
    const newRequest: DonationRequest = {
      ...requestData,
      requestId: generateRequestId(),
      requestDate: new Date().toISOString(),
      status: 'Pending',
    };
    setRequests((prev) => [newRequest, ...prev]);
    // Update donation status to Requested
    setDonations((prev) =>
      prev.map((d) =>
        d.donationId === requestData.donationId
          ? { ...d, status: 'Requested', matchedOrganizationId: requestData.organizationId, matchedOrganizationName: requestData.organizationName }
          : d,
      ),
    );
    // Notify provider
    notify(requestData.providerId, 'info', 'New Request Received', `${requestData.organizationName} has requested donation ${requestData.donationId}.`, requestData.donationId);
    // Notify recipient
    notify(requestData.organizationId, 'info', 'Request Submitted', `Your request for donation ${requestData.donationId} has been submitted.`, newRequest.requestId);
    return newRequest;
  }, [notify]);

  const updateRequestStatus: DataContextType['updateRequestStatus'] = useCallback((id, status) => {
    setRequests((prev) => {
      const updated = prev.map((r) => (r.requestId === id ? { ...r, status } : r));
      const req = updated.find((r) => r.requestId === id);
      if (req) {
        if (status === 'Approved') {
          setDonations((dprev) => dprev.map((d) => (d.donationId === req.donationId ? { ...d, status: 'Approved' } : d)));
          notify(req.organizationId, 'success', 'Request Approved', `Your request for donation ${req.donationId} has been approved.`, req.requestId);
        } else if (status === 'Rejected') {
          setDonations((dprev) => dprev.map((d) => (d.donationId === req.donationId ? { ...d, status: 'Available' } : d)));
          notify(req.organizationId, 'warning', 'Request Rejected', `Your request for donation ${req.donationId} has been rejected.`, req.requestId);
        }
      }
      return updated;
    });
  }, [notify]);

  const getRequest: DataContextType['getRequest'] = useCallback((id) => requests.find((r) => r.requestId === id), [requests]);

  const addDelivery: DataContextType['addDelivery'] = useCallback((deliveryData) => {
    const newDelivery: Delivery = {
      ...deliveryData,
      deliveryId: generateDeliveryId(),
      status: 'Assigned',
      assignedTime: new Date().toISOString(),
      pickupTime: null,
      deliveryTime: null,
      completionTime: null,
    };
    setDeliveries((prev) => [newDelivery, ...prev]);
    // Update donation status to Assigned
    setDonations((prev) => prev.map((d) => (d.donationId === deliveryData.donationId ? { ...d, status: 'Assigned' } : d)));
    // Notify delivery partner
    notify(deliveryData.partnerId, 'info', 'New Delivery Assignment', `You have been assigned delivery ${newDelivery.deliveryId}. Please accept or reject.`, newDelivery.deliveryId);
    // Notify recipient
    notify(deliveryData.recipientId, 'info', 'Delivery Assigned', `Delivery ${newDelivery.deliveryId} has been assigned for your donation.`, newDelivery.deliveryId);
    return newDelivery;
  }, [notify]);

  const updateDeliveryStatus: DataContextType['updateDeliveryStatus'] = useCallback((id, status) => {
    const now = new Date().toISOString();
    setDeliveries((prev) =>
      prev.map((d) => {
        if (d.deliveryId !== id) return d;
        const updated = { ...d, status };
        if (status === 'Picked Up') updated.pickupTime = now;
        if (status === 'Delivered') updated.deliveryTime = now;
        if (status === 'Confirmed' || status === 'Delivered') updated.completionTime = now;
        return updated;
      }),
    );
    const delivery = deliveries.find((d) => d.deliveryId === id);
    if (delivery) {
      // Sync donation status
      const donationStatusMap: Record<Delivery['status'], FoodDonation['status'] | null> = {
        'Assigned': 'Assigned',
        'Accepted': 'Assigned',
        'Rejected': null,
        'Pickup Started': 'Assigned',
        'Picked Up': 'Picked Up',
        'In Transit': 'In Transit',
        'Delivered': 'Delivered',
        'Confirmed': 'Delivered',
        'Cancelled': 'Available',
      };
      const newDonationStatus = donationStatusMap[status];
      if (newDonationStatus) {
        setDonations((prev) => prev.map((d) => (d.donationId === delivery.donationId ? { ...d, status: newDonationStatus } : d)));
      }
      // Notify relevant parties
      if (status === 'Picked Up') {
        notify(delivery.recipientId, 'info', 'Pickup Completed', `Pickup confirmed for delivery ${id}. Food is on the way.`, id);
        notify(delivery.providerId, 'info', 'Pickup Completed', `Pickup confirmed for delivery ${id}.`, id);
      } else if (status === 'Delivered') {
        notify(delivery.recipientId, 'success', 'Delivery Completed', `Delivery ${id} has been completed. Please confirm collection.`, id);
        notify(delivery.providerId, 'success', 'Delivery Completed', `Delivery ${id} has been completed successfully.`, id);
      } else if (status === 'Confirmed') {
        notify(delivery.providerId, 'success', 'Collection Confirmed', `Recipient has confirmed collection for delivery ${id}.`, id);
      }
    }
  }, [deliveries, notify]);

  const getDelivery: DataContextType['getDelivery'] = useCallback((id) => deliveries.find((d) => d.deliveryId === id), [deliveries]);

  const assignDelivery: DataContextType['assignDelivery'] = useCallback((donationId, partnerId) => {
    const donation = donations.find((d) => d.donationId === donationId);
    const req = requests.find((r) => r.donationId === donationId && r.status === 'Approved');
    const partner = getAllUsers().find((u) => u.userId === partnerId);
    const recipient = recipients.find((r) => r.organizationId === donation?.matchedOrganizationId);
    if (!donation || !req || !recipient) return;

    addDelivery({
      requestId: req.requestId,
      donationId: donation.donationId,
      partnerId,
      partnerName: partner?.name ?? 'Unknown',
      providerId: donation.providerId,
      providerName: donation.providerName,
      recipientId: recipient.organizationId,
      recipientName: recipient.organizationName,
      pickupLocation: donation.pickupLocation,
      destination: recipient.address,
      pickupLatitude: donation.pickupLatitude,
      pickupLongitude: donation.pickupLongitude,
      destLatitude: recipient.latitude,
      destLongitude: recipient.longitude,
      foodName: donation.foodName,
      foodType: donation.foodType,
      quantity: donation.quantity,
      unit: donation.unit,
      distance: 0,
      estimatedDeliveryTime: new Date(Date.now() + 2 * 60 * 60 * 1000).toISOString(),
    });
  }, [donations, requests, recipients, getAllUsers, addDelivery]);

  const addDistribution: DataContextType['addDistribution'] = useCallback((distData) => {
    const newDist: Distribution = {
      ...distData,
      distributionId: generateDistributionId(),
      updatedAt: new Date().toISOString(),
    };
    setDistributions((prev) => [newDist, ...prev]);
    // Update donation status to Distributed
    setDonations((prev) => prev.map((d) => (d.donationId === distData.donationId ? { ...d, status: 'Distributed' } : d)));
    // Update request status to Fulfilled
    setRequests((prev) => prev.map((r) => (r.donationId === distData.donationId && r.status === 'Approved' ? { ...r, status: 'Fulfilled' } : r)));
    // Notify
    notify(distData.organizationId, 'success', 'Distribution Recorded', `Distribution for ${distData.foodName} has been recorded.`, distData.donationId);
  }, [notify]);

  const updateDistribution: DataContextType['updateDistribution'] = useCallback((id, updates) => {
    setDistributions((prev) =>
      prev.map((d) => (d.distributionId === id ? { ...d, ...updates, updatedAt: new Date().toISOString() } : d)),
    );
  }, []);

  const addNotification: DataContextType['addNotification'] = useCallback((notifData) => {
    const notif: Notification = {
      ...notifData,
      notificationId: generateNotificationId(),
      createdAt: new Date().toISOString(),
      read: false,
    };
    setNotifications((prev) => [notif, ...prev]);
  }, []);

  const markNotificationRead: DataContextType['markNotificationRead'] = useCallback((id) => {
    setNotifications((prev) => prev.map((n) => (n.notificationId === id ? { ...n, read: true } : n)));
  }, []);

  const markAllNotificationsRead: DataContextType['markAllNotificationsRead'] = useCallback((userId) => {
    setNotifications((prev) => prev.map((n) => (n.userId === userId ? { ...n, read: true } : n)));
  }, []);

  const getNotificationsForUser: DataContextType['getNotificationsForUser'] = useCallback(
    (userId) => notifications.filter((n) => n.userId === userId).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()),
    [notifications],
  );

  const updateRecipient: DataContextType['updateRecipient'] = useCallback((id, updates) => {
    setRecipients((prev) => prev.map((r) => (r.organizationId === id ? { ...r, ...updates } : r)));
  }, []);

  const updateSettings: DataContextType['updateSettings'] = useCallback((updates) => {
    setSettings((prev) => ({ ...prev, ...updates }));
  }, []);

  const getMatchesForDonation: DataContextType['getMatchesForDonation'] = useCallback(
    (donationId) => {
      const donation = donations.find((d) => d.donationId === donationId);
      if (!donation) return [];
      return findBestMatches(donation, recipients, settings.matchWeights);
    },
    [donations, recipients, settings.matchWeights],
  );

  const checkExpiry: DataContextType['checkExpiry'] = useCallback(() => {
    setDonations((prev) =>
      prev.map((d) => {
        if (d.status === 'Expired' || d.status === 'Distributed' || d.status === 'Cancelled' || d.status === 'Delivered') return d;
        if (isExpired(d.expiryTime)) {
          notify(d.providerId, 'urgent', 'URGENT - Donation Expired', `Donation ${d.donationId} (${d.foodName}) has expired.`, d.donationId);
          return { ...d, status: 'Expired' as const, urgency: 'Critical' as const };
        }
        return d;
      }),
    );
  }, [notify]);

  // Generate expiry notifications periodically
  useEffect(() => {
    if (!user) return;
    donations.forEach((d) => {
      if (d.status === 'Expired' || d.status === 'Distributed' || d.status === 'Cancelled') return;
      const hoursLeft = (new Date(d.expiryTime).getTime() - Date.now()) / (1000 * 60 * 60);
      if (hoursLeft > 0 && hoursLeft <= settings.expiryUrgentHours && d.urgency === 'Critical') {
        // Only notify if not already notified recently
        const existing = notifications.find(
          (n) => n.relatedId === d.donationId && n.type === 'urgent' && n.userId === d.providerId,
        );
        if (!existing) {
          notify(d.providerId, 'urgent', 'URGENT - Expiring Soon', `Donation ${d.donationId} (${d.foodName}) expires in ${Math.round(hoursLeft)} hours.`, d.donationId);
        }
      } else if (hoursLeft > settings.expiryUrgentHours && hoursLeft <= settings.expiryWarningHours) {
        const existing = notifications.find(
          (n) => n.relatedId === d.donationId && n.type === 'warning' && n.userId === d.providerId,
        );
        if (!existing) {
          notify(d.providerId, 'warning', 'Expiring Soon', `Donation ${d.donationId} (${d.foodName}) expires within 24 hours.`, d.donationId);
        }
      }
    });
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [donations]);

  return (
    <DataContext.Provider
      value={{
        donations,
        requests,
        deliveries,
        distributions,
        notifications,
        recipients,
        providers,
        settings,
        addDonation,
        updateDonation,
        deleteDonation,
        updateDonationStatus,
        getDonation,
        addRequest,
        updateRequestStatus,
        getRequest,
        addDelivery,
        updateDeliveryStatus,
        getDelivery,
        assignDelivery,
        addDistribution,
        updateDistribution,
        addNotification,
        markNotificationRead,
        markAllNotificationsRead,
        getNotificationsForUser,
        updateRecipient,
        updateSettings,
        getMatchesForDonation,
        checkExpiry,
      }}
    >
      {children}
    </DataContext.Provider>
  );
}

export function useData() {
  const ctx = useContext(DataContext);
  if (!ctx) throw new Error('useData must be used within DataProvider');
  return ctx;
}
