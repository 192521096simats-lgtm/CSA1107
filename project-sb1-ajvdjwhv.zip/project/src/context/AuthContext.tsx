import { createContext, useContext, useState, useEffect, type ReactNode } from 'react';
import type { User, UserRole } from '@/types';
import { loadFromStorage, saveToStorage, STORAGE_KEYS } from '@/services/storage';
import { seedUsers } from '@/data/seed';

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  login: (email: string, password: string, role: UserRole) => { success: boolean; message: string };
  logout: () => void;
  register: (data: RegisterData) => { success: boolean; message: string };
  updateProfile: (updates: Partial<User>) => void;
  getAllUsers: () => User[];
  setAllUsers: (users: User[]) => void;
}

interface RegisterData {
  name: string;
  organizationName: string;
  email: string;
  phone: string;
  password: string;
  role: UserRole;
  address: string;
  city: string;
  organizationType: string;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [users, setUsers] = useState<User[]>([]);

  useEffect(() => {
    const stored = loadFromStorage<User[]>(STORAGE_KEYS.users, []);
    if (stored.length === 0) {
      saveToStorage(STORAGE_KEYS.users, seedUsers);
      setUsers(seedUsers);
    } else {
      setUsers(stored);
    }

    const currentStored = loadFromStorage<User | null>(STORAGE_KEYS.currentUser, null);
    if (currentStored) setUser(currentStored);
  }, []);

  const persistUsers = (newUsers: User[]) => {
    setUsers(newUsers);
    saveToStorage(STORAGE_KEYS.users, newUsers);
  };

  const login: AuthContextType['login'] = (email, password, role) => {
    const found = users.find(
      (u) => u.email.toLowerCase() === email.toLowerCase() && u.password === password,
    );
    if (!found) {
      return { success: false, message: 'Invalid email or password' };
    }
    if (found.role !== role) {
      return { success: false, message: `This account is registered as ${found.role}. Please select the correct role.` };
    }
    if (found.status !== 'active') {
      return { success: false, message: 'This account has been deactivated. Please contact administrator.' };
    }
    setUser(found);
    saveToStorage(STORAGE_KEYS.currentUser, found);
    return { success: true, message: 'Login successful' };
  };

  const logout = () => {
    setUser(null);
    saveToStorage(STORAGE_KEYS.currentUser, null);
  };

  const register: AuthContextType['register'] = (data) => {
    const exists = users.find((u) => u.email.toLowerCase() === data.email.toLowerCase());
    if (exists) {
      return { success: false, message: 'An account with this email already exists' };
    }

    const newUser: User = {
      userId: `U-${Date.now().toString(36)}`,
      name: data.name,
      email: data.email,
      phone: data.phone,
      password: data.password,
      role: data.role,
      status: 'active',
      organizationId: `ORG-${Date.now().toString(36)}`,
      organizationName: data.organizationName,
      organizationType: data.organizationType as User['organizationType'],
      address: data.address,
      city: data.city,
      createdAt: new Date().toISOString(),
    };

    const newUsers = [...users, newUser];
    persistUsers(newUsers);
    setUser(newUser);
    saveToStorage(STORAGE_KEYS.currentUser, newUser);
    return { success: true, message: 'Registration successful' };
  };

  const updateProfile = (updates: Partial<User>) => {
    if (!user) return;
    const updated = { ...user, ...updates };
    setUser(updated);
    saveToStorage(STORAGE_KEYS.currentUser, updated);
    const newUsers = users.map((u) => (u.userId === user.userId ? updated : u));
    persistUsers(newUsers);
  };

  const getAllUsers = () => users;
  const setAllUsers = (newUsers: User[]) => persistUsers(newUsers);

  return (
    <AuthContext.Provider
      value={{ user, isAuthenticated: !!user, login, logout, register, updateProfile, getAllUsers, setAllUsers }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
